import { conversationLink, parseConversationId, readBindings, saveBindings, type BotBindings } from "./grokBot";
import { ROLES, type RoleId } from "./sim/roles";

export function createBindingsDialog(): (role: RoleId) => string | undefined {
  const trigger = document.querySelector<HTMLButtonElement>("#bindings-trigger")!;
  const dialog = document.querySelector<HTMLDialogElement>("#bindings-dialog")!;
  const title = document.querySelector<HTMLElement>("#bindings-title")!;
  const fields = document.querySelector<HTMLElement>("#bindings-fields")!;
  const form = document.querySelector<HTMLFormElement>("#bindings-form")!;
  const status = document.querySelector<HTMLElement>("#bindings-status")!;
  let bindings = readBindings();

  const inputs = ROLES.map(({ id, name }) => {
    const label = document.createElement("label");
    const caption = document.createElement("span");
    const input = document.createElement("input");
    caption.textContent = name;
    input.name = id;
    input.type = "text";
    input.placeholder = "Paste ID or link";
    input.autocomplete = "off";
    input.autocapitalize = "off";
    input.spellcheck = false;
    input.addEventListener("input", () => {
      input.setCustomValidity("");
      status.textContent = "";
    });
    label.append(caption, input);
    fields.append(label);
    return { id, input };
  });

  function open(): void {
    for (const { id, input } of inputs) {
      input.value = bindings[id] ?? "";
      input.setCustomValidity("");
    }
    status.textContent = "";
    dialog.showModal();
    title.focus();
  }

  trigger.hidden = false;
  trigger.addEventListener("click", open);
  document.querySelector("#bindings-close")!.addEventListener("click", () => dialog.close());
  document.querySelector("#bindings-clear")!.addEventListener("click", () => {
    for (const { input } of inputs) {
      input.value = "";
      input.setCustomValidity("");
    }
    status.textContent = "Fields cleared. Save to remove the links.";
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const next: BotBindings = {};
    for (const { id, input } of inputs) {
      const value = input.value.trim();
      const conversation = parseConversationId(value);
      input.setCustomValidity(value && !conversation ? "Enter a conversation ID or a Grok Bot link." : "");
      if (conversation) next[id] = conversation;
    }
    if (!form.reportValidity()) return;

    bindings = next;
    if (saveBindings(bindings)) dialog.close();
    else status.textContent = "Saved for this visit. This browser could not store the changes for next time.";
  });

  if (new URLSearchParams(window.location.search).has("bindings")) open();
  return (role) => conversationLink(bindings[role]);
}
