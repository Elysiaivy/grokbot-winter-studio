import { CELL, GRID_R, WALK, clearance, pointClear, segmentClear } from "./layout";
import type { Vec } from "./types";

interface Cell {
  cx: number;
  cz: number;
}

const cols = Math.ceil((WALK.maxX - WALK.minX) / CELL);
const rows = Math.ceil((WALK.maxZ - WALK.minZ) / CELL);
const blocked = new Uint8Array(cols * rows);

function index(cx: number, cz: number): number {
  return cz * cols + cx;
}

function centerOf(cell: Cell): Vec {
  return {
    x: WALK.minX + (cell.cx + 0.5) * CELL,
    z: WALK.minZ + (cell.cz + 0.5) * CELL,
  };
}

function cellAt(x: number, z: number): Cell | null {
  const cx = Math.floor((x - WALK.minX) / CELL);
  const cz = Math.floor((z - WALK.minZ) / CELL);
  if (cx < 0 || cz < 0 || cx >= cols || cz >= rows) return null;
  return { cx, cz };
}

for (let cz = 0; cz < rows; cz += 1) {
  for (let cx = 0; cx < cols; cx += 1) {
    const point = centerOf({ cx, cz });
    if (clearance(point.x, point.z) < GRID_R) blocked[index(cx, cz)] = 1;
  }
}

function nearestFree(x: number, z: number): Cell | null {
  const origin = cellAt(x, z);
  if (origin && !blocked[index(origin.cx, origin.cz)]) return origin;
  let best: Cell | null = null;
  let bestDist = Infinity;
  const reach = 5;
  const seed = origin ?? { cx: Math.floor(cols / 2), cz: Math.floor(rows / 2) };
  for (let dz = -reach; dz <= reach; dz += 1) {
    for (let dx = -reach; dx <= reach; dx += 1) {
      const cx = seed.cx + dx;
      const cz = seed.cz + dz;
      if (cx < 0 || cz < 0 || cx >= cols || cz >= rows) continue;
      if (blocked[index(cx, cz)]) continue;
      const point = centerOf({ cx, cz });
      const dist = Math.hypot(point.x - x, point.z - z);
      if (dist < bestDist) {
        bestDist = dist;
        best = { cx, cz };
      }
    }
  }
  if (!best || bestDist > 0.9) return null;
  return best;
}

function smooth(points: Vec[]): Vec[] | null {
  if (points.length <= 2) {
    return points.length >= 2 && !segmentClear(points[0], points[points.length - 1]) ? null : points;
  }
  const out: Vec[] = [points[0]];
  let anchor = 0;
  while (anchor < points.length - 1) {
    let next = -1;
    for (let i = points.length - 1; i > anchor; i -= 1) {
      if (segmentClear(points[anchor], points[i])) {
        next = i;
        break;
      }
    }
    if (next < 0) return null;
    out.push(points[next]);
    anchor = next;
  }
  return out;
}

/**
 * 4-connected A* on the inflated grid, then string-pulling.
 * Returns null when the goal itself is inside furniture or a wall.
 */
export function findPath(from: Vec, to: Vec): Vec[] | null {
  if (!pointClear(to.x, to.z) || !pointClear(from.x, from.z)) return null;
  if (segmentClear(from, to)) return [from, to];

  const start = nearestFree(from.x, from.z);
  const goal = nearestFree(to.x, to.z);
  if (!start || !goal) return null;

  const startKey = index(start.cx, start.cz);
  const goalKey = index(goal.cx, goal.cz);
  const open: number[] = [startKey];
  const came = new Int32Array(blocked.length).fill(-1);
  const gScore = new Float32Array(blocked.length).fill(Infinity);
  gScore[startKey] = 0;
  const inOpen = new Uint8Array(blocked.length);
  inOpen[startKey] = 1;

  const goalCenter = centerOf(goal);
  function heuristic(key: number): number {
    const cx = key % cols;
    const cz = (key - cx) / cols;
    const point = centerOf({ cx, cz });
    return Math.abs(point.x - goalCenter.x) + Math.abs(point.z - goalCenter.z);
  }

  while (open.length) {
    let bestI = 0;
    let bestF = Infinity;
    for (let i = 0; i < open.length; i += 1) {
      const key = open[i];
      const score = gScore[key] + heuristic(key);
      if (score < bestF) {
        bestF = score;
        bestI = i;
      }
    }
    const current = open.splice(bestI, 1)[0];
    inOpen[current] = 0;
    if (current === goalKey) break;
    const cx = current % cols;
    const cz = (current - cx) / cols;
    const neighbors = [
      [cx + 1, cz],
      [cx - 1, cz],
      [cx, cz + 1],
      [cx, cz - 1],
    ];
    for (const [nx, nz] of neighbors) {
      if (nx < 0 || nz < 0 || nx >= cols || nz >= rows) continue;
      const key = index(nx, nz);
      if (blocked[key]) continue;
      const currentCell = { cx, cz };
      if (!segmentClear(centerOf(currentCell), centerOf({ cx: nx, cz: nz }), GRID_R)) continue;
      const tentative = gScore[current] + CELL;
      if (tentative < gScore[key]) {
        came[key] = current;
        gScore[key] = tentative;
        if (!inOpen[key]) {
          open.push(key);
          inOpen[key] = 1;
        }
      }
    }
  }

  if (gScore[goalKey] === Infinity) return null;

  const chain: Vec[] = [];
  let cursor = goalKey;
  const guard = blocked.length + 2;
  let steps = 0;
  while (cursor !== startKey && steps < guard) {
    const cx = cursor % cols;
    const cz = (cursor - cx) / cols;
    chain.push(centerOf({ cx, cz }));
    cursor = came[cursor];
    if (cursor < 0) return null;
    steps += 1;
  }
  chain.push(centerOf(start));
  chain.reverse();
  const withEnds = [from, ...chain, to];
  const cleaned: Vec[] = [];
  for (const point of withEnds) {
    const prev = cleaned[cleaned.length - 1];
    if (!prev || Math.hypot(prev.x - point.x, prev.z - point.z) > 1e-4) cleaned.push(point);
  }
  const pulled = smooth(cleaned);
  if (!pulled || pulled.length < 2) return null;
  const end = pulled[pulled.length - 1];
  if (Math.hypot(end.x - to.x, end.z - to.z) > 0.05) return null;
  return pulled;
}

export const navStats = { cols, rows, blocked: blocked.reduce((sum, bit) => sum + bit, 0) };
