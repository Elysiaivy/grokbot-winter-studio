const minX = -0.92;
const maxX = 5.05;
const frontZ = 0.24;
const backZ = 4.18;
const treeCutX = 1.33;
const treeCutZ = 2.15;

// The front diagonal leaves a double-height opening around the Christmas tree.
export const UPPER_FLOOR = {
  minX, maxX, frontZ, backZ, treeCutX, treeCutZ, level: 2.49,
  outline: [
    [minX, backZ], [minX, treeCutZ], [treeCutX, frontZ],
    [maxX, frontZ], [maxX, backZ],
  ] as const,
};

export const UPPER_STAIR = {
  minX: 1.64, maxX: 2.48, footZ: -2.56, landingZ: frontZ, steps: 13,
};

export const UPPER_COLUMNS = [{ x: 1.31, z: 0.30 }, { x: -0.84, z: 2.18 }] as const;
