import { roleById } from "./roles";
import type { RobotSnapshot } from "./types";

export interface RobotLabel {
  name: string;
  line: string;
  chip: string;
}

export function describeRobot(robot: RobotSnapshot): RobotLabel {
  const role = roleById(robot.id);
  switch (robot.phase) {
    case "working":
      return { name: role.name, line: "Demo · Working at their desk", chip: "Working" };
    case "getting_up":
      return {
        name: role.name,
        line: robot.intent === "busy" ? "Demo · Getting ready to return to their desk" : "Demo · Getting up",
        chip: "Getting up",
      };
    case "walking":
      if (robot.intent === "busy") {
        return { name: role.name, line: "Demo · Returning to their desk", chip: "Returning" };
      }
      if (robot.destZone === "kitchen") {
        return { name: role.name, line: "Demo · Heading to the kitchen", chip: "Walking" };
      }
      return { name: role.name, line: "Demo · Heading to the fireplace", chip: "Walking" };
    case "sipping":
      return { name: role.name, line: "Demo · Getting a hot drink in the kitchen", chip: "Kitchen" };
    case "seated_fire":
      return { name: role.name, line: "Demo · Taking a break by the fireplace", chip: "Fireplace" };
    default:
      return { name: role.name, line: "Demo activity", chip: "Demo" };
  }
}
