import { deskSeat, SEATS, seatById } from "./layout";
import { findPath } from "./nav";
import { ROLES, type RoleId } from "./roles";
import type { Intent, Phase, RobotSnapshot, Vec, Zone } from "./types";

const DEMO_FIRST = 7;
const DEMO_STAGGER = 6.2;
const DEMO_PERIOD = 50;
const WALK_SPEED = 1.22;
const GET_UP = 0.42;

export interface SimRobot {
  id: RoleId;
  intent: Intent;
  phase: Phase;
  destZone: Zone | null;
  x: number;
  z: number;
  yaw: number;
  seatId: string | null;
  destSeatId: string | null;
  path: Vec[];
  nextIndex: number;
  getUp: number;
  holdDemo: number;
  nextFlip: number;
}

export interface Sim {
  robots: SimRobot[];
  elapsed: number;
  demo: boolean;
  paused: boolean;
  reducedMotion: boolean;
}

function snapshotOf(robot: SimRobot): RobotSnapshot {
  return {
    id: robot.id,
    intent: robot.intent,
    phase: robot.phase,
    destZone: robot.destZone,
    x: robot.x,
    z: robot.z,
    yaw: robot.yaw,
    seatId: robot.seatId,
  };
}

export function snapshots(sim: Sim): RobotSnapshot[] {
  return sim.robots.map(snapshotOf);
}

function occupied(sim: Sim, seatId: string, except: RoleId): boolean {
  return sim.robots.some((robot) => robot.id !== except && robot.destSeatId === seatId);
}

function chooseIdleSeat(sim: Sim, robot: SimRobot): string | null {
  const prefer = ROLES.find((role) => role.id === robot.id)?.prefer ?? "fire";
  const free = SEATS.filter((seat) => seat.kind === "idle" && !occupied(sim, seat.id, robot.id));
  const pool = free.filter((seat) => seat.zone === prefer);
  const choices = pool.length ? pool : free;
  if (!choices.length) return null;
  choices.sort((a, b) => Math.hypot(a.x - robot.x, a.z - robot.z) - Math.hypot(b.x - robot.x, b.z - robot.z));
  return choices[0].id;
}

function arrive(robot: SimRobot): void {
  if (!robot.destSeatId) return;
  const seat = seatById(robot.destSeatId);
  robot.x = seat.x;
  robot.z = seat.z;
  robot.yaw = seat.yaw;
  robot.seatId = seat.id;
  robot.path = [];
  robot.nextIndex = 0;
  robot.destZone = seat.zone;
  if (seat.zone === "kitchen") robot.phase = "sipping";
  else if (seat.zone === "fire") robot.phase = "seated_fire";
  else robot.phase = "working";
}

function beginWalk(robot: SimRobot): void {
  if (!robot.destSeatId) return;
  const seat = seatById(robot.destSeatId);
  const path = findPath({ x: robot.x, z: robot.z }, { x: seat.x, z: seat.z });
  if (!path) {
    if (Math.hypot(seat.x - robot.x, seat.z - robot.z) < 0.35) arrive(robot);
    return;
  }
  robot.path = path;
  robot.nextIndex = 1;
  robot.phase = "walking";
  robot.destZone = seat.zone;
  if (robot.nextIndex >= robot.path.length) arrive(robot);
}

function assignDestination(sim: Sim, robot: SimRobot): void {
  if (robot.intent === "busy") {
    const desk = deskSeat(robot.id);
    robot.destSeatId = desk.id;
    robot.destZone = "desk";
    if (Math.hypot(robot.x - desk.x, robot.z - desk.z) < 0.08) {
      arrive(robot);
      return;
    }
  } else {
    const idle = chooseIdleSeat(sim, robot);
    if (!idle) return;
    robot.destSeatId = idle;
    robot.destZone = seatById(idle).zone;
    if (robot.seatId === idle && (robot.phase === "sipping" || robot.phase === "seated_fire")) return;
  }
  const standing = robot.phase === "walking" || robot.phase === "getting_up";
  if (standing && robot.phase === "walking") {
    beginWalk(robot);
    return;
  }
  if (robot.phase === "getting_up") return;
  robot.phase = "getting_up";
  robot.getUp = sim.reducedMotion ? 0.08 : GET_UP;
}

export function createSim(): Sim {
  const robots: SimRobot[] = ROLES.map((role, index) => {
    const idleStart = role.id === "literature" ? "fire:3" : role.id === "secretary" ? "kitchen:1" : null;
    const seat = idleStart ? seatById(idleStart) : deskSeat(role.id);
    const intent: Intent = idleStart ? "idle" : "busy";
    const phase: Phase = seat.zone === "kitchen" ? "sipping" : seat.zone === "fire" ? "seated_fire" : "working";
    return {
      id: role.id,
      intent,
      phase,
      destZone: seat.zone,
      x: seat.x,
      z: seat.z,
      yaw: seat.yaw,
      seatId: seat.id,
      destSeatId: seat.id,
      path: [],
      nextIndex: 0,
      getUp: 0,
      holdDemo: 0,
      nextFlip: DEMO_FIRST + index * DEMO_STAGGER,
    };
  });
  return { robots, elapsed: 0, demo: true, paused: false, reducedMotion: false };
}

export function setIntent(sim: Sim, id: RoleId, intent: Intent): void {
  const robot = sim.robots.find((item) => item.id === id);
  if (!robot || robot.intent === intent) return;
  robot.intent = intent;
  robot.holdDemo = 22;
  robot.nextFlip = Math.max(robot.nextFlip, sim.elapsed + 22);
  assignDestination(sim, robot);
}

function advanceDemo(sim: Sim): void {
  if (!sim.demo) return;
  for (const robot of sim.robots) {
    if (robot.holdDemo > 0) continue;
    if (sim.elapsed + 1e-6 < robot.nextFlip) continue;
    robot.intent = robot.intent === "busy" ? "idle" : "busy";
    robot.nextFlip = sim.elapsed + DEMO_PERIOD;
    assignDestination(sim, robot);
  }
}

function moveRobot(robot: SimRobot, dt: number, speed: number): void {
  let remaining = speed * dt;
  while (remaining > 0 && robot.nextIndex < robot.path.length) {
    const target = robot.path[robot.nextIndex];
    const dx = target.x - robot.x;
    const dz = target.z - robot.z;
    const dist = Math.hypot(dx, dz);
    if (dist < 1e-5) {
      robot.nextIndex += 1;
      continue;
    }
    robot.yaw = Math.atan2(-dx, -dz);
    if (dist <= remaining) {
      robot.x = target.x;
      robot.z = target.z;
      remaining -= dist;
      robot.nextIndex += 1;
    } else {
      robot.x += (dx / dist) * remaining;
      robot.z += (dz / dist) * remaining;
      remaining = 0;
    }
  }
  if (robot.nextIndex >= robot.path.length) arrive(robot);
}

export function tick(sim: Sim, dt: number): void {
  if (sim.paused || dt <= 0) return;
  let left = Math.min(dt, 2);
  while (left > 1e-6) {
    const step = Math.min(left, 0.05);
    left -= step;
    sim.elapsed += step;
    advanceDemo(sim);
    const speed = sim.reducedMotion ? 2.4 : WALK_SPEED;
    for (const robot of sim.robots) {
      if (robot.holdDemo > 0) robot.holdDemo = Math.max(0, robot.holdDemo - step);
      if (robot.phase === "getting_up") {
        robot.getUp -= step;
        if (robot.getUp <= 0) beginWalk(robot);
        continue;
      }
      if (robot.phase === "walking") moveRobot(robot, step, speed);
    }
  }
}

export function summonCoffee(sim: Sim): { ok: boolean; id?: RoleId; reason: "paused" | "busy" | "full" | "already" | "walking" } {
  if (sim.paused) return { ok: false, reason: "paused" };
  const idle = sim.robots.filter((robot) => robot.intent === "idle");
  if (!idle.length) return { ok: false, reason: "busy" };
  const away = idle.filter((robot) => !(robot.phase === "sipping" || robot.seatId?.startsWith("kitchen:")));
  const robot = away[0] ?? idle[0];
  if (robot.phase === "sipping" || robot.seatId?.startsWith("kitchen:")) {
    return { ok: true, id: robot.id, reason: "already" };
  }
  const kitchens = SEATS.filter((seat) => seat.zone === "kitchen" && !occupied(sim, seat.id, robot.id));
  if (!kitchens.length) return { ok: false, reason: "full" };
  kitchens.sort((a, b) => Math.hypot(a.x - robot.x, a.z - robot.z) - Math.hypot(b.x - robot.x, b.z - robot.z));
  const seat = kitchens[0];
  robot.destSeatId = seat.id;
  robot.destZone = "kitchen";
  robot.holdDemo = 30;
  robot.nextFlip = Math.max(robot.nextFlip, sim.elapsed + 30);
  if (robot.phase === "walking") beginWalk(robot);
  else if (robot.phase !== "getting_up") {
    robot.phase = "getting_up";
    robot.getUp = sim.reducedMotion ? 0.08 : GET_UP;
  }
  return { ok: true, id: robot.id, reason: "walking" };
}

export function robotById(sim: Sim, id: RoleId): SimRobot {
  const robot = sim.robots.find((item) => item.id === id);
  if (!robot) throw new Error(`missing ${id}`);
  return robot;
}
