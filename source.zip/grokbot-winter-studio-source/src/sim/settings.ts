export type QualityName = "low" | "standard" | "high";

export interface Settings {
  paused: boolean;
  snow: boolean;
  quality: QualityName;
  reducedMotion: boolean;
  demo: boolean;
  timeZone: string;
  previewHour: number | null;
}

export type SettingsAction =
  | { type: "toggle-pause" }
  | { type: "toggle-snow" }
  | { type: "toggle-demo" }
  | { type: "toggle-reduced" }
  | { type: "set-quality"; quality: QualityName }
  | { type: "set-zone"; timeZone: string }
  | { type: "set-preview"; hour: number }
  | { type: "clear-preview" };

export const TIME_ZONES = [
  { id: "Asia/Shanghai", label: "Shanghai" },
  { id: "Asia/Hong_Kong", label: "Hong Kong" },
  { id: "Asia/Tokyo", label: "Tokyo" },
  { id: "Asia/Singapore", label: "Singapore" },
  { id: "Europe/London", label: "London" },
  { id: "America/New_York", label: "New York" },
  { id: "UTC", label: "UTC" },
] as const;

export function initialSettings(prefersReduced: boolean): Settings {
  return {
    paused: false,
    snow: true,
    quality: "standard",
    reducedMotion: prefersReduced,
    demo: true,
    timeZone: "Asia/Shanghai",
    previewHour: 21.3,
  };
}

export function reduceSettings(state: Settings, action: SettingsAction): Settings {
  switch (action.type) {
    case "toggle-pause":
      return { ...state, paused: !state.paused };
    case "toggle-snow":
      return { ...state, snow: !state.snow };
    case "toggle-demo":
      return { ...state, demo: !state.demo };
    case "toggle-reduced":
      return { ...state, reducedMotion: !state.reducedMotion };
    case "set-quality":
      return { ...state, quality: action.quality };
    case "set-zone":
      return { ...state, timeZone: action.timeZone };
    case "set-preview":
      return { ...state, previewHour: Math.min(24, Math.max(0, action.hour)) };
    case "clear-preview":
      return { ...state, previewHour: null };
    default:
      return state;
  }
}

export function effectiveSnow(state: Settings): boolean {
  return state.snow && !state.reducedMotion;
}

export interface ClockView {
  hour: number;
  preview: boolean;
  timeZone: string;
}

function part(parts: Intl.DateTimeFormatPart[], type: Intl.DateTimeFormatPartTypes): number {
  const value = parts.find((item) => item.type === type)?.value;
  if (value == null) throw new Error(`missing ${type}`);
  return Number(value);
}

/** Wall-clock hour in a named zone. 0–24, with seconds as a fraction. */
export function hourInZone(date: Date, timeZone: string): number {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  let hour = part(parts, "hour");
  if (hour === 24) hour = 0;
  const minute = part(parts, "minute");
  const second = part(parts, "second");
  return hour + minute / 60 + second / 3600;
}

export function resolveClock(settings: Settings, now: Date): ClockView {
  if (settings.previewHour != null) {
    return { hour: settings.previewHour, preview: true, timeZone: settings.timeZone };
  }
  return { hour: hourInZone(now, settings.timeZone), preview: false, timeZone: settings.timeZone };
}

export function formatHour(hour: number): string {
  const clamped = Math.min(24, Math.max(0, hour));
  if (clamped >= 24) return "24:00";
  const total = Math.round(clamped * 60);
  const h = Math.floor(total / 60) % 24;
  const m = total % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}`;
}

export function zoneLabel(timeZone: string): string {
  return TIME_ZONES.find((zone) => zone.id === timeZone)?.label ?? timeZone;
}
