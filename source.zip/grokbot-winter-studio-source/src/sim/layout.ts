import type { RoleId } from "./roles";
import type { Vec, Zone } from "./types";

/** Body radius used for route clearance. */
export const ROBOT_R = 0.18;
/** Slightly larger radius for the navigation grid, so smoothed paths stay outside furniture. */
export const GRID_R = 0.24;
export const CELL = 0.22;

export const WALK = {
  minX: -5.02,
  maxX: 5.02,
  minZ: -3.38,
  maxZ: 3.9,
};

export const SHELL = {
  minX: -5.15,
  maxX: 5.15,
  minZ: -4.02,
  maxZ: 4.28,
  wall: 0.24,
  height: 3.05,
};

export const CHRISTMAS_TREE = { x: 0, z: 0.18, clearance: 1.30 };

export interface Block {
  id: string;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface Seat {
  id: string;
  kind: "desk" | "idle";
  zone: Zone;
  forRole?: RoleId;
  x: number;
  z: number;
  /** Robot faces local -Z. See nav comment in officeSim. */
  yaw: number;
}

const FACE_WEST = Math.PI / 2;
const FACE_EAST = -Math.PI / 2;
const FACE_BACK = Math.PI;

export const BLOCKS: Block[] = [
  { id: "desk-quant", minX: -4.22, maxX: -3.38, minZ: -3.22, maxZ: -2.12 },
  { id: "desk-backtest", minX: -4.22, maxX: -3.38, minZ: -1.42, maxZ: -0.32 },
  { id: "desk-literature", minX: -4.22, maxX: -3.38, minZ: 0.38, maxZ: 1.48 },
  { id: "desk-hr", minX: 3.38, maxX: 4.22, minZ: -3.22, maxZ: -2.12 },
  { id: "desk-secretary", minX: 3.38, maxX: 4.22, minZ: -1.42, maxZ: -0.32 },
  { id: "desk-ta", minX: 3.38, maxX: 4.22, minZ: 0.38, maxZ: 1.48 },
  { id: "desk-ceo", minX: -3.85, maxX: -2.4, minZ: 1.7, maxZ: 2.05 },
  { id: "hearth", minX: -4.7, maxX: -2.55, minZ: 3.92, maxZ: 4.22 },
  { id: "sofa", minX: -4.7, maxX: -2.7, minZ: 2.7, maxZ: 3.02 },
  { id: "counter", minX: 0.55, maxX: 5.05, minZ: 3.58, maxZ: 4.25 },
  {
    id: "christmas-tree",
    minX: CHRISTMAS_TREE.x - CHRISTMAS_TREE.clearance,
    maxX: CHRISTMAS_TREE.x + CHRISTMAS_TREE.clearance,
    minZ: CHRISTMAS_TREE.z - CHRISTMAS_TREE.clearance,
    maxZ: CHRISTMAS_TREE.z + CHRISTMAS_TREE.clearance,
  },
];

export const SEATS: Seat[] = [
  { id: "desk:ceo", kind: "desk", zone: "desk", forRole: "ceo", x: -3.12, z: 1.32, yaw: FACE_BACK },
  { id: "desk:quant", kind: "desk", zone: "desk", forRole: "quant", x: -4.72, z: -2.67, yaw: FACE_EAST },
  { id: "desk:backtest", kind: "desk", zone: "desk", forRole: "backtest", x: -4.72, z: -0.87, yaw: FACE_EAST },
  { id: "desk:literature", kind: "desk", zone: "desk", forRole: "literature", x: -4.72, z: 0.93, yaw: FACE_EAST },
  { id: "desk:hr", kind: "desk", zone: "desk", forRole: "hr", x: 4.72, z: -2.67, yaw: FACE_WEST },
  { id: "desk:secretary", kind: "desk", zone: "desk", forRole: "secretary", x: 4.72, z: -0.87, yaw: FACE_WEST },
  { id: "desk:ta", kind: "desk", zone: "desk", forRole: "ta", x: 4.72, z: 0.93, yaw: FACE_WEST },
  { id: "fire:1", kind: "idle", zone: "fire", x: -4.1, z: 3.5, yaw: FACE_BACK },
  { id: "fire:2", kind: "idle", zone: "fire", x: -3.35, z: 3.5, yaw: FACE_BACK },
  { id: "fire:3", kind: "idle", zone: "fire", x: -1.5, z: 3.42, yaw: FACE_BACK },
  { id: "fire:4", kind: "idle", zone: "fire", x: -1.9, z: 2.22, yaw: FACE_BACK },
  { id: "kitchen:1", kind: "idle", zone: "kitchen", x: 1.25, z: 3.12, yaw: FACE_BACK },
  { id: "kitchen:2", kind: "idle", zone: "kitchen", x: 2.85, z: 3.12, yaw: FACE_BACK },
  { id: "kitchen:3", kind: "idle", zone: "kitchen", x: 4.45, z: 3.12, yaw: FACE_BACK },
];

export function blockById(id: string): Block {
  const block = BLOCKS.find((item) => item.id === id);
  if (!block) throw new Error(`unknown block ${id}`);
  return block;
}

export function seatById(id: string): Seat {
  const seat = SEATS.find((item) => item.id === id);
  if (!seat) throw new Error(`unknown seat ${id}`);
  return seat;
}

export function deskSeat(role: RoleId): Seat {
  const seat = SEATS.find((item) => item.forRole === role);
  if (!seat) throw new Error(`no desk for ${role}`);
  return seat;
}

export function inWalk(x: number, z: number): boolean {
  return x >= WALK.minX && x <= WALK.maxX && z >= WALK.minZ && z <= WALK.maxZ;
}

/** Distance from a point to an AABB. 0 when the point is inside. */
export function distanceToBlock(x: number, z: number, block: Block): number {
  const nx = Math.max(block.minX, Math.min(x, block.maxX));
  const nz = Math.max(block.minZ, Math.min(z, block.maxZ));
  return Math.hypot(x - nx, z - nz);
}

export function clearance(x: number, z: number): number {
  if (!inWalk(x, z)) return 0;
  let best = Infinity;
  for (const block of BLOCKS) best = Math.min(best, distanceToBlock(x, z, block));
  return best;
}

export function pointClear(x: number, z: number, radius = ROBOT_R): boolean {
  return clearance(x, z) >= radius - 1e-6;
}

export function segmentClear(a: Vec, b: Vec, radius = ROBOT_R): boolean {
  const length = Math.hypot(b.x - a.x, b.z - a.z);
  const steps = Math.max(1, Math.ceil(length / 0.08));
  for (let i = 0; i <= steps; i += 1) {
    const t = i / steps;
    const x = a.x + (b.x - a.x) * t;
    const z = a.z + (b.z - a.z) * t;
    if (!pointClear(x, z, radius)) return false;
  }
  return true;
}

export function pathClear(path: Vec[], radius = ROBOT_R): boolean {
  if (path.length === 0) return false;
  for (const point of path) {
    if (!pointClear(point.x, point.z, radius)) return false;
  }
  for (let i = 1; i < path.length; i += 1) {
    if (!segmentClear(path[i - 1], path[i], radius)) return false;
  }
  return true;
}

/** Snow may fall on the street and neighbour roofs, never through the open office. */
export function isSnowZone(x: number, z: number): boolean {
  const overOffice = x > SHELL.minX - 0.35 && x < SHELL.maxX + 0.35 && z > SHELL.minZ - 0.2 && z < SHELL.maxZ + 0.45;
  return !overOffice;
}
