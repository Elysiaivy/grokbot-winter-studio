export type Period = "night" | "morning" | "day" | "dusk";

export interface LightRecipe {
  period: Period;
  sunIntensity: number;
  sunColor: string;
  skyTop: string;
  skyHorizon: string;
  hemiSky: string;
  hemiGround: string;
  hemiIntensity: number;
  lamp: number;
  street: number;
  fire: number;
  exposure: number;
  sunX: number;
  sunY: number;
  sunZ: number;
}

interface Frame {
  h: number;
  sun: number;
  sunColor: string;
  skyTop: string;
  skyHorizon: string;
  hemiSky: string;
  hemiGround: string;
  hemi: number;
  lamp: number;
  street: number;
  fire: number;
  exposure: number;
  sunPos: [number, number, number];
}

/**
 * Fixed winter-card keyframes for this miniature.
 * They are not a solar model: no latitude, facade bearing, or date.
 */
const FRAMES: Frame[] = [
  frame(0, 0.12, "#d5def2", "#1c2638", "#3d4a66", "#4a5874", "#c4895c", 0.62, 1, 1, 1, 1.14, [-4, 12, 6]),
  frame(5.4, 0.12, "#d5def2", "#1c2638", "#3d4a66", "#4a5874", "#c4895c", 0.62, 1, 1, 1, 1.14, [-4, 12, 6]),
  frame(6.6, 0.28, "#ffc49a", "#f0c7b4", "#f7d7c4", "#f0cbb8", "#d9b89a", 0.38, 0.78, 0.55, 0.72, 0.98, [7, 3.2, -6]),
  frame(8.2, 0.72, "#ffe0b8", "#f6d7c2", "#f3e0cf", "#f4dcc8", "#e4c7a4", 0.48, 0.48, 0.22, 0.55, 1.04, [6, 8, -6]),
  frame(10, 1.05, "#fff0d2", "#8ea4b8", "#c5d0dc", "#b7c8d6", "#c4a888", 0.42, 0.22, 0.06, 0.38, 0.82, [2, 14, -5]),
  frame(13, 1.25, "#fff3d8", "#9aafc2", "#d5e0e8", "#c5d4e0", "#c8ad8c", 0.46, 0.16, 0.04, 0.34, 0.76, [0.4, 16.5, -4.5]),
  frame(15.6, 1.05, "#ffd7a4", "#b08978", "#e2c2ae", "#e0b89a", "#b89070", 0.4, 0.4, 0.28, 0.5, 0.84, [-3, 9, -5]),
  frame(17.1, 0.48, "#ff7a3d", "#5c6578", "#c4896e", "#d9a088", "#a87858", 0.34, 0.86, 0.92, 0.9, 0.86, [-8, 3.1, -2.5]),
  frame(18.7, 0.18, "#d0b8d8", "#2a3148", "#c98a78", "#5a4a58", "#b07a58", 0.5, 0.98, 1, 1, 1.05, [-5, 7, 4]),
  frame(21, 0.12, "#d5def2", "#1c2638", "#3d4a66", "#4a5874", "#c4895c", 0.62, 1, 1, 1, 1.14, [-3, 11, 6]),
  frame(24, 0.12, "#d5def2", "#1c2638", "#3d4a66", "#4a5874", "#c4895c", 0.62, 1, 1, 1, 1.14, [-4, 12, 6]),
];

function frame(
  h: number,
  sun: number,
  sunColor: string,
  skyTop: string,
  skyHorizon: string,
  hemiSky: string,
  hemiGround: string,
  hemi: number,
  lamp: number,
  street: number,
  fire: number,
  exposure: number,
  sunPos: [number, number, number],
): Frame {
  return { h, sun, sunColor, skyTop, skyHorizon, hemiSky, hemiGround, hemi, lamp, street, fire, exposure, sunPos };
}

function clampHour(hour: number): number {
  const wrapped = ((hour % 24) + 24) % 24;
  return wrapped === 0 && hour >= 24 ? 24 : wrapped;
}

export function periodForHour(hour: number): Period {
  const h = ((hour % 24) + 24) % 24;
  if (h >= 6 && h < 9) return "morning";
  if (h >= 9 && h < 16.5) return "day";
  if (h >= 16.5 && h < 19) return "dusk";
  return "night";
}

export function periodLabel(period: Period): string {
  switch (period) {
    case "morning":
      return "Morning";
    case "day":
      return "Day";
    case "dusk":
      return "Dusk";
    case "night":
      return "Night";
  }
}

function hexToRgb(hex: string): [number, number, number] {
  const value = hex.replace("#", "");
  return [
    Number.parseInt(value.slice(0, 2), 16),
    Number.parseInt(value.slice(2, 4), 16),
    Number.parseInt(value.slice(4, 6), 16),
  ];
}

export function mixHex(a: string, b: string, t: number): string {
  const [ar, ag, ab] = hexToRgb(a);
  const [br, bg, bb] = hexToRgb(b);
  const r = Math.round(ar + (br - ar) * t);
  const g = Math.round(ag + (bg - ag) * t);
  const bch = Math.round(ab + (bb - ab) * t);
  return `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${bch.toString(16).padStart(2, "0")}`;
}

export function colorDistance(a: string, b: string): number {
  const [ar, ag, ab] = hexToRgb(a);
  const [br, bg, bb] = hexToRgb(b);
  return Math.hypot(ar - br, ag - bg, ab - bb);
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export function lightingForHour(hour: number): LightRecipe {
  const h = clampHour(hour);
  let upper = FRAMES[FRAMES.length - 1];
  let lower = FRAMES[0];
  for (let i = 1; i < FRAMES.length; i += 1) {
    if (h <= FRAMES[i].h) {
      upper = FRAMES[i];
      lower = FRAMES[i - 1];
      break;
    }
  }
  const span = upper.h - lower.h || 1;
  const t = Math.min(1, Math.max(0, (h - lower.h) / span));
  return {
    period: periodForHour(h === 24 ? 0 : h),
    sunIntensity: lerp(lower.sun, upper.sun, t),
    sunColor: mixHex(lower.sunColor, upper.sunColor, t),
    skyTop: mixHex(lower.skyTop, upper.skyTop, t),
    skyHorizon: mixHex(lower.skyHorizon, upper.skyHorizon, t),
    hemiSky: mixHex(lower.hemiSky, upper.hemiSky, t),
    hemiGround: mixHex(lower.hemiGround, upper.hemiGround, t),
    hemiIntensity: lerp(lower.hemi, upper.hemi, t),
    lamp: lerp(lower.lamp, upper.lamp, t),
    street: lerp(lower.street, upper.street, t),
    fire: lerp(lower.fire, upper.fire, t),
    exposure: lerp(lower.exposure, upper.exposure, t),
    sunX: lerp(lower.sunPos[0], upper.sunPos[0], t),
    sunY: lerp(lower.sunPos[1], upper.sunPos[1], t),
    sunZ: lerp(lower.sunPos[2], upper.sunPos[2], t),
  };
}
