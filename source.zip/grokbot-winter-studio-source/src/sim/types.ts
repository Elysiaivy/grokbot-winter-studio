export type Intent = "busy" | "idle";

export type Phase = "working" | "getting_up" | "walking" | "sipping" | "seated_fire";

export type Zone = "desk" | "kitchen" | "fire";

export interface Vec {
  x: number;
  z: number;
}

export interface RobotSnapshot {
  id: string;
  intent: Intent;
  phase: Phase;
  destZone: Zone | null;
  x: number;
  z: number;
  yaw: number;
  seatId: string | null;
}
