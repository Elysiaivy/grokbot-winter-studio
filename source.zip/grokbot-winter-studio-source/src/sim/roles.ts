export const ROLES = [
  {
    id: "ceo",
    name: "CEO",
    short: "CEO",
    prefer: "fire",
    iris: "#8a5a2a",
    cloth: "#6e2c3a",
  },
  {
    id: "quant",
    name: "Quant Researcher",
    short: "Quant",
    prefer: "kitchen",
    iris: "#2a6f8f",
    cloth: "#1e3f36",
  },
  {
    id: "backtest",
    name: "Backtest Engineer",
    short: "Backtest",
    prefer: "kitchen",
    iris: "#5c6b8a",
    cloth: "#3a3e46",
  },
  {
    id: "literature",
    name: "Research Archivist",
    short: "Archive",
    prefer: "fire",
    iris: "#3d6b4f",
    cloth: "#c4a07a",
  },
  {
    id: "hr",
    name: "HR",
    short: "HR",
    prefer: "fire",
    iris: "#8d5a3c",
    cloth: "#efe4d4",
  },
  {
    id: "secretary",
    name: "Secretary",
    short: "Secretary",
    prefer: "kitchen",
    iris: "#c47b4a",
    cloth: "#243044",
  },
  {
    id: "ta",
    name: "Teaching Assistant",
    short: "Teaching",
    prefer: "fire",
    iris: "#2f6a4a",
    cloth: "#c46a4a",
  },
] as const;

export type RoleId = (typeof ROLES)[number]["id"];

export function roleById(id: string) {
  const role = ROLES.find((item) => item.id === id);
  if (!role) throw new Error(`unknown role ${id}`);
  return role;
}
