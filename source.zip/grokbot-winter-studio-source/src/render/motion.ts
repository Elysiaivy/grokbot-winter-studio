import {
  BoxGeometry, CanvasTexture, ConeGeometry, CylinderGeometry, DoubleSide, Group, Mesh,
  MeshStandardMaterial, PlaneGeometry, SRGBColorSpace, Vector3, type Object3D,
} from "three";
import type { RoleId } from "../sim/roles";
import { matte } from "./factory";

export interface DeskActionRig {
  root: Object3D;
  left: Vector3;
  right: Vector3;
  page?: TurningPage;
}

export const deskActions = {
  ceo: "writing",
  quant: "typing",
  backtest: "typing",
  literature: "reading",
  hr: "stamping",
  secretary: "planning",
  ta: "teaching",
} as const satisfies Record<RoleId, string>;

export type RobotAction = (typeof deskActions)[RoleId] | "sipping" | "carrying" | "walking" | "rest";

export function smoothStep(from: number, to: number, value: number): number {
  const t = Math.min(1, Math.max(0, (value - from) / (to - from)));
  return t * t * (3 - 2 * t);
}

interface TurningPage {
  pivot: Group;
  update: (progress: number) => void;
  getGrip: (out: Vector3) => Vector3;
}

export function buildTurningPage(width: number, depth: number, material: MeshStandardMaterial, direction: -1 | 1): TurningPage {
  const pivot = new Group();
  pivot.visible = false;
  pivot.userData.keep = true;
  const leaf = new PlaneGeometry(width, depth, 8, 3);
  leaf.rotateX(-Math.PI / 2);
  leaf.translate(direction * width / 2, 0, 0);
  const position = leaf.getAttribute("position");
  const spineDistance = Array.from({ length: position.count }, (_, index) => Math.abs(position.getX(index)) / width);
  pivot.add(new Mesh(leaf, material));
  const gripZ = direction * depth * 0.46;
  let curl = 0;
  let lastProgress = -1;

  function point(u: number, z: number, out: Vector3): Vector3 {
    const bend = curl * u * u;
    const nearCorner = 0.76 + direction * z / depth * 0.48;
    return out.set(direction * (width * u - bend * 0.18), bend * nearCorner, z);
  }

  const vertex = new Vector3();
  return {
    pivot,
    update(progress) {
      if (progress === lastProgress) return;
      lastProgress = progress;
      pivot.visible = progress > 0 && progress < 1;
      const turn = smoothStep(0.12, 0.98, progress);
      pivot.rotation.z = direction * turn * Math.PI;
      // The loose corner lifts before the sheet starts turning at the binding.
      curl = width * 0.46 * (smoothStep(0, 0.24, progress) - smoothStep(0.32, 1, progress)) * (1 - turn);
      for (let index = 0; index < position.count; index += 1) {
        point(spineDistance[index], position.getZ(index), vertex);
        position.setXYZ(index, vertex.x, vertex.y, vertex.z);
      }
      position.needsUpdate = true;
      leaf.computeVertexNormals();
    },
    getGrip(out) {
      return pivot.localToWorld(point(0.99, gripZ, out));
    },
  };
}

export function buildHeldBook(): { root: Group; page: TurningPage } {
  const root = new Group();
  root.position.set(0, 0.155, -0.273);
  root.rotation.x = 0.38;
  root.visible = false;
  const cover = matte("#284a44", 0.67);
  const paper = matte("#e4d2a6", 0.78);
  const foil = matte("#c79856", 0.49, 0.48);

  const canvas = document.createElement("canvas");
  canvas.width = 96;
  canvas.height = 144;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Could not draw the book pages.");
  context.fillStyle = "#f1e2bd";
  context.fillRect(0, 0, 96, 144);
  context.fillStyle = "#a45f45";
  context.fillRect(15, 20, 59, 3);
  context.fillStyle = "#8c8070";
  for (let line = 0; line < 10; line += 1) context.fillRect(15, 37 + line * 8, line % 4 === 3 ? 39 : 62, 2);
  const map = new CanvasTexture(canvas);
  map.colorSpace = SRGBColorSpace;
  const print = new MeshStandardMaterial({ map, side: DoubleSide, roughness: 0.88, forceSinglePass: true });
  const leaf = new PlaneGeometry(0.145, 0.22);

  for (const side of [-1, 1]) {
    place(root, new BoxGeometry(0.157, 0.013, 0.239), cover, side * 0.078, -0.011, 0);
    place(root, new BoxGeometry(0.147, 0.016, 0.226), paper, side * 0.075, 0.003, 0);
    place(root, leaf, print, side * 0.074, 0.012, 0).rotation.x = -Math.PI / 2;
  }
  place(root, new BoxGeometry(0.015, 0.01, 0.24), foil, 0, -0.016, 0);
  const page = buildTurningPage(0.147, 0.22, print, 1);
  page.pivot.position.y = 0.014;
  root.add(page.pivot);
  return { root, page };
}

export function buildDeskTool(role: RoleId): Group | undefined {
  if (role !== "ceo" && role !== "hr" && role !== "secretary" && role !== "ta") return;
  const holder = new Group();
  holder.visible = false;
  const brass = matte("#dcb462", 0.42, 0.47);
  if (role === "hr") {
    place(holder, new CylinderGeometry(0.034, 0.036, 0.034, 10), matte("#9e4759", 0.57), 0, -0.026, -0.028);
    place(holder, new CylinderGeometry(0.053, 0.055, 0.027, 12), brass, 0, -0.056, -0.028);
  } else {
    const color = role === "ta" ? "#f3ebd3" : "#b16a43";
    holder.rotation.x = -0.54;
    place(holder, new CylinderGeometry(0.011, 0.011, 0.129, 6), matte(color, 0.65), 0.017, 0.003, -0.028);
    const tip = place(holder, new ConeGeometry(0.012, 0.027, 6), brass, 0.017, -0.071, -0.028);
    tip.rotation.x = Math.PI;
  }
  return holder;
}

function place(root: Group, geometry: BoxGeometry | PlaneGeometry | CylinderGeometry | ConeGeometry, material: MeshStandardMaterial, x: number, y: number, z: number): Mesh {
  const mesh = new Mesh(geometry, material);
  mesh.position.set(x, y, z);
  root.add(mesh);
  return mesh;
}
