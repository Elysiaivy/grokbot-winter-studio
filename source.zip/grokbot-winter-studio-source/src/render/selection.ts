import { InstancedMesh, Mesh, Raycaster, type Camera, type Object3D, type Scene, type Vector2 } from "three";
import type { RoleId } from "../sim/roles";
import type { RobotRig } from "./robots";

export type SceneHit =
  | { type: "robot" | "workstation"; id: RoleId }
  | { type: "hotspot"; name: string }
  | { type: "ground" | "background" | "object" | "reading" };

export function createScenePicker(scene: Scene, getCamera: () => Camera, robots: readonly RobotRig[]): (position: Vector2) => SceneHit {
  const raycaster = new Raycaster();
  const roles = new Set(robots.map((robot) => robot.id));
  const robotRoots = new Map<Object3D, RoleId>();
  const robotInstances = new Map<InstancedMesh, Map<number, RoleId>>();
  for (const robot of robots) {
    robotRoots.set(robot.group, robot.id);
    for (const { batch, index } of robot.slots) {
      let roles = robotInstances.get(batch);
      if (!roles) {
        roles = new Map();
        robotInstances.set(batch, roles);
      }
      roles.set(index, robot.id);
    }
  }

  return (position) => {
    const camera = getCamera();
    camera.updateMatrixWorld();
    scene.updateMatrixWorld();
    raycaster.layers.mask = camera.layers.mask;
    raycaster.setFromCamera(position, camera);

    // Instance transforms change as the bots move, so a cached pick bound can miss a limb.
    for (const batch of robotInstances.keys()) batch.computeBoundingSphere();

    hits: for (const { object, face, instanceId } of raycaster.intersectObjects(scene.children, true)) {
      if (!(object instanceof Mesh)) continue;
      const material = Array.isArray(object.material) ? object.material[face?.materialIndex ?? 0] : object.material;
      if (!material?.visible) continue;

      let hotspot: string | undefined;
      let robot: RoleId | undefined;
      let reading = false;
      let ground = material.userData.selectionGround === true;
      for (let node: Object3D | null = object; node; node = node.parent) {
        if (!node.visible || node.userData.selectionIgnore === true || node.name === "falling-snow") continue hits;
        if (node.name.startsWith("hotspot-")) hotspot ??= node.name;
        reading ||= node.name === "reading-loft" || node.name === "upper-storey-walls";
        robot ??= robotRoots.get(node);
        ground ||= node.userData.selectionGround === true;
      }

      if (hotspot) return { type: "hotspot", name: hotspot };
      if (material.transparent) continue;
      if (reading) return { type: "reading" };
      if (instanceId !== undefined && object instanceof InstancedMesh) {
        robot ??= robotInstances.get(object)?.get(instanceId);
      }
      if (robot) return { type: "robot", id: robot };
      const workstation = material.userData.selectionWorkstation as RoleId | undefined;
      if (workstation && roles.has(workstation)) return { type: "workstation", id: workstation };
      return { type: ground ? "ground" : "object" };
    }

    return { type: "background" };
  };
}
