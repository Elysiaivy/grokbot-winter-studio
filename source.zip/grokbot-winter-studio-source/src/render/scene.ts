import {
  BoxGeometry,
  BufferGeometry,
  CanvasTexture,
  CatmullRomCurve3,
  Color,
  ConeGeometry,
  CylinderGeometry,
  DirectionalLight,
  DoubleSide,
  ExtrudeGeometry,
  Float32BufferAttribute,
  Fog,
  Group,
  HemisphereLight,
  InstancedMesh,
  LatheGeometry,
  Mesh,
  MeshStandardMaterial,
  Object3D,
  OrthographicCamera,
  PCFSoftShadowMap,
  PlaneGeometry,
  PMREMGenerator,
  PointLight,
  Shape,
  ShapeGeometry,
  SphereGeometry,
  SRGBColorSpace,
  TorusGeometry,
  TubeGeometry,
  Vector2,
  Vector3,
  WebGLRenderer,
  Scene,
} from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import type { LightRecipe } from "../sim/lighting";
import { CHRISTMAS_TREE, SEATS, SHELL, blockById, isSnowZone, type Seat } from "../sim/layout";
import { roleById, type RoleId } from "../sim/roles";
import type { QualityName } from "../sim/settings";
import {
  fork,
  makeBookAtlas,
  makeBrickTexture,
  makeChartTexture,
  makeClothTexture,
  makeKeyboardMaterial,
  makeLabelTexture,
  makeNoteTexture,
  makePlasterTexture,
  makeRugTexture,
  makeSignTexture,
  makeSlateTexture,
  makeWindowGlass,
  makeWoodTexture,
  matte,
  textured,
  tuneTextures,
} from "./factory";
import { buildWinterStreetscape, makeWinterRoad, PLINTH_CENTER_Z, PLINTH_SIZE } from "./exterior";
import { buildHearthFire } from "./hearth";
import { mergeStatic } from "./merge";
import { buildRobots, robotSurface, type RobotRig } from "./robots";
import { createFinish } from "./finish";
import type { CameraShot } from "./focus";
import { buildTurningPage, type DeskActionRig } from "./motion";
import { DESK_FINISH, makeDeskPaper } from "./workstations";

const geoCache = new Map<string, RoundedBoxGeometry | ReturnType<typeof boxFallback>>();

function boxFallback(w: number, h: number, d: number) {
  return new RoundedBoxGeometry(Math.max(w, 0.02), Math.max(h, 0.02), Math.max(d, 0.02), 1, 0.001);
}

function rbox(w: number, h: number, d: number, radius = 0.04, seg = 2) {
  const maxR = Math.min(w, h, d) * 0.5 - 1e-4;
  const rr = Math.min(radius, Math.max(0.001, maxR));
  const key = `${w.toFixed(3)}|${h.toFixed(3)}|${d.toFixed(3)}|${rr.toFixed(3)}|${seg}`;
  let geo = geoCache.get(key);
  if (!geo) {
    geo = maxR < 0.012 ? boxFallback(w, h, d) : new RoundedBoxGeometry(w, h, d, seg, rr);
    geoCache.set(key, geo);
  }
  return geo;
}

interface PutOpts {
  cast?: boolean;
  receive?: boolean;
  ry?: number;
  rx?: number;
  rz?: number;
}

function put(parent: Object3D, geometry: ConstructorParameters<typeof Mesh>[0], material: ConstructorParameters<typeof Mesh>[1], x: number, y: number, z: number, opts: PutOpts = {}): Mesh {
  const item = new Mesh(geometry, material);
  item.position.set(x, y, z);
  if (opts.ry) item.rotation.y = opts.ry;
  if (opts.rx) item.rotation.x = opts.rx;
  if (opts.rz) item.rotation.z = opts.rz;
  item.castShadow = Boolean(opts.cast);
  item.receiveShadow = Boolean(opts.receive);
  parent.add(item);
  return item;
}

export interface OfficeView {
  scene: Scene;
  camera: OrthographicCamera;
  controls: OrbitControls;
  overviewShot: CameraShot;
  robots: RobotRig[];
  workstations: ReadonlyMap<RoleId, DeskActionRig>;
  resetCamera: () => void;
  setView: (name: "overall" | "interior" | "street") => void;
  toggleDoor: () => boolean;
  toggleStringLights: () => boolean;
  setRoof: (on: boolean) => void;
  roofVisible: () => boolean;
  setFrontWall: (visible: boolean) => void;
  pulseSteam: () => void;
  render: () => void;
  resize: (width: number, height: number) => void;
  updateLighting: (recipe: LightRecipe, renderer: WebGLRenderer) => void;
  updateSnow: (dt: number, visible: boolean) => void;
  snowState: { visible: boolean; count: number; trackedY: number };
  setQuality: (quality: QualityName, renderer: WebGLRenderer, dprScale: number) => void;
  setReducedMotion: (reduced: boolean) => void;
  setClock: (hour: number) => void;
  tickFire: (dt: number, reduced: boolean, amount: number) => void;
}

export function createOffice(canvas: HTMLCanvasElement, renderer: WebGLRenderer): OfficeView {
  const bookCache = new Map<string, BufferGeometry>();
  const workstations = new Map<RoleId, DeskActionRig>();
  let keyboardGeo: BufferGeometry | null = null;
  tuneTextures(Math.min(8, renderer.capabilities.getMaxAnisotropy()));
  const pmrem = new PMREMGenerator(renderer);
  const env = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  pmrem.dispose();
  const woodTex = makeWoodTexture();
  const brickTex = makeBrickTexture();
  const plasterTex = makePlasterTexture();
  const wood = textured(woodTex, 0.55, 2, 2);
  const woodDark = matte("#5c3b34", 0.52);
  const plaster = textured(plasterTex, 0.9, 2, 2);
  const brick = textured(brickTex, 0.78, 2.4, 2);
  const floorMat = textured(woodTex, 0.68, 1.5, 1.35);
  const rugA = textured(makeRugTexture("#6d3a42", "#e6d4bc"), 0.96, 1, 1);
  const rugB = textured(makeRugTexture("#2f4e40", "#e4d8c4"), 0.96, 1, 1);
  for (const material of [floorMat, rugA, rugB]) material.userData.selectionGround = true;
  const cloth = textured(makeClothTexture(), 0.92, 1, 1);
  const slate = textured(makeSlateTexture(), 0.9, 2.6, 2.4);
  slate.metalness = 0.08;
  const books = new MeshStandardMaterial({ map: makeBookAtlas(), roughness: 0.74, metalness: 0 });
  const keys = makeKeyboardMaterial();
  const lineChart = makeChartTexture("line", "SIGNALS", "#88dbb7", "#193035");
  const barChart = makeChartTexture("bars", "RUN LOG", "#bdb0ff", "#25293e");
  const screenMat = new Map<CanvasTexture, MeshStandardMaterial>();
  const fabric = matte("#f4efe6", 0.86);
  const pineFabric = matte("#2c5a45", 0.84);
  const gold = matte("#e0b15a", 0.32, 0.7);
  const metal = matte("#5e656c", 0.35, 0.65);
  const leaf = matte("#3f6b4a", 0.7);
  const leafDark = matte("#234936", 0.75);
  const potMat = matte("#c47b4a", 0.6);
  const fairy = matte("#ffe6bf");
  fairy.emissive.set("#ffd7a1");
  fairy.emissiveIntensity = 0.8;
  const treeFairy = fork(fairy);
  treeFairy.emissive.set("#ffd295");
  const bulb = matte("#fff1d2");
  bulb.emissive.set("#ffd9a0");
  bulb.emissiveIntensity = 0.2;
  const shade = matte("#f6e7c8", 0.7);
  shade.emissive.set("#ffc98a");
  shade.emissiveIntensity = 0.15;
  const pineTrim = matte("#24363e", 0.48, 0.1);
  const cutEdge = matte("#b78b68", 0.56);
  const aquaEnamel = new MeshStandardMaterial({ color: "#9be2e5", emissive: "#65dce6", emissiveIntensity: 0.95, roughness: 0.33 });
  const snowCeramic = matte("#e0edf9", 0.76);
  const garlandGreen = matte("#315848", 0.79);
  const cherryRed = matte("#a73854", 0.37, 0.12);

  const scene = new Scene();
  let doorOpen = false;
  let stringLights = true;
  let treeLampAmount = 1;
  let steamLeft = 0;
  const frontWall = new Group();
  frontWall.userData.keep = true;
  scene.add(frontWall);
  const doorPivot = new Group();
  doorPivot.name = "hotspot-door";
  const roofSlab = new Group();
  roofSlab.name = "roof-slab";
  roofSlab.visible = false;
  const steam = new Group();
  steam.name = "steam";
  steam.visible = false;
  scene.environment = env;
  scene.environmentIntensity = 0.44;
  const sky = new Color("#242c47");
  scene.background = sky;
  const fog = new Fog(sky, 37, 70);
  scene.fog = fog;

  const hemi = new HemisphereLight("#d5e7f6", "#e7d3b0", 0.6);
  scene.add(hemi);
  const sun = new DirectionalLight("#fff3d8", 1.2);
  sun.position.set(2, 14, -6);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.near = 0.4;
  sun.shadow.camera.far = 70;
  sun.shadow.camera.left = -12;
  sun.shadow.camera.right = 12;
  sun.shadow.camera.top = 12;
  sun.shadow.camera.bottom = -12;
  sun.shadow.bias = -0.0006;
  sun.shadow.normalBias = 0.02;
  sun.shadow.autoUpdate = false;
  sun.shadow.needsUpdate = true;
  sun.target.position.set(0, 0.6, -2);
  let shadowKey = "";
  scene.add(sun, sun.target);
  const blueRim = new DirectionalLight("#829cff", 0.42);
  blueRim.position.set(6, 8, 7);
  scene.add(blueRim);

  const kitchenLight = new PointLight("#ffd0a0", 0.4, 6, 2);
  kitchenLight.position.set(2.9, 2.15, 3.5);
  const corridorLight = new PointLight("#ffe0bf", 0.3, 7, 2);
  corridorLight.position.set(0.1, 2.35, 0.15);
  const streetL = new PointLight("#ffc98a", 0.2, 7, 2);
  streetL.position.set(-6.38, 2.09, -5.77);
  const streetR = new PointLight("#ffc98a", 0.2, 7, 2);
  streetR.position.set(6.38, 2.09, -5.77);
  const treeLight = new PointLight("#ffd7a8", 0.25, 4.5, 2);
  treeLight.position.set(CHRISTMAS_TREE.x, 1.67, CHRISTMAS_TREE.z);
  const fill = new PointLight("#ffe7c8", 0.22, 14, 2);
  fill.position.set(0.2, 3.6, 0.2);
  const deskLamps = [
    new PointLight("#ffd7a4", 0.2, 3.2, 2),
    new PointLight("#ffd7a4", 0.2, 3.2, 2),
    new PointLight("#ffd7a4", 0.2, 3.2, 2),
    new PointLight("#ffd7a4", 0.2, 3.2, 2),
  ];
  deskLamps[0].position.set(-3.7, 1.35, -2.6);
  deskLamps[1].position.set(-3.7, 1.35, 0.9);
  deskLamps[2].position.set(3.7, 1.35, -0.9);
  deskLamps[3].position.set(-3.1, 1.35, 1.9);
  scene.add(kitchenLight, corridorLight, streetL, streetR, treeLight, fill, ...deskLamps);

  buildShell();
  buildStreet();
  const streetscape = buildWinterStreetscape();
  scene.add(streetscape.root);
  const fire = buildLounge();
  buildKitchen();
  buildWork();
  buildTree();
  buildFrontDressing();
  buildBackWall();
  const clockHands = buildClock();
  const snow = buildSnow();
  const robots = buildRobots();
  for (const rig of robots) scene.add(rig.group);
  scene.add(robotSurface());
  mergeStatic(roofSlab);
  mergeStatic(doorPivot);
  mergeStatic(frontWall);
  const coffee = scene.getObjectByName("hotspot-coffee");
  if (coffee) mergeStatic(coffee);
  mergeStatic(scene);
  scene.traverse((obj) => {
    if (!(obj instanceof Mesh)) return;
    if (!obj.geometry.boundingSphere) obj.geometry.computeBoundingSphere();
    const radius = obj.geometry.boundingSphere?.radius ?? 1;
    if (radius < 0.2) obj.castShadow = false;
  });

  const camera = new OrthographicCamera(-13, 13, 8.5, -8.5, 0.1, 75);
  const finish = createFinish(renderer, camera);
  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.11;
  controls.rotateSpeed = 0.5;
  controls.zoomSpeed = 0.75;
  controls.panSpeed = 0.72;
  controls.minZoom = 0.74;
  controls.maxZoom = 9;
  controls.minPolarAngle = 0.15;
  controls.maxPolarAngle = 1.45;
  const shots = {
    overall: { p: new Vector3(11.8, 21.1, -20.9), t: new Vector3(0, 0.02, -1.75), z: 1 },
    interior: { p: new Vector3(7.5, 17, -14), t: new Vector3(0, 0.95, 0.2), z: 1.82 },
    street: { p: new Vector3(5.4, 6.2, -23), t: new Vector3(0, 1.08, -4.75), z: 1.25 },
  };

  function resize(width: number, height: number): void {
    const aspect = Math.max(width, 1) / Math.max(height, 1);
    const halfHeight = Math.max(9, 12.6 / aspect);
    camera.top = halfHeight;
    camera.bottom = -halfHeight;
    camera.left = -halfHeight * aspect;
    camera.right = halfHeight * aspect;
    camera.updateProjectionMatrix();
    finish.resize();
  }

  function applyView(name: keyof typeof shots): void {
    const shot = shots[name];
    const damping = controls.enableDamping;
    controls.enableDamping = false;
    controls.update();
    camera.position.copy(shot.p);
    controls.target.copy(shot.t);
    camera.zoom = shot.z;
    camera.updateProjectionMatrix();
    controls.update();
    controls.enableDamping = damping;
  }

  function resetCamera(): void {
    applyView("overall");
  }

  applyView("overall");

  let fireTime = 0;

  return {
    scene,
    camera,
    controls,
    overviewShot: shots.overall,
    robots,
    workstations,
    resetCamera,
    setView: applyView,
    toggleDoor: () => {
      doorOpen = !doorOpen;
      doorPivot.rotation.y = doorOpen ? -0.95 : -0.02;
      sun.shadow.needsUpdate = true;
      return doorOpen;
    },
    toggleStringLights: () => {
      stringLights = !stringLights;
      updateTreeLights();
      return stringLights;
    },
    setRoof: (on: boolean) => {
      roofSlab.visible = on;
      sun.shadow.needsUpdate = true;
    },
    roofVisible: () => roofSlab.visible,
    setFrontWall(visible) {
      if (frontWall.visible === visible) return;
      frontWall.visible = visible;
      sun.shadow.needsUpdate = true;
    },
    render: () => finish.render(scene),
    pulseSteam: () => {
      steamLeft = 2.4;
      steam.visible = true;
    },
    resize,
    updateLighting(recipe, renderer) {
      const nextShadow = `${recipe.sunX.toFixed(2)}|${recipe.sunY.toFixed(2)}|${recipe.sunZ.toFixed(2)}|${recipe.sunIntensity.toFixed(2)}`;
      if (nextShadow !== shadowKey) {
        sun.shadow.needsUpdate = true;
        shadowKey = nextShadow;
      }
      const night = recipe.period === "night";
      sky.set(night ? "#29324c" : recipe.skyTop);
      finish.backdrop.copy(sky);
      fog.color.copy(sky);
      sun.color.set(night ? "#a8c9ff" : recipe.sunColor);
      sun.intensity = night ? 0.69 : recipe.sunIntensity;
      sun.position.set(night ? -6 : recipe.sunX, night ? 12 : recipe.sunY, night ? -8 : recipe.sunZ);
      blueRim.intensity = night ? 0.43 : 0.12;
      hemi.color.set(night ? "#b0c8ee" : recipe.hemiSky);
      hemi.groundColor.set(night ? "#a68081" : recipe.hemiGround);
      hemi.intensity = night ? 0.77 : recipe.hemiIntensity;
      kitchenLight.intensity = recipe.lamp * 5.2;
      corridorLight.intensity = 0.08 + recipe.lamp * 7.8;
      streetL.intensity = recipe.street * 6.4;
      streetR.intensity = recipe.street * 6.4;
      streetscape.setStreetLight(recipe.street);
      fill.intensity = 0.2 + recipe.lamp * 4.7;
      fill.color.set(recipe.period === "day" || recipe.period === "morning" ? "#fff6e8" : "#ffd8b0");
      for (const lamp of deskLamps) lamp.intensity = 0.15 + recipe.lamp * 2.8;
      bulb.emissiveIntensity = 0.15 + recipe.street * 1.3;
      shade.emissiveIntensity = 0.12 + recipe.lamp * 0.85;
      fairy.emissiveIntensity = 0.55 + recipe.lamp * 1.25;
      treeLampAmount = recipe.lamp;
      updateTreeLights();
      renderer.toneMappingExposure = night ? 1.05 : recipe.exposure;
    },
    get snowState() {
      return { visible: snow.mesh.visible, count: snow.mesh.visible ? snow.mesh.count : 0, trackedY: snow.parts[0].y };
    },
    updateSnow(dt, visible) {
      snow.mesh.visible = visible;
      if (!visible || dt <= 0) return;
      const count = snow.mesh.count;
      for (let i = 0; i < count; i += 1) {
        const flake = snow.parts[i];
        flake.y -= flake.v * dt;
        flake.x += Math.sin(flake.y * 2 + i) * 0.08 * dt;
        if (flake.y < -0.1 || Math.abs(flake.x) > 8.35 || !isSnowZone(flake.x, flake.z)) {
          const next = snow.spawn(3.4 + Math.random() * 1.4);
          flake.x = next.x;
          flake.y = next.y;
          flake.z = next.z;
        }
        snow.dummy.position.set(flake.x, flake.y, flake.z);
        snow.dummy.scale.setScalar(flake.s);
        snow.dummy.updateMatrix();
        snow.mesh.setMatrixAt(i, snow.dummy.matrix);
      }
      snow.mesh.instanceMatrix.needsUpdate = true;
    },
    setQuality(quality, renderer, dprScale) {
      const cap = quality === "high" ? 1.75 : quality === "low" ? 1 : 1.35;
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, cap) * dprScale);
      finish.setAntialias(quality !== "low");
      const size = quality === "high" ? 2048 : quality === "standard" ? 1024 : 0;
      renderer.shadowMap.enabled = size > 0;
      sun.castShadow = size > 0;
      if (size > 0) {
        sun.shadow.mapSize.set(size, size);
        sun.shadow.map?.dispose();
        sun.shadow.map = null;
        sun.shadow.needsUpdate = true;
        shadowKey = "";
      }
      snow.mesh.count = quality === "low" ? 70 : quality === "high" ? 160 : 110;
    },
    setReducedMotion(reduced) {
      controls.enableDamping = !reduced;
    },
    setClock(hour) {
      const wrapped = ((hour % 24) + 24) % 24;
      const minutes = (wrapped % 1) * 60;
      const hour12 = wrapped % 12;
      clockHands.hour.rotation.z = -(hour12 / 12) * Math.PI * 2;
      clockHands.minute.rotation.z = -(minutes / 60) * Math.PI * 2;
    },
    tickFire(dt, reduced, amount) {
      if (steamLeft > 0) {
        steamLeft = Math.max(0, steamLeft - dt);
        steam.visible = steamLeft > 0;
        steam.children.forEach((child, index) => {
          const rise = reduced ? 0.2 : ((2.4 - steamLeft) * 0.35 + index * 0.18) % 0.8;
          child.position.y = 0.12 + rise;
          const mat = (child as Mesh).material as MeshStandardMaterial;
          mat.opacity = steamLeft > 0.05 ? 0.12 + (1 - rise) * 0.2 : 0;
        });
      }
      fireTime += dt;
      fire.update(fireTime, reduced, amount);
    },
  };

  function updateTreeLights(): void {
    treeFairy.emissiveIntensity = stringLights ? 0.65 + treeLampAmount * 1.85 : 0.02;
    treeLight.intensity = stringLights ? 0.25 + treeLampAmount * 2.4 : 0.05;
  }

  function buildShell(): void {
    const w = SHELL.maxX - SHELL.minX;
    const d = SHELL.maxZ - SHELL.minZ;
    const cx = (SHELL.minX + SHELL.maxX) / 2;
    const cz = (SHELL.minZ + SHELL.maxZ) / 2;
    put(scene, rbox(w, 0.16, d, 0.02, 1), floorMat, cx, -0.08, cz, { receive: true });
    put(scene, rbox(3.5, 0.016, 2.35, 0.05, 1), rugA, -3.2, 0.022, 2.5, { receive: true });
    put(scene, rbox(1.7, 0.012, 1.15, 0.04, 1), rugB, -3.45, 0.036, 2.95, { receive: true, ry: -0.12 });

    const wallH = SHELL.height;
    const sideGlass = makeWindowGlass();
    for (const side of [-1, 1]) {
      const edge = side * SHELL.maxX;
      const back = 2.5;
      buildSideWindows(edge, side, back, wallH, sideGlass);
      sideWall(edge, side, back, SHELL.maxZ + 0.22, wallH);
    }
    put(scene, rbox(w + 0.5, wallH, 0.16, 0.02, 1), brick, cx, wallH / 2, SHELL.maxZ + 0.16, { cast: true, receive: true });
    put(scene, rbox(w, wallH, 0.1, 0.02, 1), plaster, cx, wallH / 2, SHELL.maxZ - 0.05, { receive: true });
    put(scene, rbox(w + 0.5, 0.11, 0.28, 0.02, 1), pineTrim, cx, wallH + 0.04, SHELL.maxZ + 0.06);
    put(scene, rbox(w + 0.22, 0.06, 0.21, 0.025, 2), snowCeramic, cx, wallH + 0.124, SHELL.maxZ + 0.11);

    const pierMat = brick;
    put(frontWall, rbox(0.55, wallH, 0.28, 0.03, 2), pierMat, -5.05, wallH / 2, -4.16, { cast: true });
    put(frontWall, rbox(0.55, wallH, 0.28, 0.03, 2), pierMat, 5.05, wallH / 2, -4.16, { cast: true });
    put(frontWall, rbox(4.1, 0.42, 0.28, 0.03, 1), pierMat, -2.55, 0.21, -4.16, { cast: true });
    put(frontWall, rbox(3.5, 0.42, 0.28, 0.03, 1), pierMat, 2.35, 0.21, -4.16, { cast: true });
    put(frontWall, rbox(1.05, 0.08, 0.32, 0.02, 1), woodDark, 0, 0.04, -4.2, { receive: true });
    for (const x of [-4.66, -2.88, -1.1, -0.57, 0.57, 1.1, 2.88, 4.66]) {
      put(frontWall, rbox(0.09, 2.43, 0.25, 0.02, 1), pineTrim, x, 1.40, -4.19, { cast: true });
    }
    for (const x of [-2.88, 2.88]) {
      put(frontWall, rbox(3.56, 0.10, 0.38, 0.026, 2), pineTrim, x, 0.45, -4.20, { cast: true });
      put(frontWall, rbox(3.56, 0.035, 0.08, 0.01, 1), cutEdge, x, 0.51, -4.37);
    }
    put(frontWall, rbox(10.55, 0.46, 0.27, 0.025, 1), pineTrim, 0, 2.77, -4.20, { cast: true });
    put(frontWall, rbox(10.85, 0.105, 0.60, 0.04, 2), pineTrim, 0, 3.04, -4.26, { cast: true });
    put(frontWall, rbox(10.45, 0.052, 0.39, 0.024, 2), snowCeramic, 0, 3.116, -4.30, { receive: true });
    put(frontWall, rbox(10.64, 0.026, 0.032, 0.01, 1), aquaEnamel, 0, 2.99, -4.566);
    put(frontWall, rbox(10.34, 0.035, 0.055, 0.01, 1), cutEdge, 0, 2.54, -4.36);
    put(frontWall, rbox(3.4, 0.55, 0.08, 0.02, 1), plaster, -2.4, 0.7, -3.92, { receive: true });
    put(frontWall, rbox(3.72, 0.085, 0.42, 0.02, 1), wood, -2.75, 0.725, -3.78, { receive: true });
    put(frontWall, rbox(2.2, 0.085, 0.42, 0.02, 1), wood, 3.38, 0.725, -3.78, { receive: true });

    buildRoof(cx, cz, w, d, wallH, sideGlass);
    scene.add(roofSlab);
    const glassMat = new MeshStandardMaterial({
      color: "#c9e3ee",
      metalness: 0.12,
      roughness: 0.21,
      transparent: true,
      depthWrite: false,
      opacity: 0.12,
      envMapIntensity: 0.8,
      emissive: "#f0ab72",
      emissiveIntensity: 0.15,
    });
    for (const paneX of [-3.77, -1.99, 1.99, 3.77]) {
      put(frontWall, rbox(1.72, 2.02, 0.02, 0.008, 1), glassMat, paneX, 1.52, -4.12);
      put(frontWall, rbox(1.74, 0.035, 0.055, 0.009, 1), pineTrim, paneX, 1.97, -4.25);
    }
    put(frontWall, rbox(3.76, 0.62, 0.215, 0.035, 2), gold, 0, 2.72, -4.46, { cast: true });
    const officeSign = new Mesh(
      rbox(3.65, 0.55, 0.05, 0.02, 1),
      new MeshStandardMaterial({ map: makeSignTexture("GROKBOT", "WINTER STUDIO", "#172d3a", "#fff1cf"), roughness: 0.56, emissive: "#4b76a2", emissiveIntensity: 0.24 }),
    );
    officeSign.position.set(0, 2.72, -4.576);
    frontWall.add(officeSign);
    for (const side of [-1, 1]) {
      const garland = catenary(new Vector3(side * 2.03, 2.64, -4.39), new Vector3(side * 4.69, 2.68, -4.39), 0.27, 26);
      garland.forEach((point, index) => {
        const twig = put(frontWall, new SphereGeometry(0.072, 7, 5), index % 3 ? leafDark : garlandGreen, point.x, point.y, point.z);
        twig.scale.set(1.7, 0.71, 1.08);
        twig.rotation.z = Math.sin(index * 1.8) * 0.6;
        if (index % 5 === 1) put(frontWall, new SphereGeometry(0.041, 8, 6), fairy, point.x, point.y - 0.035, point.z - 0.057);
        if (index % 7 === 3) put(frontWall, new SphereGeometry(0.043, 10, 7), cherryRed, point.x, point.y - 0.048, point.z - 0.04);
      });
      const x = side * (SHELL.maxX + 0.27);
      put(frontWall, new CylinderGeometry(0.039, 0.046, wallH, 8), pineTrim, x, wallH / 2, -4.23, { cast: true });
    }
  }

  function buildSideWindows(edge: number, side: number, back: number, height: number, glass: MeshStandardMaterial): void {
    const front = SHELL.minZ;
    const length = back - front;
    const center = (front + back) / 2;
    const x = edge + side * 0.12;
    const sill = 0.48;
    const bays = 4;
    const bayWidth = length / bays;
    const transom = 2.36;
    sideWall(edge, side, front, back, sill);
    put(scene, rbox(0.30, 0.095, length + 0.045, 0.021, 1), pineTrim, x, sill + 0.025, center, { cast: true });
    put(scene, rbox(0.045, 0.026, length, 0.005, 1), gold, x - side * 0.123, sill + 0.079, center);
    put(scene, rbox(0.28, 0.11, SHELL.maxZ - front + 0.23, 0.021, 1), pineTrim, x, height + 0.029, (front + SHELL.maxZ + 0.23) / 2, { cast: true });
    put(scene, rbox(0.22, 0.055, 1.68, 0.024, 2), snowCeramic, x + side * 0.015, height + 0.107, 3.57);
    put(scene, rbox(0.115, 0.042, length, 0.009, 1), pineTrim, x, transom, center);

    const mainPane = new PlaneGeometry(bayWidth - 0.035, height - sill - 0.047);
    for (let bay = 0; bay < bays; bay += 1) {
      const z = front + (bay + 0.5) * bayWidth;
      const pane = put(scene, mainPane, glass, x + side * 0.026, (height + sill + 0.047) / 2, z, { ry: side * Math.PI / 2 });
      pane.name = "side-window-glass";
    }
    for (let post = 0; post <= bays; post += 1) {
      const z = front + post * bayWidth;
      put(scene, rbox(0.15, height - sill, 0.077, 0.016, 1), pineTrim, x, (height + sill) / 2, z);
      put(scene, rbox(0.054, 0.10, 0.119, 0.012, 1), cutEdge, x + side * 0.076, sill + 0.067, z);
    }
  }

  function sideWall(edge: number, side: number, front: number, back: number, height: number): void {
    const depth = back - front;
    const center = (front + back) / 2;
    put(scene, rbox(0.17, height, depth, 0.02, 1), brick, edge + side * 0.17, height / 2, center, { cast: true, receive: true });
    put(scene, rbox(0.13, height, depth, 0.019, 1), plaster, edge + side * 0.05, height / 2, center, { receive: true });
  }

  function buildRoof(cx: number, cz: number, w: number, d: number, wallH: number, glass: MeshStandardMaterial): void {
    const flash = matte("#c5ccd2", 0.28, 0.84);
    const body = matte("#6a737c", 0.46, 0.45);
    const dark = matte("#4a525a", 0.52, 0.34);
    const eaveY = wallH + 0.10;
    const rise = 0.78;
    const run = d * 0.5 + 0.36;
    const slopeLen = Math.hypot(run, rise);
    const pitch = Math.atan2(rise, run);
    const roofPanel = rbox(w + 0.62, 0.055, slopeLen, 0.01, 1);
    const gable = new Shape();
    gable.moveTo(-run, 0);
    gable.lineTo(0, rise + 0.028);
    gable.lineTo(run, 0);
    gable.closePath();
    const gablePane = new ShapeGeometry(gable);
    for (const side of [-1, 1]) {
      put(roofSlab, roofPanel, slate, cx, eaveY + rise * 0.5, cz + side * run * 0.5, { rx: side * pitch, cast: true, receive: true });
      put(roofSlab, rbox(w + 0.70, 0.10, 0.082, 0.015, 1), dark, cx, eaveY - 0.022, cz + side * run, { cast: true });
      const x = cx + side * (w / 2 + 0.146);
      put(roofSlab, gablePane, glass, x, eaveY - 0.028, cz, { ry: Math.PI / 2 });
      put(roofSlab, rbox(0.072, rise, 0.083, 0.013, 1), dark, x, eaveY + rise * 0.5, cz, { cast: true });
    }
    put(roofSlab, rbox(w + 0.70, 0.066, 0.185, 0.02, 1), flash, cx, eaveY + rise + 0.023, cz, { cast: true });
    const hx = cx + 0.15;
    const hz = cz + 1.15;
    const hy = eaveY + rise * 0.62;
    put(roofSlab, rbox(1.25, 0.26, 0.78, 0.02, 1), body, hx, hy, hz, { cast: true });
    for (let i = 0; i < 8; i += 1) {
      put(roofSlab, rbox(1.05, 0.045, 0.018, 0.002, 1), dark, hx, hy + 0.16, hz - 0.3 + i * 0.085, { cast: true });
    }
    put(roofSlab, new CylinderGeometry(0.2, 0.22, 0.07, 14), dark, hx - 0.28, hy + 0.16, hz - 0.02, { cast: true });
    put(roofSlab, new CylinderGeometry(0.13, 0.13, 0.02, 12), matte("#15191c", 0.4, 0.55), hx - 0.28, hy + 0.2, hz - 0.02);
    for (let i = 0; i < 5; i += 1) {
      put(roofSlab, rbox(0.2, 0.012, 0.035, 0.002, 1), flash, hx - 0.28, hy + 0.22, hz - 0.02, { ry: (i / 5) * Math.PI });
    }
    put(roofSlab, new CylinderGeometry(0.055, 0.065, 0.42, 8), body, hx + 0.48, hy + 0.24, hz + 0.22, { cast: true });
    put(roofSlab, new CylinderGeometry(0.09, 0.09, 0.03, 8), flash, hx + 0.48, hy + 0.46, hz + 0.22);
    put(roofSlab, new CylinderGeometry(0.028, 0.028, 0.85, 6), flash, hx + 0.1, hy + 0.02, hz + 0.48, { rx: Math.PI / 2 });
    put(roofSlab, rbox(0.42, 0.16, 0.36, 0.02, 1), body, cx - 2.4, hy - 0.02, cz - 0.85, { cast: true });
    put(roofSlab, new CylinderGeometry(0.09, 0.11, 0.14, 8), dark, cx - 2.4, hy + 0.12, cz - 0.85, { cast: true });
    put(roofSlab, new ConeGeometry(0.14, 0.09, 8), flash, cx - 2.4, hy + 0.22, cz - 0.85);
    put(roofSlab, new TorusGeometry(0.09, 0.018, 6, 12, Math.PI), flash, cx + 3.2, hy + 0.02, cz - 1.5, { rx: Math.PI / 2, cast: true });
    put(roofSlab, new CylinderGeometry(0.04, 0.04, 0.16, 8), dark, cx - 0.2, hy + 0.05, cz - 1.7, { cast: true });
    put(roofSlab, new CylinderGeometry(0.07, 0.07, 0.02, 8), flash, cx - 0.2, hy + 0.14, cz - 1.7);
  }

  function buildStreet(): void {
    buildPlinth();
    scene.add(makeWinterRoad(env));

    const pavement = ["#515f70", "#596777", "#5e6a79"].map((color) => matte(color, 0.82));
    const footing = matte("#353f52", 0.84);
    for (const material of [...pavement, footing]) material.userData.selectionGround = true;
    put(scene, rbox(16.74, 0.16, 1.95, 0.035, 2), footing, 0, -0.105, -5.243, { receive: true });
    for (let row = 0; row < 4; row += 1) {
      for (let col = 0; col < 26; col += 1) {
        const x = -8.02 + col * 0.63 + (row % 2) * 0.28;
        put(scene, rbox(0.602, 0.035, 0.414, 0.016, 1), pavement[(col * 7 + row * 5) % 3], x, -0.016, -5.943 + row * 0.47, { receive: true });
      }
    }
    const curb = matte("#8593a1", 0.72);
    for (let col = 0; col < 26; col += 1) {
      put(scene, rbox(0.616, 0.13, 0.15, 0.023, 2), curb, -8.03 + col * 0.642, -0.096, -6.19, { receive: true });
    }
    const roadPaint = matte("#8b99aa", 0.66);
    for (const x of [-6.4, -4.8, -3.2, -1.6, 1.6, 3.2, 4.8, 6.4]) {
      put(scene, rbox(0.61, 0.008, 0.048, 0.005, 1), roadPaint, x, -0.163, -8.54);
    }
    for (const x of [-5.25, -2.6, 2.6, 5.25]) {
      put(scene, rbox(0.37, 0.022, 0.14, 0.006, 1), matte("#1c2634", 0.46, 0.38), x, -0.146, -6.34);
      for (let i = 0; i < 4; i += 1) {
        put(scene, rbox(0.32, 0.01, 0.008, 0.003, 1), metal, x, -0.133, -6.38 + i * 0.028);
      }
    }
    lamp(-6.38, -5.77);
    lamp(6.38, -5.77);
    shop({
      x: -6.95,
      wall: "#773e55",
      trim: "#f1dfcf",
      awning: "#974b61",
      title: "MARGINS",
      subtitle: "BOOKSELLER",
      glow: "#f2c9a0",
      kind: "books",
    });
    shop({
      x: 6.95,
      wall: "#385857",
      trim: "#f3dfbf",
      awning: "#426e65",
      title: "HEARTH",
      subtitle: "COFFEE",
      glow: "#ffd7a8",
      kind: "cups",
    });
    buildWinterGarden();
    buildDoorstep();
    bench(2.83, -5.29);
    planter(-3.92, -4.71);
    planter(4.79, -4.76);
    bike(4.39, -5.55);
    postbox(-2.72, -5.31);
    bin(5.45, -5.59);
    doorPivot.position.set(-0.52, 0, -4.22);
    doorPivot.rotation.y = -0.02;
    put(doorPivot, rbox(1.02, 2.12, 0.07, 0.03, 2), wood, 0.51, 1.06, 0, { cast: true });
    put(doorPivot, rbox(0.72, 0.9, 0.02, 0.02, 1), matte("#c5d5de", 0.15, 0.08), 0.51, 1.35, -0.04);
    put(doorPivot, rbox(0.035, 0.14, 0.04, 0.01, 1), gold, 0.92, 1.02, -0.05);
    const wreath = new Group();
    wreath.position.set(0.5, 1.45, -0.07);
    for (let i = 0; i < 14; i += 1) {
      const a = (i / 14) * Math.PI * 2;
      put(wreath, new SphereGeometry(0.045, 8, 6), i % 2 ? leaf : leafDark, Math.cos(a) * 0.16, Math.sin(a) * 0.16, 0);
    }
    put(wreath, rbox(0.08, 0.06, 0.03, 0.01, 1), matte("#7a3140", 0.55), 0, -0.16, 0);
    doorPivot.add(wreath);
    frontWall.add(doorPivot);
    put(scene, rbox(0.9, 0.02, 0.4, 0.01, 1), matte("#6e3a34", 0.8), 0, 0.02, -3.55, { receive: true });
  }

  function buildDoorstep(): void {
    const snow = new MeshStandardMaterial({ vertexColors: true, roughness: 0.92 });
    snow.userData.selectionGround = true;
    const crust = new Color("#a6bbd1");
    const powder = new Color("#e3edf5");
    const depthSteps = [0, 0.22, 0.45, 0.63, 0.82, 1];
    const heightProfile = [0.73, 1, 0.80, 0.50, 0.17, 0];
    const columnCount = 16;
    for (const [left, right, depth, height, seed] of [
      [-1.96, -0.56, 0.43, 0.16, 0.7],
      [0.57, 1.75, 0.35, 0.13, 2.3],
    ] as const) {
      const vertices: number[] = [];
      const colors: number[] = [];
      const uvs: number[] = [];
      const indices: number[] = [];
      const tone = new Color();
      for (let column = 0; column <= columnCount; column += 1) {
        const along = column / columnCount;
        const taper = Math.sin(Math.PI * along) ** 0.52;
        const width = depth * (0.18 + taper * (0.74 + 0.19 * Math.sin(along * 15 + seed)));
        depthSteps.forEach((outward, row) => {
          const ripple = 1 + 0.15 * Math.sin(along * 28 - outward * 8 + seed);
          const rise = height * taper * heightProfile[row] * ripple;
          const x = left + (right - left) * along + outward * taper * 0.045 * Math.sin(along * 11 + seed);
          const z = -4.272 - outward * width;
          vertices.push(x, 0.004 + rise, z);
          uvs.push(along, outward);
          tone.copy(crust).lerp(powder, Math.min(1, rise / height * 1.03 + 0.16));
          colors.push(tone.r, tone.g, tone.b);
          if (column < columnCount && row < depthSteps.length - 1) {
            const current = column * depthSteps.length + row;
            const next = current + depthSteps.length;
            indices.push(current, next, current + 1, next, next + 1, current + 1);
          }
        });
      }
      const bank = new BufferGeometry();
      bank.setAttribute("position", new Float32BufferAttribute(vertices, 3));
      bank.setAttribute("color", new Float32BufferAttribute(colors, 3));
      bank.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
      bank.setIndex(indices);
      bank.computeVertexNormals();
      put(scene, bank, snow, 0, 0, 0, { receive: true });
    }

    const pattern = document.createElement("canvas");
    pattern.width = 512;
    pattern.height = 352;
    const painter = pattern.getContext("2d");
    if (!painter) return;
    const planeWidth = 2.56;
    const planeDepth = 1.76;
    const leftEdge = -planeWidth / 2;
    const streetEdge = -6.15;
    painter.scale(pattern.width / planeWidth, pattern.height / planeDepth);
    painter.translate(-leftEdge, -streetEdge);

    // The wet core stays at the threshold, breaking up into smaller patches toward the curb.
    for (const [x, z, width, depth, alpha, angle] of [
      [-0.12, -4.57, 0.59, 0.21, 0.54, -0.08],
      [0.11, -4.69, 0.42, 0.24, 0.44, 0.27],
      [-0.09, -4.92, 0.40, 0.20, 0.32, -0.28],
      [-0.19, -5.13, 0.29, 0.19, 0.26, 0.24],
      [-0.37, -5.33, 0.29, 0.13, 0.22, -0.2],
      [-0.58, -5.83, 0.36, 0.15, 0.35, 0.18],
    ] as const) {
      painter.save();
      painter.translate(x, z);
      painter.rotate(angle);
      painter.scale(width, depth);
      const melt = painter.createRadialGradient(0, 0, 0.1, 0, 0, 1);
      melt.addColorStop(0, `rgba(29, 47, 64, ${alpha})`);
      melt.addColorStop(0.67, `rgba(34, 54, 70, ${alpha * 0.65})`);
      melt.addColorStop(1, "rgba(38, 59, 72, 0)");
      painter.fillStyle = melt;
      painter.fillRect(-1, -1, 2, 2);
      painter.restore();
    }

    for (const [x, z, turn, strength] of [
      [-0.62, -5.92, 0.37, 0.76],
      [-0.28, -5.62, 0.31, 0.68],
      [-0.36, -5.33, 0.25, 0.57],
      [0.01, -5.06, 0.21, 0.43],
      [-0.11, -4.80, 0.05, 0.28],
    ] as const) {
      painter.save();
      painter.translate(x, z);
      painter.rotate(-turn);
      painter.globalAlpha = strength;
      painter.fillStyle = "#bacbd8";
      painter.beginPath();
      painter.roundRect(-0.082, -0.124, 0.164, 0.248, [0.027, 0.029, 0.051, 0.046]);
      painter.fill();
      painter.fillStyle = "#384d60";
      painter.beginPath();
      painter.roundRect(-0.062, -0.108, 0.124, 0.216, [0.019, 0.020, 0.038, 0.032]);
      painter.fill();
      painter.fillStyle = "#879eaf";
      for (const lug of [-0.070, -0.025, 0.020, 0.064]) {
        painter.fillRect(-0.044, lug, 0.088, 0.012);
      }
      painter.restore();
    }

    const texture = new CanvasTexture(pattern);
    texture.colorSpace = SRGBColorSpace;
    texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    const wet = new MeshStandardMaterial({ map: texture, roughness: 0.47, transparent: true, depthWrite: false });
    const decal = put(scene, new PlaneGeometry(planeWidth, planeDepth), wet, 0, 0.003, streetEdge + planeDepth / 2, { rx: -Math.PI / 2, receive: true });
    decal.userData.selectionIgnore = true;
  }

  function buildPlinth(): void {
    const edge = matte("#263146", 0.53, 0.22);
    const body = matte("#344055", 0.75);
    const inlay = matte("#8b7b70", 0.48, 0.58);
    const top = matte("#455468", 0.82);
    const layers = [
      [PLINTH_SIZE, 0.16, -0.65, 0.066, edge],
      [16.84, 0.027, -0.557, 0.011, inlay],
      [16.77, 0.251, -0.425, 0.06, body],
      [16.91, 0.14, -0.242, 0.05, top],
    ] as const;
    for (const [size, thickness, y, radius, material] of layers) {
      put(scene, rbox(size, thickness, size, radius, 2), material, 0, y, PLINTH_CENTER_Z, { receive: true });
    }
    const terrace = matte("#647185", 0.79);
    terrace.userData.selectionGround = true;
    put(scene, rbox(16.74, 0.13, 1.85, 0.045, 2), terrace, 0, -0.107, 5.52, { receive: true });
    for (const x of [-6.89, 6.89]) {
      put(scene, rbox(2.96, 0.15, 9.02, 0.045, 2), terrace, x, -0.11, 0.14, { receive: true });
    }
    const seam = matte("#3f4d62", 0.84);
    for (let row = 0; row < 12; row += 1) {
      for (const x of [-6.89, 6.89]) {
        put(scene, rbox(2.88, 0.004, 0.024, 0.001, 1), seam, x, -0.034, -4.01 + row * 0.74);
      }
    }
    for (const x of [-6.89, 6.89]) {
      put(scene, rbox(0.022, 0.004, 8.96, 0.001, 1), seam, x, -0.034, 0.14);
    }
    for (let col = 0; col < 19; col += 1) {
      put(scene, rbox(0.023, 0.004, 1.77, 0.001, 1), seam, -7.8 + col * 0.86, -0.041, 5.52);
    }
  }

  function buildWinterGarden(): void {
    for (const [x, z, width, depth, y] of [
      [-7.25, -9.91, 1.31, 0.31, -0.155], [7.2, -9.91, 1.39, 0.34, -0.155],
      [-7.82, -6.15, 0.55, 0.32, -0.028], [-1.84, -6.08, 0.74, 0.19, -0.025],
      [1.84, -6.1, 0.72, 0.19, -0.025], [7.83, -6.17, 0.53, 0.32, -0.028],
      [-7.8, -2.92, 0.65, 0.35, -0.026], [7.76, -2.94, 0.62, 0.34, -0.026],
      [-7.96, 0.65, 0.34, 0.78, -0.027], [7.96, 1.57, 0.35, 0.76, -0.027],
      [-7.3, 5.43, 1.18, 0.7, -0.029], [7.27, 5.47, 1.14, 0.7, -0.029],
      [-4.65, 6.14, 1.32, 0.24, -0.033], [0.95, 6.13, 1.47, 0.23, -0.033],
      [5.41, 6.15, 0.99, 0.24, -0.033],
    ] as const) {
      snowdrift(x, y, z, width, depth);
    }
    streetFir(-7.32, 5.32, 1.02);
    streetFir(7.29, 5.21, 0.88);
    streetFir(7.23, -1.64, 0.78);
    streetFir(-7.38, 0.14, 0.74);
    for (const [x, z, ry, tint] of [
      [-7.03, 4.83, 0.18, "#805167"], [-7.61, 5.04, -0.16, "#4d736d"],
      [7.41, 4.53, -0.23, "#9e6468"],
    ] as const) {
      const gift = new Group();
      gift.position.set(x, 0.085, z);
      gift.rotation.y = ry;
      put(gift, rbox(0.31, 0.23, 0.3, 0.025, 2), matte(tint, 0.75), 0, 0, 0, { cast: true });
      put(gift, rbox(0.05, 0.239, 0.31, 0.008, 1), gold, 0, 0.001, 0);
      put(gift, rbox(0.32, 0.239, 0.044, 0.008, 1), gold, 0, 0.001, 0);
      for (const dx of [-0.041, 0.041]) {
        const loop = put(gift, new TorusGeometry(0.039, 0.008, 5, 11), gold, dx, 0.135, 0, { ry: 0.4 });
        loop.scale.set(1.34, 0.68, 1);
      }
      scene.add(gift);
    }
  }

  function snowdrift(x: number, y: number, z: number, width: number, depth: number): void {
    const driftGeo = new SphereGeometry(1, 12, 8);
    const powder = matte("#becddb", 0.94);
    const crest = matte("#e7eff5", 0.93);
    for (let i = 0; i < 3; i += 1) {
      const offset = (i - 1) * 0.42;
      const drift = put(scene, driftGeo, i === 1 ? crest : powder, x + offset * width, y, z + offset * depth * 0.48, { ry: 0.15 + offset });
      drift.scale.set(width * (i === 1 ? 0.58 : 0.36), 0.12 + depth * (i === 1 ? 0.17 : 0.08), depth * (i === 1 ? 0.76 : 0.62));
    }
  }

  function streetFir(x: number, z: number, scale: number): void {
    const tree = new Group();
    tree.position.set(x, -0.035, z);
    tree.scale.setScalar(scale);
    put(tree, new CylinderGeometry(0.079, 0.114, 0.45, 9), woodDark, 0, 0.23, 0, { cast: true });
    const tiers = ["#284f53", "#396963", "#447770"];
    for (let i = 0; i < 3; i += 1) {
      const y = 0.66 + i * 0.32;
      const radius = 0.59 - i * 0.12;
      put(tree, new ConeGeometry(radius, 0.82, 11), matte(tiers[i]), 0, y, 0, { cast: true, ry: i * 0.3 });
      put(tree, new ConeGeometry(radius * 0.8, 0.62, 11), matte("#d1e2e6", 0.89), 0, y + 0.145, 0, { ry: i * 0.3 });
      for (let j = 0; j < 8; j += 1) {
        const a = j * Math.PI / 4 + i * 1.2;
        put(tree, new SphereGeometry(0.035, 7, 6), j % 3 === 0 ? gold : fairy, Math.cos(a) * radius * 0.82, y - 0.19 + Math.sin(a) * 0.025, Math.sin(a) * radius * 0.82);
      }
    }
    scene.add(tree);
  }

  function lamp(x: number, z: number): void {
    const iron = matte("#303c50", 0.52, 0.47);
    const trim = matte("#647083", 0.52, 0.46);
    put(scene, new CylinderGeometry(0.125, 0.17, 0.09, 10), iron, x, 0.049, z);
    put(scene, new CylinderGeometry(0.065, 0.1, 0.25, 10), iron, x, 0.2, z);
    put(scene, new CylinderGeometry(0.044, 0.054, 1.66, 9), iron, x, 1.08, z, { cast: true });
    put(scene, new CylinderGeometry(0.12, 0.084, 0.08, 4), iron, x, 1.93, z, { ry: Math.PI / 4 });
    put(scene, new CylinderGeometry(0.166, 0.103, 0.27, 4), bulb, x, 2.092, z, { ry: Math.PI / 4 });
    put(scene, new CylinderGeometry(0.041, 0.197, 0.133, 4), iron, x, 2.28, z, { ry: Math.PI / 4, cast: true });
    put(scene, new CylinderGeometry(0.041, 0.149, 0.088, 4), matte("#d7e3ef", 0.9), x, 2.31, z, { ry: Math.PI / 4 });
    put(scene, new SphereGeometry(0.048, 8, 6), trim, x, 2.36, z);
    for (const dx of [-0.093, 0.093]) {
      for (const dz of [-0.093, 0.093]) {
        put(scene, rbox(0.019, 0.282, 0.019, 0.005, 1), iron, x + dx, 2.092, z + dz, { rz: -Math.sign(dx) * 0.14, rx: Math.sign(dz) * 0.14 });
      }
    }
    for (const y of [0.31, 1.54, 1.87]) put(scene, new CylinderGeometry(0.064, 0.064, 0.03, 8), gold, x, y, z);
    const ribbon = matte("#aa556c", 0.74);
    for (const dx of [-0.066, 0.066]) {
      put(scene, rbox(0.148, 0.09, 0.044, 0.022, 2), ribbon, x + dx, 1.57, z - 0.049, { rz: dx * 4.4 });
      put(scene, rbox(0.049, 0.14, 0.024, 0.01, 1), ribbon, x + dx * 0.65, 1.484, z - 0.05, { rz: dx * 5.2 });
    }
    put(scene, new SphereGeometry(0.038, 8, 6), gold, x, 1.57, z - 0.076);
  }

  function shop(opts: { x: number; wall: string; trim: string; awning: string; title: string; subtitle: string; glow: string; kind: "books" | "cups" }): void {
    const { x } = opts;
    const front = -5.157;
    const paint = matte(opts.wall, 0.76);
    const trim = matte(opts.trim, 0.62);
    const shadow = matte(opts.kind === "books" ? "#472f41" : "#243f48", 0.79);
    const stripe = matte(opts.awning, 0.71);
    put(scene, rbox(2.46, 0.14, 1.46, 0.038, 2), shadow, x, 0.058, -4.43, { cast: true, receive: true });
    put(scene, rbox(2.37, 2.19, 1.37, 0.054, 2), paint, x, 1.095, -4.43, { cast: true, receive: true });
    put(scene, rbox(2.52, 0.13, 1.53, 0.034, 2), shadow, x, 2.187, -4.43, { cast: true });
    put(scene, rbox(2.5, 0.057, 1.48, 0.026, 1), matte("#d5e3ed", 0.94), x, 2.27, -4.44, { receive: true });
    snowdrift(x - 0.51, 2.235, -4.49, 0.74, 0.44);
    snowdrift(x + 0.6, 2.23, -4.45, 0.55, 0.34);
    for (const dx of [-1.083, 1.083]) {
      put(scene, rbox(0.094, 1.73, 0.075, 0.016, 1), trim, x + dx, 0.939, front);
    }
    for (let i = 0; i < 11; i += 1) {
      const dx = -1.089 + i * 0.218;
      put(scene, rbox(0.218, 0.09, 0.54, 0.029, 2), i % 2 ? trim : stripe, x + dx, 1.568, front - 0.208, { rx: -0.23, cast: true });
      put(scene, rbox(0.216, 0.127, 0.042, 0.018, 2), i % 2 ? trim : stripe, x + dx, 1.444, front - 0.473);
    }
    const glow = fork(matte(opts.glow, 0.42));
    glow.emissive.set(opts.glow);
    glow.emissiveIntensity = 1.0;
    for (const dx of [-0.736, 0.736]) {
      if (opts.kind === "cups" && dx > 0) {
        coffeePickup(x + dx, front, trim, shadow);
        continue;
      }
      put(scene, rbox(0.688, 0.87, 0.09, 0.028, 2), shadow, x + dx, 0.867, front - 0.015, { cast: true });
      put(scene, rbox(0.585, 0.737, 0.04, 0.018, 2), glow, x + dx, 0.867, front - 0.054);
      put(scene, rbox(0.677, 0.059, 0.16, 0.013, 1), trim, x + dx, 0.476, front - 0.076);
      if (opts.kind === "books" && dx < 0) {
        bookDisplay(x + dx, front);
        continue;
      }
      if (opts.kind === "books") {
        rowOfBooks(x + dx, 0.52, front - 0.103, 3, 0.5);
      } else {
        mug(x + dx - 0.12, 0.54, front - 0.104, "#f7f4ee");
        mug(x + dx + 0.12, 0.54, front - 0.106, "#7a3140");
      }
      put(scene, rbox(0.031, 0.759, 0.024, 0.004, 1), shadow, x + dx, 0.867, front - 0.078);
      put(scene, rbox(0.6, 0.032, 0.025, 0.005, 1), shadow, x + dx, 0.976, front - 0.078);
    }
    put(scene, rbox(0.63, 1.41, 0.09, 0.027, 2), shadow, x, 0.755, front - 0.027, { cast: true });
    put(scene, rbox(0.493, 1.247, 0.065, 0.024, 2), paint, x, 0.711, front - 0.066);
    put(scene, rbox(0.344, 0.536, 0.018, 0.01, 1), glow, x, 0.979, front - 0.105);
    put(scene, rbox(0.03, 0.175, 0.024, 0.004, 1), gold, x + 0.161, 0.687, front - 0.108);
    for (let i = 0; i < 13; i += 1) {
      const a = i * Math.PI * 2 / 13;
      const bead = i % 4 === 0 ? gold : i % 2 === 0 ? leaf : leafDark;
      put(scene, new SphereGeometry(0.031, 7, 6), bead, x + Math.cos(a) * 0.108, 0.99 + Math.sin(a) * 0.108, front - 0.127);
    }
    const side = Math.sign(x);
    const outside = x + side * 1.187;
    put(scene, rbox(0.085, 0.75, 0.665, 0.023, 2), shadow, outside, 1.014, -4.41);
    put(scene, rbox(0.036, 0.621, 0.523, 0.016, 1), glow, outside + side * 0.041, 1.014, -4.41);
    put(scene, rbox(0.029, 0.63, 0.026, 0.004, 1), shadow, outside + side * 0.057, 1.014, -4.41);
    put(scene, rbox(0.029, 0.031, 0.557, 0.004, 1), shadow, outside + side * 0.057, 1.093, -4.41);
    put(scene, rbox(0.148, 0.062, 0.707, 0.012, 1), trim, outside + side * 0.044, 0.659, -4.41);
    put(scene, rbox(0.642, 1.25, 0.054, 0.024, 2), shadow, x, 0.63, -3.728);
    put(scene, rbox(0.529, 0.984, 0.04, 0.018, 1), paint, x, 0.569, -3.69);
    put(scene, rbox(0.031, 0.104, 0.027, 0.007, 1), gold, x + 0.161, 0.563, -3.665);
    const sign = new Mesh(
      rbox(1.79, 0.389, 0.057, 0.023, 2),
      new MeshStandardMaterial({ map: makeSignTexture(opts.title, opts.subtitle, opts.trim, "#2a241e"), roughness: 0.6 }),
    );
    sign.position.set(x, 1.902, front - 0.051);
    scene.add(sign);
    for (const dx of [-0.976, 0.976]) {
      put(scene, new SphereGeometry(0.053, 8, 6), fairy, x + dx, 1.9, front - 0.05);
    }
    if (opts.kind === "books") bookBladeSign(x - 0.94, front, shadow);
  }

  function bookBladeSign(x: number, front: number, binding: MeshStandardMaterial): void {
    const sign = new Group();
    sign.position.set(x, 1.93, front - 0.32);
    sign.rotation.y = -0.96;
    scene.add(sign);
    put(scene, rbox(0.17, 0.19, 0.05, 0.015, 1), binding, x, 2.206, front + 0.012);
    put(scene, rbox(0.056, 0.053, 0.46, 0.018, 2), binding, x, 2.225, front - 0.182, { cast: true });
    put(scene, new TorusGeometry(0.036, 0.008, 5, 12), gold, x, 2.183, front - 0.32);
    put(sign, rbox(0.072, 0.086, 0.038, 0.009, 1), binding, 0, 0.217, 0);

    // The opening at the spine stays visible even when seen in silhouette.
    const page = new Shape();
    page.moveTo(0, 0.134);
    page.quadraticCurveTo(0.126, 0.23, 0.329, 0.20);
    page.quadraticCurveTo(0.348, 0.198, 0.35, 0.181);
    page.lineTo(0.35, -0.155);
    page.quadraticCurveTo(0.142, -0.132, 0, -0.209);
    page.closePath();
    const solidLeaf = new ExtrudeGeometry(page, { depth: 0.045, bevelEnabled: true, bevelThickness: 0.009, bevelSize: 0.007, bevelSegments: 1, curveSegments: 6, steps: 1 });
    const faceLeaf = new ShapeGeometry(page, 6);
    const enamel = new MeshStandardMaterial({ color: "#f0d1a4", roughness: 0.62, side: DoubleSide });
    const engraving = matte("#97716b", 0.84);
    for (const side of [-1, 1]) {
      const turn = side < 0 ? Math.PI : 0;
      put(sign, solidLeaf, binding, side * 0.014, 0, -side * 0.0225, { ry: turn, cast: true });
      for (const face of [-1, 1]) {
        put(sign, faceLeaf, enamel, side * 0.036, 0.002, face * 0.034, { ry: turn }).scale.set(0.855, 0.85, 1);
        for (const [y, width] of [[0.107, 0.183], [0.041, 0.176], [-0.026, 0.126]]) {
          put(sign, rbox(width, 0.012, 0.008, 0.003, 1), engraving, side * 0.187, y, face * 0.04, { rz: side * 0.105 });
        }
      }
    }
    put(sign, rbox(0.036, 0.305, 0.069, 0.011, 1), gold, 0, -0.02, 0);
  }

  function bookDisplay(x: number, front: number): void {
    const display = new Group();
    display.position.set(x, 0.75, front - 0.162);
    display.rotation.set(0.25, -0.12, -0.045);
    scene.add(display);
    put(scene, rbox(0.574, 0.037, 0.26, 0.017, 1), woodDark, x, 0.520, front - 0.134);
    const cover = matte("#804052", 0.64);
    const edges = matte("#debf94", 0.83);
    const print = new MeshStandardMaterial({ map: makeDeskPaper("archive"), roughness: 0.93 });
    for (const side of [-1, 1]) {
      const page = new Group();
      page.rotation.y = -side * 0.20;
      display.add(page);
      put(page, rbox(0.245, 0.418, 0.029, 0.013, 2), cover, side * 0.125, 0, 0.011);
      put(page, rbox(0.228, 0.395, 0.031, 0.014, 2), edges, side * 0.121, 0.003, -0.011);
      put(page, new PlaneGeometry(0.209, 0.375), print, side * 0.121, 0.003, -0.028, { ry: Math.PI });
    }
    put(display, rbox(0.022, 0.408, 0.026, 0.008, 1), cover, 0, 0, 0.006);
    put(display, rbox(0.032, 0.21, 0.012, 0.005, 1), cover, 0.039, -0.124, -0.039, { rz: 0.095 });
  }

  function coffeePickup(x: number, front: number, trim: MeshStandardMaterial, frame: MeshStandardMaterial): void {
    const light = document.createElement("canvas");
    light.width = light.height = 64;
    const paint = light.getContext("2d")!;
    const falloff = paint.createRadialGradient(29, 5, 0, 30, 14, 59);
    falloff.addColorStop(0, "#fff2c9");
    falloff.addColorStop(0.53, "#e4aa6e");
    falloff.addColorStop(1, "#7e4631");
    paint.fillStyle = falloff;
    paint.fillRect(0, 0, 64, 64);
    const amber = new CanvasTexture(light);
    amber.colorSpace = SRGBColorSpace;
    const back = new MeshStandardMaterial({ color: "#ac622f", roughness: 0.68, emissive: "#ffc183", emissiveMap: amber, emissiveIntensity: 0.82 });
    const innerEdge = matte("#713a30", 0.69);
    put(scene, rbox(0.719, 0.874, 0.1, 0.035, 2), frame, x, 0.867, front - 0.021, { cast: true });
    put(scene, rbox(0.564, 0.543, 0.037, 0.02, 2), back, x, 0.957, front - 0.066);
    put(scene, rbox(0.565, 0.051, 0.097, 0.013, 1), shade, x, 1.206, front - 0.096);
    for (const side of [-1, 1]) {
      put(scene, rbox(0.045, 0.559, 0.085, 0.013, 1), innerEdge, x + side * 0.269, 0.957, front - 0.093);
    }
    put(scene, rbox(0.723, 0.057, 0.29, 0.021, 2), woodDark, x, 0.672, front - 0.125, { cast: true, receive: true });
    put(scene, rbox(0.729, 0.027, 0.305, 0.012, 1), trim, x, 0.703, front - 0.128, { receive: true });
    const label = new MeshStandardMaterial({ map: makeLabelTexture("PICK UP", "#f3e3c0", "#3f5753"), roughness: 0.68 });
    put(scene, new PlaneGeometry(0.311, 0.097), label, x, 0.546, front - 0.078, { ry: Math.PI });

    const cupShape = new LatheGeometry([
      new Vector2(0, 0.007), new Vector2(0.058, 0.007), new Vector2(0.074, 0.016),
      new Vector2(0.088, 0.047), new Vector2(0.107, 0.126), new Vector2(0.106, 0.138),
      new Vector2(0.094, 0.139), new Vector2(0.085, 0.125), new Vector2(0.072, 0.043),
      new Vector2(0.052, 0.027), new Vector2(0, 0.027),
    ], 16);
    const handleShape = new TorusGeometry(0.041, 0.013, 7, 13);
    for (const [height, turn, color] of [[0, 0.29, "#f5e8cd"], [0.109, -2.69, "#b46954"]] as const) {
      const cup = new Group();
      cup.position.set(x + 0.05, 0.71 + height, front - 0.172);
      cup.rotation.y = turn;
      const glaze = matte(color, 0.39);
      put(cup, cupShape, glaze, 0, 0, 0);
      put(cup, handleShape, glaze, 0.112, 0.077, 0).scale.set(1, 0.91, 1);
      scene.add(cup);
    }
  }

  function bench(x: number, z: number): void {
    for (let i = 0; i < 3; i += 1) {
      put(scene, rbox(1.13, 0.05, 0.103, 0.014, 1), wood, x, 0.352, z - 0.12 + i * 0.111, { cast: true });
      put(scene, rbox(1.12, 0.081, 0.045, 0.014, 1), wood, x, 0.45 + i * 0.087, z + 0.16 + i * 0.014, { cast: true });
    }
    for (const dx of [-0.452, 0.452]) {
      put(scene, rbox(0.062, 0.366, 0.069, 0.014, 1), metal, x + dx, 0.177, z - 0.109);
      put(scene, rbox(0.059, 0.627, 0.063, 0.012, 1), metal, x + dx, 0.301, z + 0.134, { rx: 0.14 });
      put(scene, rbox(0.06, 0.045, 0.293, 0.014, 1), metal, x + dx, 0.505, z + 0.002);
    }
    const dusting = put(scene, new SphereGeometry(1, 12, 7), matte("#cddde8", 0.9), x + 0.292, 0.382, z + 0.045);
    dusting.scale.set(0.252, 0.025, 0.093);
  }

  function planter(x: number, z: number): void {
    put(scene, new CylinderGeometry(0.25, 0.176, 0.282, 10), matte("#59616c", 0.62), x, 0.151, z, { cast: true });
    put(scene, new CylinderGeometry(0.263, 0.247, 0.045, 10), gold, x, 0.281, z);
    const shrub = new SphereGeometry(0.155, 9, 7);
    for (let i = 0; i < 6; i += 1) {
      const a = i * Math.PI / 3 + 0.5;
      put(scene, shrub, i % 2 ? leafDark : leaf, x + Math.cos(a) * 0.123, 0.389 + Math.cos(a * 2.4) * 0.04, z + Math.sin(a) * 0.123, { cast: true });
    }
    const drift = put(scene, new SphereGeometry(0.15, 9, 7), matte("#d7e2ea", 0.91), x - 0.032, 0.481, z + 0.027);
    drift.scale.set(1.26, 0.47, 0.9);
  }

  function bike(x: number, z: number): void {
    const frame = matte("#a15460", 0.49, 0.33);
    const tire = new TorusGeometry(0.188, 0.019, 7, 19);
    const rim = new TorusGeometry(0.17, 0.009, 6, 17);
    for (const dx of [-0.28, 0.28]) {
      put(scene, tire, matte("#242a39", 0.87), x + dx, 0.207, z);
      put(scene, rim, metal, x + dx, 0.207, z);
      for (let i = 0; i < 4; i += 1) {
        put(scene, rbox(0.31, 0.01, 0.01, 0.003, 1), metal, x + dx, 0.207, z, { rz: i * Math.PI / 4 });
      }
    }
    for (const [x1, y1, x2, y2, material] of [
      [-0.28, 0.207, -0.09, 0.475, frame], [-0.28, 0.207, -0.008, 0.238, frame],
      [-0.09, 0.475, -0.008, 0.238, frame], [-0.09, 0.475, 0.16, 0.457, frame],
      [-0.008, 0.238, 0.16, 0.457, frame], [0.16, 0.49, 0.28, 0.207, metal],
    ] as const) {
      put(scene, rbox(Math.hypot(x2 - x1, y2 - y1), 0.026, 0.025, 0.008, 1), material, x + (x1 + x2) / 2, (y1 + y2) / 2, z - 0.004, { rz: Math.atan2(y2 - y1, x2 - x1) });
    }
    put(scene, rbox(0.14, 0.044, 0.073, 0.018, 2), woodDark, x - 0.107, 0.502, z);
    put(scene, rbox(0.048, 0.032, 0.16, 0.01, 1), woodDark, x + 0.154, 0.519, z);
  }

  function postbox(x: number, z: number): void {
    const lacquer = matte("#963f55", 0.54, 0.24);
    put(scene, new CylinderGeometry(0.141, 0.177, 0.112, 10), metal, x, 0.062, z, { cast: true });
    put(scene, rbox(0.333, 0.655, 0.292, 0.064, 2), lacquer, x, 0.363, z, { cast: true });
    put(scene, rbox(0.36, 0.085, 0.327, 0.041, 2), lacquer, x, 0.678, z, { cast: true });
    put(scene, rbox(0.201, 0.052, 0.024, 0.016, 2), matte("#302536", 0.8), x, 0.557, z - 0.149);
    put(scene, rbox(0.218, 0.027, 0.019, 0.006, 1), gold, x, 0.588, z - 0.153);
    put(scene, rbox(0.063, 0.057, 0.018, 0.008, 1), gold, x, 0.337, z - 0.148);
  }

  function bin(x: number, z: number): void {
    put(scene, new CylinderGeometry(0.16, 0.14, 0.48, 8), matte("#3c4650", 0.6), x, 0.24, z, { cast: true });
    put(scene, new CylinderGeometry(0.17, 0.17, 0.04, 8), metal, x, 0.48, z);
  }

  function buildLounge() {
    const hearth = blockById("hearth");
    const hx = (hearth.minX + hearth.maxX) / 2;
    const redVelvet = matte("#823f50", 0.88);
    const oxblood = matte("#673343", 0.86);
    const hearthWidth = hearth.maxX - hearth.minX;
    const openingWidth = 1.13;
    const pierWidth = (hearthWidth - openingWidth) / 2;
    const fireboxFloor = 0.345;
    const soot = matte("#322421", 0.94);
    const iron = matte("#443b3a", 0.68, 0.33);
    for (const side of [-1, 1]) {
      put(scene, rbox(pierWidth, 1.15, 0.42, 0.031, 2), brick, hx + side * (openingWidth + pierWidth) / 2, 0.595, 4.02, { cast: true, receive: true });
      put(scene, rbox(0.045, 0.65, 0.072, 0.012, 1), iron, hx + side * 0.54, fireboxFloor + 0.325, 3.795);
    }
    put(scene, rbox(hearthWidth, 0.24, 0.43, 0.023, 2), brick, hx, 1.15, 4.02, { cast: true, receive: true });
    put(scene, rbox(1.16, 0.71, 0.083, 0.02, 1), soot, hx, fireboxFloor + 0.34, 4.21, { receive: true });
    put(scene, rbox(openingWidth + 0.01, fireboxFloor - 0.055, 0.414, 0.022, 1), brick, hx, (fireboxFloor - 0.055) / 2 + 0.01, 4.018, { cast: true, receive: true });
    put(scene, rbox(1.22, 0.067, 0.55, 0.027, 2), iron, hx, fireboxFloor - 0.034, 3.889, { receive: true });
    put(scene, rbox(2.3, 0.1, 0.48, 0.03, 2), wood, hx, 1.28, 3.78, { cast: true });
    put(scene, rbox(2.23, 0.047, 0.037, 0.007, 1), cutEdge, hx, 1.265, 3.532);
    for (const [dx, yarn, tilt] of [[-0.48, redVelvet, 0.12], [0, pineFabric, -0.08], [0.48, redVelvet, 0.06]] as const) {
      const stocking = new Group();
      stocking.position.set(hx + dx, 1.06, 3.541);
      stocking.rotation.z = tilt;
      put(stocking, rbox(0.145, 0.26, 0.071, 0.03, 2), yarn, 0, 0, 0, { cast: true });
      put(stocking, rbox(0.217, 0.115, 0.074, 0.039, 2), yarn, -0.042, -0.10, -0.006, { rz: 0.12 });
      put(stocking, rbox(0.174, 0.067, 0.087, 0.018, 2), fabric, 0, 0.116, 0);
      put(stocking, rbox(0.09, 0.014, 0.013, 0.003, 1), gold, 0, 0.011, -0.038);
      scene.add(stocking);
    }
    hangEvergreen(catenary(new Vector3(hx - 0.96, 1.375, 3.55), new Vector3(hx + 0.96, 1.375, 3.55), 0.12, 20), 0.097);
    mantelWreath(hx, 2.14, 4.08, redVelvet);
    candle(hx - 0.83, 1.33, 3.80, 0.20);
    candle(hx - 0.62, 1.33, 3.82, 0.135);
    candle(hx + 0.82, 1.33, 3.84, 0.23);
    const sofa = blockById("sofa");
    const sx = (sofa.minX + sofa.maxX) / 2;
    put(scene, rbox(sofa.maxX - sofa.minX, 0.55, 0.28, 0.05, 2), oxblood, sx, 0.48, 2.86, { cast: true, receive: true });
    put(scene, rbox(1.85, 0.18, 0.62, 0.05, 2), oxblood, sx, 0.32, 3.38, { cast: true, receive: true });
    put(scene, rbox(1.8, 0.045, 0.6, 0.016, 2), woodDark, sx, 0.22, 3.38);
    for (const side of [-1, 1]) {
      put(scene, rbox(0.28, 0.32, 0.58, 0.05, 2), oxblood, sx + side * 0.88, 0.42, 3.36, { cast: true });
      put(scene, rbox(0.27, 0.058, 0.55, 0.025, 2), redVelvet, sx + side * 0.88, 0.573, 3.36);
      put(scene, rbox(0.73, 0.082, 0.50, 0.03, 2), redVelvet, sx + side * 0.38, 0.414, 3.4);
      put(scene, rbox(0.74, 0.33, 0.094, 0.04, 2), redVelvet, sx + side * 0.39, 0.552, 3.005, { rx: -0.13 });
    }
    put(scene, rbox(0.32, 0.28, 0.105, 0.05, 2), fabric, sx - 0.55, 0.575, 3.12, { rz: 0.28, rx: -0.18, cast: true });
    put(scene, rbox(0.27, 0.25, 0.106, 0.04, 2), pineFabric, sx + 0.58, 0.553, 3.13, { rz: -0.26, rx: -0.22, cast: true });
    put(scene, rbox(0.18, 0.012, 0.012, 0.004, 1), gold, sx + 0.58, 0.555, 3.192, { rz: -0.26 });
    put(scene, rbox(0.39, 0.027, 0.52, 0.01, 2), cloth, sx + 0.47, 0.468, 3.46);
    put(scene, rbox(0.39, 0.126, 0.025, 0.01, 2), cloth, sx + 0.47, 0.404, 3.718, { rx: 0.2 });
    for (let i = 0; i < 8; i += 1) {
      put(scene, rbox(0.014, 0.033, 0.014, 0.005, 1), fabric, sx + 0.302 + i * 0.048, 0.329, 3.724);
    }

    const chair = new Group();
    chair.position.set(-1.5, 0, 3.42);
    chair.rotation.y = Math.PI;
    put(chair, rbox(0.48, 0.16, 0.48, 0.05, 2), pineFabric, 0, 0.38, 0, { cast: true });
    put(chair, rbox(0.48, 0.42, 0.1, 0.04, 2), matte("#23493a", 0.8), 0, 0.62, 0.18, { cast: true });
    scene.add(chair);
    const bench = SEATS.find((seat) => seat.id === "fire:4");
    if (bench) {
      put(scene, rbox(0.55, 0.14, 0.36, 0.04, 2), wood, bench.x, 0.32, bench.z, { cast: true });
      put(scene, rbox(0.48, 0.05, 0.3, 0.02, 1), fabric, bench.x, 0.42, bench.z);
    }
    addDesk("desk-ceo", "ceo");
    const shelves = new Group();
    shelves.position.set(-5.09, 1.5, 3.34);
    shelves.rotation.y = Math.PI / 2;
    for (let i = 0; i < 3; i += 1) {
      const y = i * 0.28;
      put(shelves, rbox(0.95, 0.042, 0.24, 0.01, 1), woodDark, 0, y, 0.11, { cast: true });
      rowOfBooks(0, y + 0.12, 0.115, 5, 0.85, shelves);
    }
    scene.add(shelves);
    const fire = buildHearthFire(hx, fireboxFloor);
    scene.add(fire.root);
    return fire;
  }

  function hangEvergreen(points: Vector3[], size: number): void {
    const sprig = new SphereGeometry(1, 7, 5);
    const bead = new SphereGeometry(size * 0.28, 8, 6);
    for (const [index, point] of points.entries()) {
      const side = index % 2 === 0 ? -1 : 1;
      const twig = put(scene, sprig, index % 3 ? leafDark : leaf, point.x, point.y + side * size * 0.23, point.z);
      twig.scale.set(size, size * 0.38, size * 0.4);
      twig.rotation.z = side * 0.57;
      if (index % 4 === 0) put(scene, bead, fairy, point.x, point.y - size * 0.34, point.z - size * 0.41);
      if (index % 4 === 2) {
        put(scene, bead, cherryRed, point.x - size * 0.12, point.y + size * 0.02, point.z - size * 0.35);
        put(scene, bead, cherryRed, point.x + size * 0.18, point.y - size * 0.15, point.z - size * 0.36);
      }
    }
  }

  function mantelWreath(x: number, y: number, z: number, ribbon: MeshStandardMaterial): void {
    const sprig = new SphereGeometry(1, 9, 6);
    const berry = new SphereGeometry(0.037, 8, 6);
    put(scene, new TorusGeometry(0.365, 0.043, 7, 30), leafDark, x, y, z);
    for (let i = 0; i < 22; i += 1) {
      const t = (i / 22) * Math.PI * 2;
      const radius = 0.36 + 0.026 * Math.sin(i * 2.35);
      const px = x + Math.cos(t) * radius;
      const py = y + Math.sin(t) * radius;
      const twig = put(scene, sprig, i % 3 === 0 ? leaf : garlandGreen, px, py, z - 0.024);
      twig.scale.set(0.125, 0.052, 0.047);
      twig.rotation.z = t + 1.04;
      if (i % 3 === 0) put(scene, berry, i % 2 === 0 ? cherryRed : gold, px + 0.024, py - 0.024, z - 0.074);
    }
    for (const side of [-1, 1]) {
      put(scene, rbox(0.18, 0.084, 0.044, 0.018, 2), ribbon, x + side * 0.084, y - 0.328, z - 0.103, { rz: side * 0.31 });
      put(scene, rbox(0.071, 0.164, 0.026, 0.01, 1), ribbon, x + side * 0.046, y - 0.438, z - 0.103, { rz: side * 0.25 });
    }
    put(scene, rbox(0.084, 0.083, 0.061, 0.02, 2), cherryRed, x, y - 0.35, z - 0.105);
  }

  function candle(x: number, surface: number, z: number, height: number): void {
    put(scene, new CylinderGeometry(0.064, 0.081, 0.028, 12), gold, x, surface + 0.014, z);
    put(scene, new CylinderGeometry(0.046, 0.049, height, 12), fabric, x, surface + 0.028 + height / 2, z, { cast: true });
    put(scene, new CylinderGeometry(0.008, 0.008, 0.016, 6), woodDark, x, surface + height + 0.036, z);
  }

  function buildKitchen(): void {
    const counter = blockById("counter");
    const cx = (counter.minX + counter.maxX) / 2;
    const cz = (counter.minZ + counter.maxZ) / 2;
    const cw = counter.maxX - counter.minX;
    const cabinet = matte("#3e5850", 0.68);
    const cabinetPanel = matte("#5d7464", 0.61);
    const porcelain = matte("#e8ddc8", 0.32);
    put(scene, rbox(cw, 0.78, counter.maxZ - counter.minZ, 0.04, 2), wood, cx, 0.39, cz, { cast: true, receive: true });
    put(scene, rbox(cw, 0.06, 0.5, 0.02, 1), matte("#f7f3ea", 0.4), cx, 0.9, cz, { receive: true });
    put(scene, rbox(cw, 0.7, 0.06, 0.01, 1), matte("#e7d3c4", 0.55), cx, 1.25, 4.18);
    const frontZ = counter.minZ - 0.02;
    for (let i = 0; i < 4; i += 1) {
      const dx = -1.6 + i * 1.05;
      put(scene, rbox(0.92, 0.575, 0.038, 0.025, 2), cabinet, cx + dx, 0.42, frontZ);
      put(scene, rbox(0.78, 0.429, 0.034, 0.02, 2), cabinetPanel, cx + dx, 0.41, frontZ - 0.02);
      put(scene, rbox(0.14, 0.027, 0.04, 0.01, 1), gold, cx + dx, 0.58, frontZ - 0.033);
    }
    put(scene, rbox(cw - 0.10, 0.05, 0.04, 0.014, 1), woodDark, cx, 0.83, frontZ);
    put(scene, new CylinderGeometry(0.16, 0.14, 0.06, 12), metal, 2.15, 0.95, 3.85);
    put(scene, new CylinderGeometry(0.012, 0.012, 0.22, 6), metal, 2.15, 1.12, 3.72);
    put(scene, new CylinderGeometry(0.012, 0.012, 0.12, 6), metal, 2.22, 1.18, 3.78, { rz: Math.PI / 2 });
    const kettle = new Group();
    kettle.position.set(3.05, 0.98, 3.82);
    put(kettle, rbox(0.16, 0.14, 0.14, 0.04, 2), metal, 0, 0.07, 0, { cast: true });
    put(kettle, new TorusGeometry(0.05, 0.008, 6, 10), metal, 0.1, 0.08, 0);
    scene.add(kettle);
    put(scene, rbox(0.12, 0.1, 0.08, 0.015, 1), matte("#6b3a28", 0.6), 2.55, 1.02, 4.05, { cast: true });
    put(scene, rbox(1.6, 0.05, 0.22, 0.015, 1), woodDark, 1.55, 1.7, 4.08, { cast: true });
    for (let i = 0; i < 4; i += 1) {
      put(scene, new CylinderGeometry(0.095, 0.077, 0.027, 14), porcelain, 1.99, 1.737 + i * 0.026, 4.06);
    }
    put(scene, rbox(0.28, 0.22, 0.058, 0.016, 1), cabinet, 1.26, 1.836, 4.13, { rz: -0.11 });
    put(scene, rbox(0.232, 0.172, 0.018, 0.01, 1), fabric, 1.26, 1.839, 4.098, { rz: -0.11 });
    put(scene, rbox(0.14, 0.02, 0.018, 0.005, 1), cherryRed, 1.26, 1.84, 4.085, { rz: -0.11 });
    put(scene, rbox(0.9, 0.042, 0.04, 0.007, 1), gold, 1.55, 1.589, 4.031);
    for (const [i, color] of ["#e8ddc8", "#973f53", "#537767", "#dbad71"].entries()) {
      const x = 1.26 + i * 0.185;
      const mugGlaze = matte(color, 0.37);
      put(scene, new TorusGeometry(0.034, 0.008, 6, 10), gold, x + 0.034, 1.555, 4.032);
      put(scene, new TorusGeometry(0.039, 0.011, 7, 12), mugGlaze, x + 0.034, 1.509, 4.011);
      put(scene, new CylinderGeometry(0.059, 0.047, 0.086, 12), mugGlaze, x - 0.016, 1.478, 4.012);
    }
    const machine = new Group();
    machine.name = "hotspot-coffee";
    machine.position.set(4.15, 0.93, 3.95);
    put(machine, rbox(0.32, 0.38, 0.26, 0.03, 2), metal, 0, 0.19, 0, { cast: true });
    put(machine, rbox(0.2, 0.12, 0.16, 0.02, 1), matte("#d5e4ea", 0.15, 0.1), 0, 0.42, 0);
    put(machine, rbox(0.08, 0.06, 0.08, 0.015, 1), matte("#f4efe6", 0.4), 0, 0.02, -0.12);
    const led = matte("#9dcaa8");
    led.emissive.set("#7dbe96");
    led.emissiveIntensity = 0.6;
    put(machine, new SphereGeometry(0.015, 8, 6), led, 0.1, 0.28, -0.13);
    scene.add(machine);
    for (let i = 0; i < 3; i += 1) {
      const puff = fork(matte("#f7f4ee", 0.3));
      puff.transparent = true;
      puff.opacity = 0;
      puff.depthWrite = false;
      put(steam, new SphereGeometry(0.035 + i * 0.012, 8, 6), puff, (i - 1) * 0.03, 0.15, 0);
    }
    steam.position.set(4.15, 1.25, 3.78);
    scene.add(steam);
    jar(3.35, 0.93, 3.95, "#f7f4ee");
    jar(3.62, 0.93, 3.98, "#e6d2a2");
    pantryTreats(porcelain, cabinet);
    const sconce = new Group();
    sconce.position.set(3.49, 1.93, 4.18);
    put(sconce, new CylinderGeometry(0.10, 0.10, 0.045, 12), gold, 0, 0.15, 0, { rx: Math.PI / 2 });
    put(sconce, new CylinderGeometry(0.021, 0.021, 0.32, 8), gold, 0, 0.15, -0.18, { rx: Math.PI / 2 });
    put(sconce, new CylinderGeometry(0.086, 0.148, 0.15, 13), shade, 0, 0.071, -0.30, { cast: true });
    scene.add(sconce);
    for (const seat of SEATS.filter((item) => item.zone === "kitchen")) addStool(seat);
  }

  function pantryTreats(porcelain: MeshStandardMaterial, pine: MeshStandardMaterial): void {
    const tins = [[0.88, 0.19, 0.075, pine], [1.10, 0.15, 0.085, cherryRed], [1.34, 0.22, 0.08, porcelain]] as const;
    for (const [x, height, radius, enamel] of tins) {
      put(scene, new CylinderGeometry(radius, radius, height, 12), enamel, x, 0.93 + height / 2, 4.03, { cast: true });
      put(scene, new CylinderGeometry(radius + 0.008, radius + 0.008, 0.024, 12), gold, x, 0.935 + height, 4.03);
      put(scene, rbox(0.087, 0.052, 0.012, 0.007, 1), fabric, x, 0.933 + height / 2, 4.027 - radius);
    }
    put(scene, rbox(0.52, 0.04, 0.285, 0.019, 2), woodDark, 1.64, 0.952, 3.82, { ry: 0.14, cast: true });
    const cookieShape = new Shape();
    for (let i = 0; i < 10; i += 1) {
      const turn = (i / 10) * Math.PI * 2;
      const radius = i % 2 === 0 ? 0.068 : 0.032;
      const x = Math.cos(turn) * radius;
      const y = Math.sin(turn) * radius;
      if (i === 0) cookieShape.moveTo(x, y);
      else cookieShape.lineTo(x, y);
    }
    cookieShape.closePath();
    const cookie = new ExtrudeGeometry(cookieShape, { depth: 0.02, bevelEnabled: false });
    const gingerbread = matte("#ac6f45", 0.84);
    const icing = new SphereGeometry(0.013, 6, 4);
    for (const [dx, dz] of [[-0.12, 0.025], [0.02, -0.035], [0.15, -0.015], [0.075, 0.065]]) {
      put(scene, cookie, gingerbread, 1.64 + dx, 0.972, 3.82 + dz, { rx: -Math.PI / 2, rz: dx * 9 });
      put(scene, icing, fabric, 1.64 + dx, 0.992, 3.82 + dz);
    }
    put(scene, new CylinderGeometry(0.11, 0.083, 0.027, 12), porcelain, 2.68, 0.946, 3.84);
    mug(2.68, 0.986, 3.84, "#973f53");
  }

  function buildWork(): void {
    const desks: [string, RoleId][] = [
      ["desk-quant", "quant"],
      ["desk-backtest", "backtest"],
      ["desk-literature", "literature"],
      ["desk-hr", "hr"],
      ["desk-secretary", "secretary"],
      ["desk-ta", "ta"],
    ];
    for (const [id, role] of desks) addDesk(id, role);
    const globeDesk = blockById("desk-secretary");
    const globeX = (globeDesk.minX + globeDesk.maxX) / 2;
    const globeZ = globeDesk.minZ + 0.15;
    const globeGlass = new MeshStandardMaterial({ color: "#d4e7e7", opacity: 0.19, transparent: true, depthWrite: false, roughness: 0.13, metalness: 0.19 });
    put(scene, new CylinderGeometry(0.102, 0.119, 0.048, 12), gold, globeX, 0.824, globeZ);
    put(scene, new SphereGeometry(0.095, 12, 10), globeGlass, globeX, 0.93, globeZ);
    put(scene, new CylinderGeometry(0.076, 0.08, 0.024, 10), snowCeramic, globeX, 0.873, globeZ);
    put(scene, new ConeGeometry(0.043, 0.105, 8), leafDark, globeX, 0.933, globeZ);
    put(scene, new ConeGeometry(0.023, 0.068, 8), snowCeramic, globeX, 0.966, globeZ);
    const reading = blockById("desk-literature");
    const journalX = (reading.minX + reading.maxX) / 2;
    const journalZ = reading.maxZ - 0.17;
    put(scene, rbox(0.22, 0.032, 0.19, 0.009, 1), pineFabric, journalX, 0.818, journalZ, { ry: 0.17 });
    put(scene, rbox(0.18, 0.023, 0.15, 0.006, 1), fabric, journalX + 0.027, 0.84, journalZ - 0.016, { ry: -0.095 });
    put(scene, rbox(0.013, 0.012, 0.133, 0.004, 1), gold, journalX + 0.046, 0.856, journalZ, { ry: 0.28 });
    put(scene, rbox(0.95, 0.70, 0.075, 0.02, 1), woodDark, 5.1, 1.77, 3.16, { ry: -Math.PI / 2, cast: true });
    const note = new Mesh(rbox(0.62, 0.48, 0.02, 0.01, 1), new MeshStandardMaterial({ map: makeNoteTexture(), roughness: 0.8 }));
    note.position.set(5.053, 1.77, 3.16);
    note.rotation.y = -Math.PI / 2;
    scene.add(note);
  }

  function buildBackWall(): void {
    const panel = matte("#6a8173", 0.73);
    const panelFrame = matte("#435b50", 0.62);
    const wallZ = 4.171;
    put(scene, rbox(10.29, 1.14, 0.042, 0.014, 1), panelFrame, 0, 0.57, wallZ);
    put(scene, rbox(10.31, 0.087, 0.070, 0.015, 1), panelFrame, 0, 1.14, wallZ - 0.021);
    put(scene, rbox(10.31, 0.025, 0.042, 0.007, 1), cutEdge, 0, 1.181, wallZ - 0.036);
    for (let i = 0; i < 12; i += 1) {
      put(scene, rbox(0.735, 0.91, 0.025, 0.013, 1), panel, -4.73 + i * 0.86, 0.543, wallZ - 0.025);
    }

    const caseX = -1.05;
    const zBack = 4.18;
    put(scene, rbox(2.3, 1.85, 0.06, 0.013, 1), woodDark, caseX, 0.95, zBack, { cast: true });
    put(scene, rbox(2.36, 0.095, 0.32, 0.026, 2), wood, caseX, 1.896, zBack - 0.141, { cast: true });
    put(scene, rbox(2.37, 0.024, 0.043, 0.007, 1), cutEdge, caseX, 1.862, zBack - 0.309);
    put(scene, rbox(2.3, 0.33, 0.28, 0.016, 1), woodDark, caseX, 0.205, zBack - 0.13);
    for (const side of [-1, 1]) {
      put(scene, rbox(0.073, 1.83, 0.32, 0.018, 1), wood, caseX + side * 1.13, 0.94, zBack - 0.13, { cast: true });
      put(scene, rbox(1.02, 0.25, 0.042, 0.017, 1), wood, caseX + side * 0.538, 0.211, zBack - 0.274);
      put(scene, rbox(0.115, 0.026, 0.037, 0.010, 1), gold, caseX + side * 0.538, 0.258, zBack - 0.305);
    }
    const shelfHeights = [0.39, 0.77, 1.15, 1.53];
    for (const y of shelfHeights) {
      put(scene, rbox(2.21, 0.042, 0.28, 0.01, 1), wood, caseX, y, zBack - 0.12);
      put(scene, rbox(2.19, 0.018, 0.019, 0.004, 1), cutEdge, caseX, y + 0.006, zBack - 0.267);
    }
    rowOfBooks(caseX, shelfHeights[0] + 0.118, zBack - 0.16, 10, 2.02);
    rowOfBooks(caseX - 0.28, shelfHeights[1] + 0.118, zBack - 0.16, 7, 1.42);
    rowOfBooks(caseX + 0.29, shelfHeights[2] + 0.118, zBack - 0.17, 6, 1.43);
    rowOfBooks(caseX - 0.34, shelfHeights[3] + 0.118, zBack - 0.16, 6, 1.32);
    const cartons = [panelFrame, cherryRed, cutEdge];
    for (let i = 0; i < cartons.length; i += 1) {
      put(scene, rbox(0.36 - 0.034 * i, 0.058, 0.18, 0.013, 1), cartons[i], caseX - 0.68, 1.201 + i * 0.057, zBack - 0.17, { ry: 0.13 * (i - 1) });
    }
    plant(caseX + 0.63, shelfHeights[1] + 0.022, zBack - 0.17, 0.90);
    put(scene, new CylinderGeometry(0.076, 0.093, 0.18, 10), panel, caseX + 0.57, 1.642, zBack - 0.18);
    put(scene, new CylinderGeometry(0.048, 0.062, 0.07, 10), panel, caseX + 0.57, 1.747, zBack - 0.18);
    put(scene, rbox(0.27, 0.15, 0.16, 0.025, 2), cherryRed, caseX - 0.77, 2.015, zBack - 0.15);
    put(scene, rbox(0.087, 0.029, 0.17, 0.008, 1), gold, caseX - 0.77, 2.076, zBack - 0.15);
    plant(caseX + 0.75, 1.945, zBack - 0.14, 0.78);

    frame(-4.69, 2.13, 0, 0.77);
    frame(0.63, 2.33, 1, 1.08);
    frame(2.47, 2.17, 2, 0.73);
    frame(4.25, 2.12, 3, 1);
    const hooks = [-4.89, -1.83, 1.30, 4.81];
    hooks.forEach((x, index) => {
      put(scene, new SphereGeometry(0.047, 7, 6), gold, x, 2.771, 4.095);
      const next = hooks[index + 1];
      if (next !== undefined) {
        hangEvergreen(catenary(new Vector3(x, 2.75, 4.094), new Vector3(next, 2.75, 4.094), 0.19, 21), 0.144);
      }
    });
  }

  function frame(x: number, y: number, variant: number, scale: number): void {
    const frames = ["#6e3a34", "#2c4038", "#6a5438", "#3e4654"];
    put(scene, rbox(0.62 * scale, 0.46 * scale, 0.057, 0.015, 2), matte(frames[variant % frames.length], 0.48), x, y, 4.151, { cast: true });
    put(scene, rbox(0.53 * scale, 0.39 * scale, 0.029, 0.012, 1), fabric, x, y, 4.121);
    const painting = new MeshStandardMaterial({ map: paintingTexture(variant), roughness: 0.65 });
    put(scene, rbox(0.441 * scale, 0.306 * scale, 0.014, 0.007, 1), painting, x, y, 4.105);
  }

  function paintingTexture(variant: number): CanvasTexture {
    const canvas = document.createElement("canvas");
    canvas.width = 160;
    canvas.height = 120;
    const g = canvas.getContext("2d");
    if (!g) throw new Error("Unable to draw the framed print.");
    const palettes = [
      ["#e5beae", "#8b5763", "#fbdf9f", "#f2d9cc"],
      ["#adcbc8", "#355b50", "#f2e1b7", "#dceae1"],
      ["#e0c89f", "#8b644e", "#ecab80", "#f1dcc1"],
      ["#b5bacd", "#414b69", "#edcea0", "#d5dfeb"],
    ];
    const palette = palettes[variant % palettes.length];
    g.fillStyle = palette[0];
    g.fillRect(0, 0, 160, 120);
    const moonX = variant % 2 ? 108 : 53;
    g.fillStyle = palette[2];
    g.beginPath();
    g.arc(moonX, 35, 17, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = palette[3];
    g.beginPath();
    g.moveTo(0, 89);
    g.quadraticCurveTo(40, 52, 80, 80);
    g.quadraticCurveTo(117, 99, 160, 68);
    g.lineTo(160, 120);
    g.lineTo(0, 120);
    g.fill();
    g.fillStyle = palette[1];
    for (const [x, ground, height] of [[27, 101, 33], [63, 111, 53], [113, 104, 38], [133, 96, 30]]) {
      g.fillRect(x - 1.5, ground - 12, 3, 12);
      for (let tier = 0; tier < 3; tier += 1) {
        const peak = ground - height + tier * height * 0.22;
        const base = peak + height * 0.43;
        const spread = height * (0.15 + tier * 0.047);
        g.beginPath();
        g.moveTo(x, peak);
        g.lineTo(x + spread, base);
        g.lineTo(x - spread, base);
        g.fill();
      }
    }
    const texture = new CanvasTexture(canvas);
    texture.colorSpace = SRGBColorSpace;
    texture.needsUpdate = true;
    return texture;
  }

  function buildFrontDressing(): void {
    const spots = [-4.3, -3.5, -2.6, -1.7];
    spots.forEach((x, i) => plantLocal(frontWall, x, 0.78, -3.72, 0.85 + (i % 2) * 0.1));
    const stand = new Group();
    stand.position.set(-1.15, 0.78, -3.7);
    put(stand, rbox(0.28, 0.04, 0.2, 0.01, 1), wood, 0, 0.08, 0);
    put(stand, rbox(0.22, 0.015, 0.16, 0.005, 1), fabric, 0, 0.12, 0, { rx: -0.4 });
    put(stand, rbox(0.2, 0.012, 0.14, 0.004, 1), matte("#f7f1e4", 0.7), 0, 0.135, 0, { rx: -0.4 });
    frontWall.add(stand);
    rowOfBooks(-2.15, 0.84, -3.7, 4, 0.28, frontWall);

    const cabinet = matte("#28423e", 0.62);
    put(frontWall, rbox(2.11, 0.69, 0.40, 0.035, 2), cabinet, 3.38, 0.345, -3.83, { cast: true, receive: true });
    for (const x of [2.70, 3.38, 4.06]) {
      put(frontWall, rbox(0.60, 0.46, 0.036, 0.018, 2), pineFabric, x, 0.37, -3.61);
      put(frontWall, rbox(0.082, 0.023, 0.038, 0.008, 1), gold, x, 0.49, -3.58);
    }
    plantLocal(frontWall, 4.19, 0.78, -3.78, 0.94);
    rowOfBooks(3.04, 0.87, -3.79, 4, 0.43, frontWall);
    const lanternX = 3.62;
    const lanternZ = -3.78;
    put(frontWall, rbox(0.20, 0.045, 0.18, 0.013, 1), woodDark, lanternX, 0.79, lanternZ);
    put(frontWall, rbox(0.17, 0.21, 0.15, 0.017, 1), shade, lanternX, 0.91, lanternZ);
    put(frontWall, rbox(0.21, 0.045, 0.18, 0.013, 1), gold, lanternX, 1.03, lanternZ);
    put(frontWall, new TorusGeometry(0.045, 0.008, 6, 12), gold, lanternX, 1.073, lanternZ);
    for (const dx of [-0.083, 0.083]) {
      for (const dz of [-0.074, 0.074]) {
        put(frontWall, rbox(0.018, 0.215, 0.018, 0.003, 1), woodDark, lanternX + dx, 0.92, lanternZ + dz);
      }
    }
    sprinkle(catenary(new Vector3(-4.2, 2.22, -3.95), new Vector3(-0.9, 2.22, -3.95), 0.1, 14), leaf, 0.045, false, frontWall);
    sprinkle(catenary(new Vector3(-4.1, 2.28, -3.95), new Vector3(-1.0, 2.28, -3.95), 0.1, 10), fairy, 0.03, true, frontWall);
  }

  function buildTree(): void {
    const tree = new Group();
    tree.name = "hotspot-lights";
    const { x, z } = CHRISTMAS_TREE;
    tree.position.set(x, 0, z);
    const velvet = matte("#6a293c", 0.90);
    const rugTrim = matte("#b88d6c", 0.82);
    put(scene, new CylinderGeometry(1.46, 1.46, 0.022, 56), velvet, x, 0.016, z, { receive: true });
    for (const [radius, width] of [[1.38, 0.013], [1.28, 0.008]]) {
      put(scene, new TorusGeometry(radius, width, 5, 64), rugTrim, x, 0.027, z, { rx: -Math.PI / 2 });
    }
    put(tree, new CylinderGeometry(0.39, 0.52, 0.055, 20), velvet, 0, 0.053, 0);
    put(tree, new CylinderGeometry(0.27, 0.19, 0.24, 12), woodDark, 0, 0.19, 0, { cast: true });
    put(tree, new TorusGeometry(0.245, 0.014, 6, 22), gold, 0, 0.285, 0, { rx: Math.PI / 2 });
    put(tree, new CylinderGeometry(0.08, 0.12, 0.45, 9), woodDark, 0, 0.32, 0, { cast: true });

    const branches = [matte("#254c40", 0.82), garlandGreen, matte("#3c7056", 0.72)];
    const baubles = [matte("#8e2f49", 0.31, 0.28), matte("#bf9354", 0.36, 0.59), matte("#ebdac2", 0.44, 0.16)];
    const bauble = new SphereGeometry(1, 12, 8);
    const cap = new CylinderGeometry(0.75, 1, 1, 7);
    const hanger = new CylinderGeometry(0.005, 0.005, 1, 5);
    const diode = new SphereGeometry(0.032, 8, 6);
    const cable = matte("#514637", 0.74, 0.12);
    const ornamentCap = matte("#a38151", 0.53, 0.52);
    const tiers = [
      { radius: 1.10, height: 0.75, y: 0.39, x: 0.022, z: -0.024, start: -2.52, sweep: 5.61, bulbs: 13, sag: 0.16 },
      { radius: 0.97, height: 0.65, y: 0.82, x: -0.037, z: 0.027, start: -1.85, sweep: 5.10, bulbs: 11, sag: 0.115 },
      { radius: 0.76, height: 0.70, y: 1.22, x: 0.034, z: 0.039, start: -2.81, sweep: 5.04, bulbs: 10, sag: 0.15 },
      { radius: 0.64, height: 0.58, y: 1.72, x: 0.018, z: -0.041, start: -2.36, sweep: 5.77, bulbs: 9, sag: 0.091 },
      { radius: 0.45, height: 0.54, y: 2.09, x: -0.027, z: 0.018, start: -1.66, sweep: 5.21, bulbs: 7, sag: 0.094 },
      { radius: 0.26, height: 0.56, y: 2.49, x: 0, z: -0.024, start: -2.08, sweep: 5.32, bulbs: 6, sag: 0.058 },
    ];
    // Angle, hanging length, size and finish. These hang from the boughs, independent of the lights.
    const ornaments = [
      [[-2.35, 0.05, 0.073, 1], [-1.75, 0.10, 0.084, 0], [-0.54, 0.056, 0.091, 1], [0.62, 0.02, 0.06, 2], [2.31, 0.082, 0.075, 0]],
      [[-2.69, 0.07, 0.068, 0], [-1.37, 0.06, 0.062, 2], [-0.20, 0.11, 0.087, 0], [1.13, 0.06, 0.08, 1], [2.78, 0.04, 0.071, 2]],
      [[-2.07, 0.095, 0.082, 1], [-1.01, 0.046, 0.075, 0], [0.27, 0.035, 0.057, 2], [1.72, 0.072, 0.071, 0], [2.62, 0.044, 0.077, 1]],
      [[-2.54, 0.039, 0.05, 2], [-1.82, 0.106, 0.067, 0], [-0.49, 0.045, 0.073, 1], [1.35, 0.035, 0.057, 1], [2.49, 0.06, 0.059, 0]],
      [[-2.13, 0.045, 0.057, 1], [-0.93, 0.036, 0.069, 0], [0.79, 0.035, 0.051, 2], [2.45, 0.043, 0.058, 1]],
      [[-1.91, 0.031, 0.048, 0], [-0.35, 0.045, 0.048, 1], [1.51, 0.026, 0.045, 0]],
    ] as const;
    for (const [tier, { radius, height, y, x, z, start, sweep, bulbs, sag }] of tiers.entries()) {
      const profile = [[0, 0.05], [0.55, 0.00], [0.87, 0.019], [1, 0.092], [0.92, 0.20], [0.67, 0.38], [0.43, 0.63], [0.19, 0.83], [0, 1]];
      const canopy = new LatheGeometry(profile.map(([r, h]) => new Vector2(r * radius, h * height)), 56);
      const vertices = canopy.getAttribute("position");
      const widthAt = (turn: number) => 0.087 * Math.sin(turn * (tier % 2 ? 6 : 5) + tier * 1.64)
        + 0.028 * Math.cos(turn * 9 - tier * 0.73) + 0.023 * Math.cos(turn + tier * 1.9);
      const liftAt = (turn: number) => height * (0.065 * Math.cos(turn * 5 - tier * 1.93) + 0.045 * Math.sin(turn * 3 + tier));
      for (let i = 0; i < vertices.count; i += 1) {
        const px = vertices.getX(i);
        const pz = vertices.getZ(i);
        const turn = Math.atan2(pz, px);
        const edge = (px * px + pz * pz) / (radius * radius);
        const scallop = 1 + widthAt(turn) * edge;
        vertices.setXYZ(i, px * scallop, vertices.getY(i) + liftAt(turn) * edge, pz * scallop);
      }
      canopy.computeVertexNormals();
      put(tree, canopy, branches[tier % branches.length], x, y, z, { cast: true, receive: true });

      function stringPoint(progress: number, offset = 0): Vector3 {
        const turn = start + progress * sweep;
        const dip = sag * Math.sin(progress * Math.PI * 3) ** 2 * (0.64 + 0.36 * Math.sin(turn * 1.73 + tier) ** 2);
        const tuck = (1 - Math.min(1, 14 * progress, 14 * (1 - progress))) ** 2;
        const ring = radius * (1.005 + widthAt(turn) - 0.20 * tuck) + 0.015 + offset;
        const rise = y + height * (0.198 + 0.05 * Math.sin(turn * 2 + tier)) + 0.65 * liftAt(turn) - dip;
        return new Vector3(x + Math.cos(turn) * ring, rise, z + Math.sin(turn) * ring);
      }
      const strand = Array.from({ length: 33 }, (_, index) => stringPoint(index / 32));
      put(tree, new TubeGeometry(new CatmullRomCurve3(strand), 64, 0.006, 5, false), cable, 0, 0, 0);
      for (let i = 0; i < bulbs; i += 1) {
        const progress = (i + 0.5 + 0.26 * Math.sin(i * 2.53 + tier * 1.36)) / bulbs;
        const bulbPosition = stringPoint(progress, 0.011);
        const light = put(tree, diode, treeFairy, bulbPosition.x, bulbPosition.y - 0.008, bulbPosition.z);
        const size = (i + tier) % 4 === 0 ? 1 : 0.72 + 0.10 * Math.sin(i * 2 + tier);
        light.scale.set(size, 0.93 * size, size);
      }
      for (const [turn, drop, size, finish] of ornaments[tier]) {
        const ring = radius * (0.986 + widthAt(turn));
        const tip = y + height * 0.094 + liftAt(turn);
        const ballX = x + ring * Math.cos(turn);
        const ballZ = z + ring * Math.sin(turn);
        const ballTop = tip - drop;
        put(tree, hanger, ornamentCap, ballX, (tip + ballTop) / 2, ballZ).scale.y = drop;
        put(tree, cap, ornamentCap, ballX, ballTop, ballZ).scale.set(size * 0.28, size * 0.32, size * 0.28);
        put(tree, bauble, baubles[finish], ballX, ballTop - size * 0.96, ballZ).scale.set(size, size * 1.04, size);
      }
    }
    const star = new Shape();
    for (let i = 0; i < 10; i += 1) {
      const angle = Math.PI / 2 + i * Math.PI / 5;
      const radius = i % 2 === 0 ? 0.224 : 0.098;
      const x = radius * Math.cos(angle);
      const y = radius * Math.sin(angle);
      if (i === 0) star.moveTo(x, y);
      else star.lineTo(x, y);
    }
    star.closePath();
    const starGeo = new ExtrudeGeometry(star, { depth: 0.044, bevelEnabled: true, bevelSize: 0.010, bevelThickness: 0.010, bevelSegments: 1 });
    put(tree, starGeo, treeFairy, 0, 3.13, -0.024, { ry: -0.35 });
    for (const [gx, gz, color, size, turn] of [
      [-0.63, -0.54, "#8b354c", 0.35, 0.14], [-0.27, -0.86, "#326863", 0.29, -0.21],
      [0.18, -0.94, "#d59d65", 0.31, 0.21], [0.65, -0.62, "#8b354c", 0.41, -0.31],
      [0.78, 0.05, "#d3b789", 0.37, 0.27], [0.53, 0.62, "#397361", 0.34, 0.33],
      [-0.38, 0.79, "#b2757e", 0.32, -0.22], [-0.87, 0.19, "#4c6975", 0.36, 0.31],
    ] as const) gift(tree, gx, gz, color, size, turn);
    mergeStatic(tree);
    scene.add(tree);
  }

  function buildClock(): { hour: Object3D; minute: Object3D } {
    const clock = new Group();
    clock.position.set(-1.15, 2.15, 4.16);
    clock.rotation.y = Math.PI;
    put(clock, new CylinderGeometry(0.22, 0.22, 0.04, 20), woodDark, 0, 0, 0, { rx: Math.PI / 2 });
    put(clock, new CylinderGeometry(0.18, 0.18, 0.02, 20), fabric, 0, 0, 0.02, { rx: Math.PI / 2 });
    const hour = new Group();
    hour.userData.keep = true;
    put(hour, rbox(0.025, 0.1, 0.01, 0.005, 1), woodDark, 0, 0.04, 0.04);
    clock.add(hour);
    const minute = new Group();
    minute.userData.keep = true;
    put(minute, rbox(0.016, 0.14, 0.01, 0.004, 1), matte("#2a241e", 0.5), 0, 0.06, 0.045);
    clock.add(minute);
    scene.add(clock);
    return { hour, minute };
  }

  function buildSnow(): { mesh: InstancedMesh; parts: { x: number; y: number; z: number; v: number; s: number }[]; dummy: Object3D; spawn: (y: number) => { x: number; y: number; z: number } } {
    const count = 160;
    const parts: { x: number; y: number; z: number; v: number; s: number }[] = [];
    const geo = new SphereGeometry(0.041, 6, 5);
    const material = new MeshStandardMaterial({ color: "#f2f8ff", emissive: "#aec3ee", emissiveIntensity: 0.39, roughness: 0.8 });
    const mesh = new InstancedMesh(geo, material, count);
    mesh.name = "falling-snow";
    mesh.instanceMatrix.setUsage(35048);
    const dummy = new Object3D();
    const spawn = (y: number) => {
      for (let attempt = 0; attempt < 12; attempt += 1) {
        const x = -8.25 + Math.random() * 16.5;
        const z = -10.03 + Math.random() * 16.2;
        if (isSnowZone(x, z)) return { x, y, z };
      }
      return { x: -7.2, y, z: -6.2 };
    };
    for (let i = 0; i < count; i += 1) {
      const born = spawn(Math.random() * 4.8);
      const flake = { ...born, v: 0.24 + Math.random() * 0.31, s: 0.62 + Math.random() * 0.72 };
      parts.push(flake);
      dummy.position.set(flake.x, flake.y, flake.z);
      dummy.scale.setScalar(flake.s);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.count = 110;
    scene.add(mesh);
    mesh.visible = false;
    return { mesh, parts, dummy, spawn };
  }

  function addDesk(id: string, role: RoleId): void {
    const block = blockById(id);
    const seat = SEATS.find((item) => item.forRole === role);
    if (!seat) return;
    const cx = (block.minX + block.maxX) / 2;
    const cz = (block.minZ + block.maxZ) / 2;
    const w = block.maxX - block.minX;
    const d = block.maxZ - block.minZ;
    const palette = DESK_FINISH[role];
    const lacquer = matte(palette.lacquer, 0.63);
    const accent = matte(palette.accent, 0.70);
    const trim = matte(palette.trim, 0.48, 0.34);
    const technical = role === "quant" || role === "backtest";
    const tabletop = fork(technical || role === "hr" ? lacquer : wood);
    if (role === "quant") {
      tabletop.roughness = 0.46;
      tabletop.metalness = 0.05;
    }
    tabletop.userData.selectionWorkstation = role;
    put(scene, rbox(w, 0.075, d, 0.035, 2), tabletop, cx, 0.7625, cz, { cast: true, receive: true });
    put(scene, rbox(w * 0.94, 0.122, d * 0.91, 0.018, 2), lacquer, cx, 0.681, cz, { cast: true });
    for (const sx of [-1, 1]) {
      for (const sz of [-1, 1]) {
        put(scene, rbox(0.065, 0.65, 0.065, 0.013, 1), lacquer, cx + sx * (w / 2 - 0.074), 0.325, cz + sz * (d / 2 - 0.071), { cast: true });
      }
    }
    addChair(seat, accent, lacquer, trim);
    const dress = new Group();
    dress.name = `workstation:${role}`;
    dress.position.set(cx, 0.80, cz);
    dress.rotation.y = seat.yaw + Math.PI;
    const sideFacing = Math.abs(seat.x - cx) > Math.abs(seat.z - cz);
    const depth = sideFacing ? w : d;
    const width = sideFacing ? d : w;
    const edge = -depth / 2;
    const plaqueX = role === "ceo" ? 0.48 : 0.26;
    const plaqueZ = depth * 0.37;
    const plaqueY = 0.034;
    put(dress, rbox(width * 0.9, 0.015, 0.019, 0.004, 1), trim, 0, -0.08, depth * 0.46);
    put(dress, rbox(0.39, 0.086, 0.029, 0.011, 2), accent, plaqueX, plaqueY - 0.004, plaqueZ, { rx: -1.08 });
    const plate = new Mesh(
      new PlaneGeometry(0.37, 0.073),
      new MeshStandardMaterial({ map: makeLabelTexture(roleById(role).short, "#fff3d9", palette.lacquer), roughness: 0.54 }),
    );
    plate.material.userData.selectionWorkstation = role;
    plate.position.set(plaqueX, plaqueY + 0.010, plaqueZ + 0.010);
    plate.rotation.x = -1.08;
    dress.add(plate);
    scene.add(dress);
    workstations.set(role, dressRole(dress, role, edge, accent, lacquer, trim));
  }

  function dressRole(dress: Group, role: RoleId, edge: number, accent: MeshStandardMaterial, lacquer: MeshStandardMaterial, trim: MeshStandardMaterial): DeskActionRig {
    const handsZ = edge + 0.043;
    const hands = { root: dress, left: new Vector3(0.155, 0.039, handsZ), right: new Vector3(-0.155, 0.039, handsZ) };
    // The bot sits at the local -Z edge, looking in the opposite direction to the desk front.
    const writingPad = (w: number, d: number, x = 0) => put(dress, rbox(w, 0.014, d, 0.014, 2), accent, x, 0.014, edge + d / 2 + 0.011);
    const printed = (kind: Parameters<typeof makeDeskPaper>[0], w: number, d: number, x: number, z: number, y = 0.032) =>
      put(dress, new PlaneGeometry(w, d), new MeshStandardMaterial({ map: makeDeskPaper(kind), roughness: 0.91 }), x, y, z, { rx: -Math.PI / 2 });

    switch (role) {
      case "quant": {
        const board = put(dress, keyboardGeometry(), makeKeyboardMaterial(true), 0, 0.024, edge + 0.068, { cast: true });
        board.scale.x = 1.43;
        const monitorTrim = matte("#70a69a", 0.54, 0.26);
        screen(dress, -0.035, 0.27, 0.04, lineChart, 0.65, 0.27, -0.09, lacquer, monitorTrim);
        put(dress, rbox(0.55, 0.014, 0.19, 0.014, 2), matte("#365e52", 0.95), 0, 0.014, edge + 0.106);
        deskLamp(dress, 0.35, 0.045);
        put(dress, rbox(0.11, 0.025, 0.14, 0.01, 1), fabric, -0.395, 0.026, -0.17, { ry: -0.22 });
        break;
      }
      case "backtest": {
        const board = put(dress, keyboardGeometry(), keys, 0, 0.024, edge + 0.068, { cast: true });
        board.scale.x = 1.43;
        writingPad(0.56, 0.19);
        screen(dress, -0.17, 0.259, 0.039, barChart, 0.43, 0.28, -0.14, lacquer, trim);
        screen(dress, 0.245, 0.225, 0.055, lineChart, 0.24, 0.23, 0.24, lacquer, trim);
        put(dress, rbox(0.15, 0.177, 0.22, 0.023, 2), accent, -0.446, 0.091, 0.103, { cast: true });
        for (let row = 0; row < 3; row += 1) {
          put(dress, rbox(0.092, 0.011, 0.012, 0.004, 1), trim, -0.446, 0.07 + row * 0.034, -0.01);
        }
        break;
      }
      case "literature": {
        const book = new Group();
        book.position.set(0, 0.027, edge + 0.146);
        dress.add(book);
        put(book, rbox(0.49, 0.032, 0.27, 0.012, 1), accent, 0, 0, 0, { cast: true });
        const paper = new MeshStandardMaterial({ map: makeDeskPaper("archive"), roughness: 0.89, side: DoubleSide });
        const leaf = new PlaneGeometry(0.223, 0.246);
        for (const side of [-1, 1]) {
          put(book, rbox(0.223, 0.019, 0.246, 0.006, 1), fabric, side * 0.118, 0.019, 0);
          put(book, leaf, paper, side * 0.118, 0.034, 0, { rx: -Math.PI / 2 });
        }
        const page = buildTurningPage(0.23, 0.246, paper, -1);
        page.pivot.position.y = 0.042;
        page.pivot.name = "turning-ledger-page";
        book.add(page.pivot);
        put(book, rbox(0.012, 0.009, 0.262, 0.002, 1), trim, 0.102, 0.028, -0.01);
        rowOfBooks(-0.23, 0.115, 0.118, 5, 0.43, dress);
        deskLamp(dress, 0.31, 0.083);
        hands.left.set(0.169, 0.064, edge + 0.059);
        hands.right.set(-0.133, 0.062, edge + 0.064);
        return { ...hands, page };
      }
      case "hr": {
        writingPad(0.52, 0.26);
        printed("intake", 0.32, 0.224, 0, edge + 0.14);
        for (const [offset, rotation] of [[-0.06, -0.23], [0, 0.02], [0.062, 0.21]]) {
          const file = put(dress, rbox(0.099, 0.225, 0.042, 0.01, 1), accent, -0.30 + offset, 0.117, 0.097, { rz: rotation, cast: true });
          put(file, rbox(0.065, 0.026, 0.01, 0.003, 1), trim, 0, 0.068, -0.021);
        }
        put(dress, rbox(0.27, 0.045, 0.20, 0.016, 1), lacquer, -0.30, 0.026, 0.099);
        mug(0.31, 0.045, -0.12, "#bc7287", dress);
        plantLocal(dress, 0.38, 0, 0.048, 0.61);
        break;
      }
      case "secretary": {
        writingPad(0.52, 0.27);
        printed("calendar", 0.49, 0.23, 0, edge + 0.143);
        put(dress, rbox(0.28, 0.041, 0.18, 0.011, 2), lacquer, -0.26, 0.026, 0.165, { cast: true });
        put(dress, rbox(0.28, 0.039, 0.18, 0.011, 2), accent, -0.26, 0.111, 0.165, { cast: true });
        for (const x of [-0.39, -0.13]) {
          put(dress, rbox(0.022, 0.104, 0.165, 0.005, 1), trim, x, 0.068, 0.165);
        }
        put(dress, rbox(0.24, 0.017, 0.14, 0.004, 1), fabric, -0.26, 0.134, 0.165, { ry: -0.12 });
        plantLocal(dress, 0.41, 0, -0.035, 0.66);
        break;
      }
      case "ta": {
        writingPad(0.49, 0.264);
        const slate = new Group();
        slate.position.set(-0.14, 0.21, 0.131);
        slate.rotation.y = -0.2;
        slate.rotation.x = -0.15;
        dress.add(slate);
        put(slate, rbox(0.48, 0.304, 0.044, 0.018, 2), lacquer, 0, 0, 0, { cast: true });
        const chalkboard = new MeshStandardMaterial({ map: makeDeskPaper("lesson"), roughness: 0.84, side: DoubleSide });
        const slateFace = new PlaneGeometry(0.438, 0.258);
        put(slate, slateFace, chalkboard, 0, 0, -0.024, { ry: Math.PI });
        put(slate, slateFace, chalkboard, 0, 0, 0.024);
        put(slate, rbox(0.50, 0.025, 0.104, 0.008, 1), trim, 0, -0.159, -0.013);
        put(slate, rbox(0.084, 0.014, 0.017, 0.003, 1), fabric, -0.13, -0.14, -0.052);
        printed("briefing", 0.26, 0.193, 0.053, edge + 0.139);
        put(dress, new CylinderGeometry(0.057, 0.052, 0.087, 10), accent, 0.34, 0.046, 0.048, { cast: true });
        for (const [x, lean] of [[0.308, -0.15], [0.338, 0.1], [0.365, 0.22]]) {
          put(dress, rbox(0.016, 0.15, 0.016, 0.004, 1), trim, x, 0.128, 0.05, { rz: lean });
        }
        break;
      }
      case "ceo": {
        put(dress, rbox(0.33, 0.62, 0.286, 0.03, 2), lacquer, 0.49, -0.456, 0.006, { cast: true });
        for (const y of [-0.661, -0.481, -0.300]) {
          put(dress, rbox(0.286, 0.158, 0.026, 0.011, 1), accent, 0.49, y, 0.147);
          put(dress, rbox(0.077, 0.023, 0.024, 0.004, 1), trim, 0.49, y, 0.164);
        }
        deskLamp(dress, -0.48, 0.063);
        writingPad(0.58, 0.29);
        printed("briefing", 0.37, 0.232, -0.023, edge + 0.135);
        mug(0.36, 0.05, -0.06, "#8b4152", dress);
        put(dress, rbox(0.072, 0.019, 0.10, 0.006, 1), trim, -0.361, 0.028, -0.047);
        break;
      }
    }
    return hands;
  }

  function deskLamp(parent: Object3D, x: number, z: number): void {
    put(parent, new CylinderGeometry(0.055, 0.065, 0.02, 10), metal, x, 0.02, z, { cast: true });
    put(parent, new CylinderGeometry(0.012, 0.012, 0.12, 6), metal, x, 0.08, z);
    put(parent, new CylinderGeometry(0.012, 0.012, 0.12, 6), metal, x + 0.045, 0.14, z, { rz: 1.05 });
    put(parent, new CylinderGeometry(0.01, 0.01, 0.06, 6), metal, x + 0.09, 0.18, z);
    put(parent, rbox(0.12, 0.045, 0.12, 0.016, 1), shade, x + 0.09, 0.22, z, { cast: true });
  }

  function addChair(seat: Seat, upholstery: MeshStandardMaterial, lacquer: MeshStandardMaterial, trim: MeshStandardMaterial): void {
    const chair = new Group();
    chair.position.set(seat.x, 0, seat.z);
    chair.rotation.y = seat.yaw;
    put(chair, rbox(0.36, 0.062, 0.36, 0.04, 2), upholstery, 0, 0.46, 0.02, { cast: true });
    put(chair, rbox(0.36, 0.32, 0.06, 0.03, 2), lacquer, 0, 0.72, 0.16, { cast: true });
    put(chair, rbox(0.31, 0.254, 0.032, 0.016, 2), upholstery, 0, 0.73, 0.126);
    put(chair, rbox(0.218, 0.014, 0.013, 0.004, 1), trim, 0, 0.81, 0.196);
    for (const sx of [-1, 1]) {
      for (const sz of [-1, 1]) {
        put(chair, rbox(0.045, 0.44, 0.045, 0.012, 1), woodDark, sx * 0.14, 0.22, 0.02 + sz * 0.12);
      }
    }
    scene.add(chair);
  }

  function addStool(seat: Seat): void {
    put(scene, new CylinderGeometry(0.16, 0.16, 0.06, 12), wood, seat.x, 0.64, seat.z, { cast: true });
    put(scene, new CylinderGeometry(0.035, 0.04, 0.6, 8), metal, seat.x, 0.32, seat.z, { cast: true });
    put(scene, new TorusGeometry(0.12, 0.012, 6, 14), metal, seat.x, 0.28, seat.z, { rx: Math.PI / 2 });
  }

  function screen(
    parent: Object3D,
    x: number,
    y: number,
    z: number,
    mapTexture: CanvasTexture,
    w: number,
    h: number,
    yaw: number,
    housing: MeshStandardMaterial,
    trim: MeshStandardMaterial,
  ): void {
    const group = new Group();
    group.position.set(x, y, z);
    group.rotation.y = yaw;
    put(group, rbox(w + 0.049, h + 0.060, 0.054, 0.014, 2), housing, 0, 0, 0, { cast: true });
    let glow = screenMat.get(mapTexture);
    if (!glow) {
      glow = new MeshStandardMaterial({
        color: "#e7f3ee",
        roughness: 0.38,
        map: mapTexture,
        emissive: "#ffffff",
        emissiveMap: mapTexture,
        emissiveIntensity: 0.87,
      });
      screenMat.set(mapTexture, glow);
    }
    put(group, new PlaneGeometry(w, h), glow, 0, 0.008, -0.028, { ry: Math.PI });
    put(group, rbox(w * 0.72, 0.019, 0.015, 0.004, 1), trim, 0, h * 0.22, 0.028);
    put(group, rbox(w * 0.38, 0.042, 0.013, 0.004, 1), housing, 0, -h * 0.11, 0.029);
    put(group, rbox(0.080, 0.12, 0.060, 0.012, 1), metal, 0, -y / 2 - h / 4, 0.014, { cast: true });
    put(group, rbox(0.154, 0.023, 0.102, 0.008, 1), housing, 0, -y + 0.015, -0.006, { cast: true });
    parent.add(group);
  }

  function plant(x: number, y: number, z: number, scale: number): void {
    const g = new Group();
    g.position.set(x, y, z);
    g.scale.setScalar(scale);
    plantLocal(g, 0, 0, 0, 1);
    scene.add(g);
  }

  function plantLocal(parent: Object3D, x: number, y: number, z: number, scale: number): void {
    const g = new Group();
    g.position.set(x, y, z);
    g.scale.setScalar(scale);
    put(g, new CylinderGeometry(0.09, 0.11, 0.1, 8), potMat, 0, 0.05, 0, { cast: true });
    put(g, new CylinderGeometry(0.012, 0.014, 0.16, 5), matte("#3e4a32", 0.7), 0, 0.16, 0);
    for (let i = 0; i < 7; i += 1) {
      const a = (i / 7) * Math.PI * 2;
      const frond = put(g, new ConeGeometry(0.045, 0.2, 5), i % 2 ? leaf : leafDark, Math.cos(a) * 0.04, 0.22, Math.sin(a) * 0.04, { cast: true });
      frond.rotation.z = Math.cos(a) * 0.7;
      frond.rotation.x = Math.sin(a) * 0.7;
      frond.scale.set(0.55, 1, 0.22);
    }
    parent.add(g);
  }

  function bookGeo(w: number, h: number, d: number, spine: number): BufferGeometry {
    const slot = spine % 8;
    const key = `${w.toFixed(3)}|${h.toFixed(3)}|${d.toFixed(3)}|${slot}`;
    const cached = bookCache.get(key);
    if (cached) return cached;
    const geo = new BoxGeometry(w, h, d);
    const uv = geo.attributes.uv;
    const u0 = slot / 8;
    const u1 = u0 + 0.11;
    for (let face = 0; face < 6; face += 1) {
      const show = face === 0 || face === 2 || face === 5;
      for (let i = 0; i < 4; i += 1) {
        const idx = face * 4 + i;
        const u = uv.getX(idx);
        const v = uv.getY(idx);
        uv.setXY(idx, show ? u0 + u * (u1 - u0) : u0 + 0.015, show ? 0.04 + v * 0.9 : 0.5);
      }
    }
    uv.needsUpdate = true;
    bookCache.set(key, geo);
    return geo;
  }

  function keyboardGeometry(): BufferGeometry {
    if (keyboardGeo) return keyboardGeo;
    const geo = new BoxGeometry(0.32, 0.026, 0.12);
    const uv = geo.attributes.uv;
    for (let face = 0; face < 6; face += 1) {
      if (face === 2) continue;
      for (let i = 0; i < 4; i += 1) uv.setXY(face * 4 + i, 0.02, 0.02);
    }
    uv.needsUpdate = true;
    keyboardGeo = geo;
    return geo;
  }

  function rowOfBooks(x: number, y: number, z: number, count: number, span: number, parent: Object3D = scene): void {
    const baseline = y - 0.1;
    for (let i = 0; i < count; i += 1) {
      const h = 0.16 + ((i * 3 + 1) % 4) * 0.03;
      const bw = Math.max(0.04, span / count - 0.012);
      const px = x - span / 2 + (i + 0.5) * (span / count);
      put(parent, bookGeo(bw, h, 0.12, i), books, px, baseline + h / 2, z, { cast: true, ry: ((i % 5) - 2) * 0.02 });
    }
  }

  function mug(x: number, y: number, z: number, color: string, parent: Object3D = scene): void {
    put(parent, new CylinderGeometry(0.035, 0.04, 0.06, 8), matte(color, 0.45), x, y, z, { cast: true });
    put(parent, new TorusGeometry(0.02, 0.005, 6, 8), matte(color, 0.45), x + 0.04, y, z);
  }

  function jar(x: number, y: number, z: number, fill: string): void {
    const glass = fork(matte("#e7f1f4", 0.12, 0.05));
    glass.transparent = true;
    glass.opacity = 0.45;
    put(scene, new CylinderGeometry(0.07, 0.08, 0.16, 10), glass, x, y + 0.08, z, { cast: true });
    put(scene, new CylinderGeometry(0.055, 0.06, 0.09, 8), matte(fill, 0.7), x, y + 0.06, z);
    put(scene, new CylinderGeometry(0.075, 0.075, 0.03, 10), wood, x, y + 0.17, z);
  }

  function gift(parent: Group, x: number, z: number, color: string, size: number, turn: number): void {
    const parcel = new Group();
    parcel.position.set(x, 0.03, z);
    parcel.rotation.y = turn;
    const height = size * 0.80;
    put(parcel, rbox(size, height, size, 0.018, 1), matte(color, 0.55), 0, height / 2, 0, { cast: true });
    put(parcel, rbox(size * 1.01, 0.014, size * 0.13, 0.005, 1), gold, 0, height + 0.002, 0);
    put(parcel, rbox(size * 0.13, 0.015, size * 1.01, 0.005, 1), gold, 0, height + 0.004, 0);
    for (const sign of [-1, 1]) {
      put(parcel, rbox(size * 0.13, height, 0.011, 0.003, 1), gold, 0, height / 2, sign * size / 2);
      const loop = put(parcel, new TorusGeometry(size * 0.099, 0.011, 5, 12), gold, sign * size * 0.075, height + size * 0.072, 0, { rz: sign * 0.41 });
      loop.scale.y = 0.63;
    }
    parent.add(parcel);
  }

  function sprinkle(points: Vector3[], material: ReturnType<typeof matte>, radius: number, instanced = false, parent: Object3D = scene): void {
    if (instanced) {
      const mesh = new InstancedMesh(new SphereGeometry(radius, 7, 6), material, points.length);
      const dummy = new Object3D();
      points.forEach((point, index) => {
        dummy.position.copy(point);
        dummy.updateMatrix();
        mesh.setMatrixAt(index, dummy.matrix);
      });
      parent.add(mesh);
      return;
    }
    for (const point of points) put(parent, new SphereGeometry(radius, 7, 6), material, point.x, point.y, point.z);
  }

  function catenary(a: Vector3, b: Vector3, droop: number, steps: number): Vector3[] {
    const points: Vector3[] = [];
    for (let i = 0; i <= steps; i += 1) {
      const t = i / steps;
      const arch = 1 - (t * 2 - 1) ** 2;
      points.push(new Vector3(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t - droop * arch, a.z + (b.z - a.z) * t));
    }
    return points;
  }

}

export function configureRenderer(renderer: WebGLRenderer): void {
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = PCFSoftShadowMap;
  renderer.setClearColor("#d7e6f2", 1);
}
