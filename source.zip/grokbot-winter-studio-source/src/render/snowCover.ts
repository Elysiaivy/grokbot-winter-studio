import { BufferGeometry, CanvasTexture, Color, Float32BufferAttribute, InstancedMesh, Mesh, MeshBasicMaterial, MeshStandardMaterial, PlaneGeometry, RepeatWrapping, SRGBColorSpace, type Object3D, } from "three";
import { firNeedles, makeFirBoughs } from "./fir";

// Periodic value noise. All the outdoor snow uses the same prevailing wind.
const table = new Float32Array(64 * 64);
let seed = 417;
for (let i = 0; i < table.length; i++) {
  seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
  table[i] = seed / 4294967296;
}

export function snowNoise(x: number, z: number): number {
  const i = Math.floor(x), j = Math.floor(z);
  let u = x - i, v = z - j;
  u *= u * (3 - 2 * u);
  v *= v * (3 - 2 * v);
  const a = table[(j & 63) * 64 + (i & 63)], b = table[(j & 63) * 64 + ((i + 1) & 63)];
  const c = table[((j + 1) & 63) * 64 + (i & 63)], d = table[((j + 1) & 63) * 64 + ((i + 1) & 63)];
  return (a + (b - a) * u) * (1 - v) + (c + (d - c) * u) * v;
}

// Wrap the coarse octaves as well as the crystal grain so neighbouring
// texture tiles agree without repeating parallel ripple lines.

function tileNoise(u: number, v: number, across: number, along: number) {
  const x = u * across, z = v * along, ix = Math.floor(x), iz = Math.floor(z);
  const wrap = (i: number, n: number) => ((i % n) + n) % n;
  const x0 = wrap(ix, across), z0 = wrap(iz, along), x1 = (x0 + 1) % across, z1 = (z0 + 1) % along;
  let a = x - ix, b = z - iz;
  a = a * a * (3 - 2 * a);
  b = b * b * (3 - 2 * b);
  return (table[z0 * 64 + x0] * (1 - a) + table[z0 * 64 + x1] * a) * (1 - b)
    + (table[z1 * 64 + x0] * (1 - a) + table[z1 * 64 + x1] * a) * b;
}

function surfaceTile() {
  const size = 384;
  const color = document.createElement("canvas"), relief = document.createElement("canvas");
  color.width = color.height = relief.width = relief.height = size;
  const ctx = color.getContext("2d")!, packed = relief.getContext("2d")!;
  const albedo = ctx.createImageData(size, size), surface = packed.createImageData(size, size);
  for (let j = 0; j < size; j++)
    for (let i = 0; i < size; i++) {
      const u = i / size, v = j / size;
      const mottling = snowNoise(64 * u, 64 * v);
      const grain = table[(j & 63) * 64 + (i & 63)];
      const warpedV = v + .14 * (tileNoise(u, v, 4, 3) - .5);
      const wind = tileNoise(u + warpedV, warpedV, 5, 13);
      const ridges = tileNoise(u - .05 * wind, warpedV, 21, 32);
      const value = 237 + 8 * (wind - .5) + 7 * (ridges - .5) + 12 * (mottling - .5) + 8 * (grain - .5);
      const k = (j * size + i) * 4;
      albedo.data[k] = value;
      albedo.data[k + 1] = value + 1;
      albedo.data[k + 2] = value + 3;
      // Only the taper at a melt boundary reaches the alpha-test threshold.
      albedo.data[k + 3] = 113 + 88 * mottling + 54 * grain;
      surface.data[k] = 64 + 39 * wind + 41 * ridges + 59 * mottling + 27 * grain;
      surface.data[k + 1] = 200 + 34 * mottling + 17 * grain;
      surface.data[k + 2] = 0;
      surface.data[k + 3] = 255;
    }
  ctx.putImageData(albedo, 0, 0);
  packed.putImageData(surface, 0, 0);
  const map = new CanvasTexture(color), finish = new CanvasTexture(relief);
  map.colorSpace = SRGBColorSpace;
  for (const tex of [map, finish]) {
    tex.wrapS = tex.wrapT = RepeatWrapping;
    tex.repeat.set(.47, .47);
    tex.anisotropy = 4;
  }
  return new MeshStandardMaterial({ map, bumpMap: finish, bumpScale: .017, roughnessMap: finish,
    roughness: 1, metalness: 0, vertexColors: true, alphaTest: .32, envMapIntensity: .34 });
}
const powder = surfaceTile();
const frostFilm = powder.clone();
frostFilm.transparent = true;
frostFilm.depthWrite = false;
frostFilm.alphaTest = .018;
frostFilm.bumpScale = .006;
const crust = new Color("#a0b5c3"), fresh = new Color("#f5f5ee");
type Field = (x: number, z: number) => number;
interface Bounds {
  left: number;
  right: number;
  front: number;
  back: number;
}
type SnowPoint = {
  x: number;
  z: number;
  cover: number;
};

// Clip each triangle at the melt line. The snow thins and cools in colour at
// the exposed slate. Shared vertices keep the low relief continuous in sunlight.

export function laySnow(parent: Object3D, bounds: Bounds, height: Field, coverage: Field, deep: number, outer: Bounds = bounds): void {
  const { left, right, front, back } = bounds;
  const cols = Math.ceil((right - left) / 0.078), rows = Math.ceil((back - front) / 0.078);
  if (cols < 1 || rows < 1)
    return;
  const position: number[] = [], colors: number[] = [], uv: number[] = [], indices: number[] = [];
  const vertices = new Map<string, number>();
  const surfaceColor = new Color();
  function vertex(p: SnowPoint): number {
    const key = Math.round(p.x * 10000) + "," + Math.round(p.z * 10000);
    const existing = vertices.get(key);
    if (existing !== undefined)
      return existing;
    const packed = Math.min(1, Math.max(0, (p.cover - 0.038) * 2.55));
    const wind = snowNoise(p.x * .84 + p.z * .19, p.z * 2.8 - p.x * .50);
    const h = deep * Math.pow(packed, 1.14) * (.69 + .45 * wind);
    const varied = Math.min(1, 0.13 + 0.75 * Math.sqrt(packed) + .13 * wind);
    surfaceColor.copy(crust).lerp(fresh, varied);
    const idx = position.length / 3;
    position.push(p.x, height(p.x, p.z) + 0.003 + h, p.z);
    colors.push(surfaceColor.r, surfaceColor.g, surfaceColor.b, Math.min(1, .27 + p.cover * 10));
    uv.push(p.x, p.z);
    vertices.set(key, idx);
    return idx;
  }
  function triangle(a: SnowPoint, b: SnowPoint, c: SnowPoint): void {
    const polygon: number[] = [];
    let previous = c;
    for (const current of [a, b, c]) {
      if ((previous.cover > 0) !== (current.cover > 0)) {
        const t = previous.cover / (previous.cover - current.cover);
        polygon.push(vertex({ x: previous.x + (current.x - previous.x) * t,
          z: previous.z + (current.z - previous.z) * t, cover: 0 }));
      }
      if (current.cover > 0)
        polygon.push(vertex(current));
      previous = current;
    }
    for (let i = 2; i < polygon.length; i++)
      indices.push(polygon[0], polygon[i - 1], polygon[i]);
  }
  const grid: SnowPoint[][] = [];
  for (let j = 0; j <= rows; j++) {
    const row: SnowPoint[] = [];
    for (let i = 0; i <= cols; i++) {
      const x = left + (right - left) * i / cols, z = front + (back - front) * j / rows;
      row.push({ x, z, cover: coverage(x, z) + .053 + .038 * (snowNoise(x * 10, z * 12) - .5) });
    }
    grid.push(row);
  }
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < cols; i++) {
      const a = grid[j][i], b = grid[j + 1][i], c = grid[j + 1][i + 1], d = grid[j][i + 1];
      triangle(a, b, c);
      triangle(a, c, d);
    }
  // A loose film breaks up the transition from bare shingles to deep snow;
  // the underlying roof and its seams still show through the sparse crystals.
  if ((right - left) * (back - front) > 1.7) {
    const pos: number[] = [], tint: number[] = [], tex: number[] = [], ix: number[] = [];
    const cached = new Map<SnowPoint, number>();
    const dustVertex = (point: SnowPoint) => {
      const known = cached.get(point);
      if (known !== undefined)
        return known;
      const { x, z, cover } = point;
      const n = snowNoise(x * 5.1 + 1.6, z * 8.6);
      const alpha = Math.max(0, Math.min(.68, (cover + .17 + n * .035) * 2.8)) * (.60 + .40 * n);
      const id = pos.length / 3;
      pos.push(x, height(x, z) + .0018, z);
      tex.push(x, z);
      tint.push(.81, .87, .90, alpha);
      cached.set(point, id);
      return id;
    };
    for (let j = 0; j < rows; j++)
      for (let i = 0; i < cols; i++) {
        const a = grid[j][i], b = grid[j + 1][i], c = grid[j + 1][i + 1], d = grid[j][i + 1];
        if (Math.max(a.cover, b.cover, c.cover, d.cover) < -.21 || Math.min(a.cover, b.cover, c.cover, d.cover) > .12)
          continue;
        ix.push(dustVertex(a), dustVertex(b), dustVertex(c), dustVertex(a), dustVertex(c), dustVertex(d));
      }
    if (ix.length) {
      const film = new BufferGeometry();
      film.setAttribute("position", new Float32BufferAttribute(pos, 3));
      film.setAttribute("uv", new Float32BufferAttribute(tex, 2));
      film.setAttribute("color", new Float32BufferAttribute(tint, 4));
      film.setIndex(ix);
      film.computeVertexNormals();
      const dust = new Mesh(film, frostFilm);
      dust.receiveShadow = true;
      dust.userData.selectionIgnore = true;
      parent.add(dust);
    }
  }
  // A drift that reaches the fascia curls over the edge. Taper its lip to the
  // substrate, especially at a gable end where its profile is seen from below.
  function cornice(a: SnowPoint, b: SnowPoint, dx: number, dz: number): void {
    if (a.cover <= 0 && b.cover <= 0)
      return;
    if (a.cover <= 0 || b.cover <= 0) {
      const t = a.cover / (a.cover - b.cover);
      const edge = { x: a.x + (b.x - a.x) * t, z: a.z + (b.z - a.z) * t, cover: 0 };
      if (a.cover <= 0)
        a = edge;
      else
        b = edge;
    }
    const end = (p: SnowPoint) => {
      const top = vertex(p);
      const base = height(p.x, p.z);
      const thick = position[top * 3 + 1] - base;
      const begin = position.length / 3;
      const reach = Math.min(0.046, thick * 0.52);
      position.push(p.x + dx * reach, base + thick * 0.47, p.z + dz * reach, p.x + dx * reach * 0.62, base - thick * 0.20, p.z + dz * reach * 0.62);
      colors.push(crust.r, crust.g, crust.b, 1, crust.r * .88, crust.g * .88, crust.b * .91, .78);
      uv.push(p.x, p.z, p.x, p.z);
      return [top, begin, begin + 1];
    };
    const [at, am, ab] = end(a), [bt, bm, bb] = end(b);
    indices.push(at, bt, am, bt, bm, am, am, bm, ab, bm, bb, ab);
  }
  for (let i = 0; i < cols; i++) {
    if (front === outer.front)
      cornice(grid[0][i], grid[0][i + 1], 0, -1);
    if (back === outer.back)
      cornice(grid[rows][i + 1], grid[rows][i], 0, 1);
  }
  for (let j = 0; j < rows; j++) {
    if (left === outer.left)
      cornice(grid[j + 1][0], grid[j][0], -1, 0);
    if (right === outer.right)
      cornice(grid[j][cols], grid[j + 1][cols], 1, 0);
  }
  if (!indices.length)
    return;
  const geo = new BufferGeometry();
  geo.setAttribute("position", new Float32BufferAttribute(position, 3));
  geo.setAttribute("color", new Float32BufferAttribute(colors, 4));
  geo.setAttribute("uv", new Float32BufferAttribute(uv, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  const mesh = new Mesh(geo, powder);
  mesh.castShadow = mesh.receiveShadow = true;
  parent.add(mesh);
}

// A shallow, wind-tailed deposit with a feathered rim. The optional substrate
// height keeps the cover in contact with a sloping bank or an exposed rock.

export function snowPatch(parent: Object3D, x: number, y: number, z: number, width: number, depth: number, thickness: number, variation: number, substrate?: Field) {
  const vertices: number[] = [], colors: number[] = [], uv: number[] = [], indices: number[] = [];
  const tone = new Color();
  const rings = 8, spokes = 28;
  function vertex(radius: number, angle: number) {
    const cos = Math.cos(angle), sin = Math.sin(angle);
    const edge = .86 + .22 * snowNoise(variation + cos * 3, sin * 3 + 4)
      + .08 * Math.sin(angle * 3 + variation);
    const dx = width * .5 * (cos * radius * edge + .15 * radius * radius);
    const dz = depth * .5 * (sin * radius * edge + .17 * Math.sin(cos * 3 + variation) * radius);
    const n = snowNoise(variation + dx * 3.7, dz * 6.2);
    const lobe = Math.max(0, 1 - radius ** 1.75) ** 1.55;
    const lift = thickness * lobe * (.62 + .45 * n - .23 * cos * radius);
    const idx = vertices.length / 3;
    vertices.push(x + dx, y + (substrate?.(dx, dz) ?? 0) + .003 + lift, z + dz);
    tone.copy(crust).lerp(fresh, Math.min(1, .23 + .54 * Math.sqrt(lobe) + .20 * n));
    colors.push(tone.r, tone.g, tone.b, Math.min(1, .26 + (1 - radius) * 9));
    uv.push(x + dx, z + dz);
    return idx;
  }
  vertex(0, 0);
  for (let ring = 1; ring <= rings; ring++)
    for (let i = 0; i < spokes; i++) {
      const current = vertex(ring / rings, Math.PI * 2 * i / spokes);
      const next = 1 + (ring - 1) * spokes + (i + 1) % spokes;
      if (ring === 1)
        indices.push(0, next, current);
      else
        indices.push(current - spokes, next, current, current - spokes, next - spokes, next);
    }
  const g = new BufferGeometry();
  g.setAttribute("position", new Float32BufferAttribute(vertices, 3));
  g.setAttribute("uv", new Float32BufferAttribute(uv, 2));
  g.setAttribute("color", new Float32BufferAttribute(colors, 4));
  g.setIndex(indices);
  g.computeVertexNormals();
  const deposit = new Mesh(g, powder);
  deposit.castShadow = deposit.receiveShadow = true;
  parent.add(deposit);
  return deposit;
}

export function snowOnRock(rock: Mesh, seed: number) {
  // Query the actual low-poly face, rather than balancing a smaller ellipsoid on it.
  const p = rock.geometry.getAttribute("position");
  const idx = rock.geometry.index;
  const count = idx?.count ?? p.count;
  const faces: number[][] = [];
  for (let i = 0; i < count; i += 3) {
    const a = idx ? idx.getX(i) : i, b = idx ? idx.getX(i + 1) : i + 1, c = idx ? idx.getX(i + 2) : i + 2;
    const ax = p.getX(a), az = p.getZ(a), dx1 = p.getX(b) - ax, dz1 = p.getZ(b) - az;
    const dx2 = p.getX(c) - ax, dz2 = p.getZ(c) - az, det = dx1 * dz2 - dz1 * dx2;
    if (det < -.00001)
      faces.push([ax, az, dx1, dz1, dx2, dz2, 1 / det, p.getY(a), p.getY(b) - p.getY(a), p.getY(c) - p.getY(a)]);
  }
  const cap = snowPatch(rock, -.024, 0, .004, .76, .77, .12, seed, (dx, dz) => {
    const x = dx - .024, z = dz + .004;
    for (const [ax, az, bx, bz, cx, cz, inv, ay, by, cy] of faces) {
      const u = ((x - ax) * cz - (z - az) * cx) * inv, v = (bx * (z - az) - bz * (x - ax)) * inv;
      if (u >= -.0001 && v >= -.0001 && u + v <= 1.0001)
        return ay + u * by + v * cy;
    }
    return 0;
  });
  return cap;
}
let flakeMaterial: MeshBasicMaterial | undefined;

export function snowFlakes(count: number) {
  if (!flakeMaterial) {
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 48;
    const ctx = canvas.getContext("2d")!;
    const image = ctx.createImageData(48, 48);
    for (let y = 0; y < 48; y++)
      for (let x = 0; x < 48; x++) {
        const dx = (x - 23.5) / 22, dy = (y - 23.5) / 22;
        const distance = Math.hypot(dx * 1.15, dy) + .10 * Math.sin(dx * 5 + dy * 7);
        const alpha = Math.max(0, 1 - distance * distance);
        const k = (y * 48 + x) * 4;
        image.data[k] = 237;
        image.data[k + 1] = 244;
        image.data[k + 2] = 249;
        image.data[k + 3] = 224 * alpha * alpha;
      }
    ctx.putImageData(image, 0, 0);
    const map = new CanvasTexture(canvas);
    map.colorSpace = SRGBColorSpace;
    flakeMaterial = new MeshBasicMaterial({ map, transparent: true, opacity: .83, depthWrite: false, alphaTest: .025 });
  }
  const mesh = new InstancedMesh(new PlaneGeometry(.078, .078), flakeMaterial, count);
  mesh.frustumCulled = false;
  mesh.userData.selectionIgnore = true;
  mesh.name = "falling-snow";
  mesh.instanceMatrix.setUsage(35048);
  return mesh;
}
const needles = new Color("#31594b"), newGrowth = new Color("#597364");
const snowOnNeedles = powder.clone();
snowOnNeedles.alphaTest = 0;
snowOnNeedles.bumpScale = .009;

// A snowy tier shares vertices around the branch whorl. Load varies across
// branches and falls away toward the unsupported tips and the underside.

export function winterBough(radius: number, height: number, phase: number) {
  const segments = 40, rings = 6;
  const p: number[] = [], c: number[] = [], uv: number[] = [], indices: number[] = [];
  const tint = new Color(), frost = new Color();
  for (let row = 0; row <= rings; row++)
    for (let i = 0; i < segments; i++) {
      const a = i * Math.PI * 2 / segments, nx = Math.cos(a), nz = Math.sin(a), t = row / rings;
      const branch = .5 + .5 * Math.cos(a * 10 + phase * .61);
      const lee = snowNoise(phase + nx * 2.2, nz * 2.2 + .41);
      const tip = .71 + .24 * branch + .10 * lee;
      const r = radius * (.012 + t * tip) * .94;
      const x = r * nx, z = r * nz;
      const retained = Math.max(0, Math.min(1, (.31 + lee * .69 + branch * .18 - t * .85 + (snowNoise(x * 16 + phase, z * 13) - .5) * .22) * 3.0));
      const y = height * (1 - t ** .88) - height * .13 * t * t * branch + retained * radius * .065;
      p.push(x, y, z);
      uv.push(x, z);
      frost.copy(crust).lerp(fresh, .47 + .46 * lee);
      tint.copy(needles).lerp(newGrowth, .16 + .47 * branch).lerp(frost, retained);
      c.push(tint.r, tint.g, tint.b);
      if (row < rings) {
        const k = row * segments + i, n = row * segments + (i + 1) % segments;
        indices.push(k, n, k + segments, n, n + segments, k + segments);
      }
    }
  const bottom = p.length / 3;
  p.push(0, -height * .13, 0);
  uv.push(0, 0);
  c.push(needles.r, needles.g, needles.b);
  for (let i = 0; i < segments; i++)
    indices.push(rings * segments + i, rings * segments + (i + 1) % segments, bottom);
  const g = new BufferGeometry();
  g.setAttribute("position", new Float32BufferAttribute(p, 3));
  g.setAttribute("uv", new Float32BufferAttribute(uv, 2));
  g.setAttribute("color", new Float32BufferAttribute(c, 3));
  g.setIndex(indices);
  g.computeVertexNormals();
  const branch = new Mesh(g, snowOnNeedles);
  branch.castShadow = branch.receiveShadow = true;
  const tips = new Mesh(makeFirBoughs(radius * 1.10, height * .71, phase, 2), firNeedles);
  tips.position.y = -height * .018;
  branch.add(tips);
  return branch;
}
