import { BufferGeometry, CanvasTexture, Color, Float32BufferAttribute, Group, Mesh, MeshStandardMaterial, PlaneGeometry, SRGBColorSpace, type Material } from "three";
import { batch, beam, box, cyl, group, lit, oval, paint, part, placard, timberPaint } from "./townCraft";
import { makeBrickTexture, textured } from "./factory";
import { laySnow, snowNoise } from "./snowCover";
import { heightAt } from "./townLand";
export const BAKERY = { x: 10.7, z: -2.73 }, POST = { x: 13.36, z: 1.43 };
const cream = paint("#efdfbc"), pine = timberPaint("#b89470"), walnut = timberPaint("#80664d"), iron = paint("#435158"), snow = paint("#dbe5e8"), slate = paint("#4c5e67");
const brass = paint("#b59860"), paper = paint("#ece1c6"), brick = paint("#945a48"), dough = paint("#c39156");
const windowLight = lit("#deb98a", "#f0af68"), ovenLight = lit("#eaa268", "#df782e");

function glazing() {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 192;
  const g = c.getContext("2d")!, shade = g.createLinearGradient(0, 0, 0, 192);
  shade.addColorStop(0, "#ba9e79");
  shade.addColorStop(.42, "#e4cf99");
  shade.addColorStop(.84, "#c9ac86");
  shade.addColorStop(1, "#9c8e79");
  g.fillStyle = shade;
  g.fillRect(0, 0, 256, 192);
  for (let i = 0; i < 18; i++) {
    g.fillStyle = i % 2 ? "#dac6a57e" : "#eee0c35c";
    g.fillRect(i * 2.5, 0, 2, 155 + i * .75);
    g.fillRect(254 - i * 1.6, 0, 2, 161 + i * .65);
  }
  g.fillStyle = "#706e58";
  g.fillRect(172, 147, 16, 39);
  g.fillStyle = "#72745c";
  for (let i = 0; i < 8; i++) {
    const a = i * 2.4;
    g.beginPath();
    g.ellipse(180 + Math.cos(a) * 10, 138 + Math.sin(a) * 13, 6, 14, a, 0, Math.PI * 2);
    g.fill();
  }
  for (let i = 0; i < 5; i++) {
    g.fillStyle = i % 2 ? "#9b7963" : "#748274";
    g.fillRect(51 + i * 6, 149 - i % 3 * 3, 5, 35 + i % 3 * 3);
  }
  const tex = new CanvasTexture(c);
  tex.colorSpace = SRGBColorSpace;
  tex.anisotropy = 4;
  const mat = new MeshStandardMaterial({ map: tex, emissiveMap: tex, emissive: "#d6ae76", roughness: .40 });
  return mat;
}
const glazed = glazing();

function pane(p: Group, x: number, y: number, z: number, w: number, h: number, split = true) {
  box(p, cream, x, y, z, w + .13, h + .13, .10);
  box(p, walnut, x, y, z - .061, w + .026, h + .024, .028);
  box(p, glazed, x, y, z - .082, w, h, .035);
  if (split) {
    box(p, cream, x, y, z - .109, .044, h, .038);
    box(p, cream, x, y + .10 * h, z - .11, w, .036, .038);
  }
  box(p, cream, x, y - h / 2 - .075, z - .07, w + .21, .075, .19);
}

function door(p: Group, x: number, z: number, w: number, h: number, color: Material) {
  box(p, cream, x, h / 2, z, w + .14, h + .07, .13);
  box(p, color, x, h / 2, z - .075, w, h, .08);
  for (let i = 0; i < 3; i++)
    box(p, walnut, x - w * .28 + i * w * .28, h * .26, z - .12, .016, h * .38, .018);
  pane(p, x, h * .72, z - .12, w * .53, h * .29, false);
  oval(p, brass, x - w * .35, h * .48, z - .14, .056, .053, .07);
  box(p, slate, x, .043, z - .19, w + .25, .09, .37);
}

function gable(parent: Group, w: number, rise: number, y: number, z: number, m: Material) {
  const g = new BufferGeometry();
  g.setAttribute("position", new Float32BufferAttribute([-w / 2, y, z, w / 2, y, z, 0, y + rise, z], 3));
  g.setAttribute("uv", new Float32BufferAttribute([0, 0, 1, 0, .5, 1], 2));
  g.computeVertexNormals();
  const face = new Mesh(g, m);
  face.castShadow = true;
  parent.add(face);
}

function lantern(p: Group, x: number, y: number, z: number) {
  box(p, iron, x, y + .24, z - .11, .06, .08, .27);
  cyl(p, iron, x, y + .13, z - .21, .22, .075);
  cyl(p, windowLight, x, y, z - .21, .15, .21);
  cyl(p, iron, x, y - .13, z - .21, .18, .052);
}
type House = {
  house: Group;
  lid: Group;
  inside: Group;
  outside: Group;
  w: number;
  d: number;
  h: number;
};
type HouseStyle = {
  x: number;
  z: number;
  rotation: number;
  w: number;
  d: number;
  h: number;
  rise: number;
  color: string;
  roof: string;
  frontDoor?: boolean;
  site?: string;
};

function house(root: Group, style: HouseStyle): House {
  const { x, z, rotation, w, d, h, rise } = style;
  const g = group(root, x, heightAt(x, z) + .095, z);
  g.rotation.y = rotation;
  g.name = style.site ? 'hotspot-' + style.site : '';
  const outer = group(g), lid = group(g), inside = group(g), retail = Boolean(style.site);
  const wall = timberPaint(style.color), join = paint(new Color(style.color).multiplyScalar(.72).getStyle()), roof = paint(style.roof);
  wall.side = 2;
  box(outer, paint("#6b7273"), 0, -.15, 0, w + .12, .39, d + .12);
  box(outer, pine, 0, .015, 0, w, .085, d);
  // Back and left walls frame the open dollhouse; the front, right and roof lift together.
  box(outer, wall, 0, h / 2, d / 2, w, h, .13);
  box(outer, wall, -w / 2, h / 2, 0, .13, h, d);
  box(lid, wall, 0, h / 2, -d / 2, w, h, .13);
  box(lid, wall, w / 2, h / 2, 0, .13, h, d);
  for (let i = 0; i <= Math.floor(w / .23); i++) {
    const u = -w / 2 + .08 + i * .23;
    box(lid, join, u, h / 2, -d / 2 - .067, .032, h - .04, .022);
    box(outer, join, u, h / 2, d / 2 + .068, .032, h - .04, .022);
  }
  for (let i = 0; i <= Math.floor(d / .235); i++) {
    const u = -d / 2 + .08 + i * .235;
    box(lid, join, w / 2 + .068, h / 2, u, .022, h - .04, .032);
    box(outer, join, -w / 2 - .068, h / 2, u, .022, h - .04, .032);
  }
  for (const s of [-1, 1]) {
    for (const t of [-1, 1])
      box(t < 0 || s > 0 ? lid : outer, cream, s * w / 2, h / 2, t * d / 2, .13, h + .06, .14);
    const frontZ = s * d / 2;
    gable(lid, w, rise, h, frontZ, wall);
    box(lid, cream, 0, h - .03, frontZ, w + .14, .1, .19);
  }
  const angle = Math.atan2(rise, w / 2), span = Math.hypot(w / 2, rise) + .31;
  const rd = d + .58;
  for (const s of [-1, 1]) {
    const anchor = group(lid, s * (w / 4 + .09), h + rise / 2 - .09 * Math.tan(angle), 0);
    anchor.rotation.z = -s * angle;
    box(anchor, roof, 0, 0, 0, span, .16, rd);
    const bounds={left:-span/2,right:span/2,front:-rd/2,back:rd/2};
    laySnow(anchor,bounds,()=>.087,(u,v)=>{
      const localX=s*(w/4+.09)+u*Math.cos(angle);
      const gust=snowNoise(x*1.13+localX*.86+v*.22,z*.84+v*1.86-localX*.59);
      const downslope=.48+s*u/span;
      const warmFlue=Math.exp(-(((localX+w*.22)/.32)**2+((v-d*.24)/.45)**2));
      const runoff=snowNoise(x+localX*.65,z+v*4.4);
      const lip=Math.max(0,downslope-.76)*.62*(gust+.2);
      return .044+downslope*.13+(gust-.43)*.56+(runoff-.5)*.16+s*.066+lip-warmFlue*.49;
    },.135);
    for (let k=0;k<6;k++)
      box(anchor,slate,0,.083,(k-2.5)*rd/6,span,.035,.035);
    for (const t of [-1, 1])
      box(anchor, cream, 0, -.025, t * rd * .5, span, .15, .09);
    box(anchor, slate, s * span * .5, -.10, 0, .09, .13, rd);
  }
  const chim = group(lid, -w * .22, h + rise * .7, d * .24);
  box(chim, brick, 0, .33, 0, .36, .79, .40);
  box(chim, walnut, 0, .74, 0, .44, .12, .48);
  box(chim, snow, 0, .812, 0, .44, .044, .48);
  box(chim, iron, 0, .84, 0, .23, .02, .25);
  const sideWin = group(lid, w / 2 + .075, 0, .12);
  sideWin.rotation.y = -Math.PI / 2;
  pane(sideWin, 0, h * .54, 0, Math.min(1, d * .39), .78);
  const leftWin = group(outer, -w / 2 - .075, 0, .08);
  leftWin.rotation.y = Math.PI / 2;
  pane(leftWin, 0, h * .55, 0, .75, .76);
  const backWin = group(outer, 0, 0, d / 2 + .08);
  backWin.rotation.y = Math.PI;
  if (style.site === "post")
    door(backWin, -.90, 0, .66, 1.51, paint("#4e625c"));
  else
    pane(backWin, .22, h * .54, 0, .83, .77);
  if (retail) {
    const innerPaint = paint(style.site === "bakery" ? "#d6c39e" : "#bcc2a7");
    box(inside, innerPaint, 0, h / 2, d / 2 - .081, w - .13, h - .025, .04);
    box(inside, innerPaint, -w / 2 + .078, h / 2, 0, .04, h - .02, d - .15);
    box(inside, cream, 0, .15, d / 2 - .11, w - .12, .21, .065);
    for (let i = 0; i < Math.floor(w / .24); i++)
      box(inside, i % 4 ? pine : timberPaint("#a58160"), -w / 2 + .16 + i * .24, .063, 0, .232, .024, d - .10);
  }
  if (style.frontDoor !== false) {
    door(lid, w * .265, -d / 2 - .08, retail ? .73 : .62, retail ? 1.64 : 1.48, paint(style.site === "bakery" ? "#47665c" : "#5d6861"));
    pane(lid, -w * .18, h * .49, -d / 2 - .078, w * (retail ? .42 : .33), retail ? .91 : .8);
    lantern(lid, w * .43, h * .72, -d / 2 - .09);
  }
  return { house: g, lid, inside, outside: outer, w, d, h };
}

function finishHouse(h: House) {
  batch(h.lid);
  batch(h.outside);
  batch(h.inside);
  h.house.userData.keep = true;
}

function sign(h: House, title: string, sub: string, bg: string, ink: string) {
  const z = -h.d / 2 - .10;
  box(h.lid, walnut, 0, h.h - .17, z, h.w * .80, .48, .12);
  placard(h.lid, title, sub, 0, h.h - .17, z - .066, h.w * .77, .43, bg, ink);
}

function table(p: Group, x: number, z: number, w: number, d: number, h: number) {
  box(p, pine, x, h, z, w, .10, d);
  for (const a of [-1, 1])
    for (const b of [-1, 1])
      box(p, walnut, x + a * (w / 2 - .095), h / 2, z + b * (d / 2 - .08), .09, h, .085);
  box(p, pine, x, .17, z, w - .12, .065, d - .13);
}

function crate(p: Group, x: number, y: number, z: number, w = .50, d = .40) {
  box(p, pine, x, y + .15, z, w, .30, d);
  for (const s of [-1, 1]) {
    for (const t of [-1, 1])
      box(p, walnut, x + s * (w / 2 - .035), y + .15, z + t * d / 2, .058, .32, .025);
    box(p, walnut, x, y + .292, z + s * d / 2, w + .02, .045, .034);
  }
}

function sack(p: Group, x: number, y: number, z: number) {
  oval(p, paint("#cfbb91"), x, y + .22, z, .35, .47, .32);
  cyl(p, walnut, x, y + .405, z, .135, .047);
  oval(p, cream, x, y + .446, z, .17, .09, .13);
}

function bun(p: Group, x: number, y: number, z: number) {
  oval(p, dough, x, y + .045, z, .168, .088, .16);
  const swirl = paint("#945e3b");
  let px = x, pz = z;
  for (let i = 1; i <= 13; i++) {
    const a = i * .73, r = .0048 * i, nx = x + Math.cos(a) * r, nz = z + Math.sin(a) * r;
    beam(p, swirl, [px, y + .086, pz], [nx, y + .086 - (r * .21), nz], .012);
    px = nx;
    pz = nz;
  }
}

function bakeryInterior(h: House) {
  const p = h.inside;
  const oven = group(p, -.79, .07, .63);
  const masonry = textured(makeBrickTexture(), .92, .73, .78);
  box(oven, masonry, 0, .57, .11, 1.34, 1.08, 1.00);
  box(oven, slate, 0, .26, -.02, 1.47, .13, 1.17);
  box(oven, masonry, 0, 1.39, .40, .69, .77, .45);
  for (let row = 0; row < 4; row++)
    for (let col = 0; col < 5; col++) {
      const x = -.54 + col * .256 + (row % 2) * .054;
      if (Math.abs(x) < .37 && row < 3)
        continue;
      box(oven, paint(row % 2 ? "#ac7259" : "#a36752"), x, .37 + row * .196, -.409, .236, .164, .035);
    }
  oval(oven, iron, 0, .66, -.44, .83, .72, .075);
  box(oven, iron, 0, .50, -.46, .80, .32, .05);
  // Dark masonry remains visible between the logs and the small tongues of flame.
  oval(oven, paint("#3d2822"), 0, .61, -.492, .68, .49, .035);
  const ember = lit("#c5723c", "#d86c21");
  for (let i = 0; i < 6; i++) {
    const px = -.22 + i * .086;
    oval(oven, ember, px, .493, -.518, .12, .073, .021);
    oval(oven, i % 2 ? ovenLight : ember, px + .016, .549 + (i % 3) * .016, -.522, .066, .13 + (i % 3) * .044, .018).rotation.z = .16 * (i % 3 - 1);
  }
  for (let i = 0; i < 9; i++) {
    const a = (i + .5) * Math.PI / 9;
    const b = box(oven, paint("#d29b76"), .445 * Math.cos(a), .64 + .39 * Math.sin(a), -.50, .17, .18, .135);
    b.rotation.z = a - Math.PI / 2;
  }
  for (let i = 0; i < 4; i++)
    oval(oven, walnut, -.23 + i * .14, .47, -.52, .15, .073, .073);
  box(oven, slate, 0, .383, -.55, 1.25, .077, .34);
  const bench = group(p, .24, .08, -.60);
  table(bench, 0, 0, 1.73, .60, .72);
  oval(bench, cream, -.25, .776, .015, .53, .014, .26);
  const pin = cyl(bench, pine, -.22, .84, .018, .10, .43);
  pin.rotation.z = Math.PI / 2;
  beam(bench, walnut, [-.53, .84, .018], [.10, .84, .018], .045);
  box(bench, iron, .47, .78, .015, .52, .021, .365);
  for (let i = 0; i < 4; i++)
    bun(bench, .35 + (i % 2) * .18, .795, -.067 + Math.floor(i / 2) * .17);
  for (let i = 0; i < 2; i++)
    sack(bench, -.48 + i * .34, .196, .015);
  const peel = group(p, -1.32, .09, -.30);
  beam(peel, walnut, [0, 0, 0], [.1, 1.23, .08], .053);
  oval(peel, pine, .10, 1.37, .08, .31, .38, .07);
  for (let i = 0; i < 5; i++) {
    const r = box(oven, paint(i % 2 ? "#c18b68" : "#ae7859"), -.55 + i * .245, 1.06, -.415, .226, .134, .061);
    r.rotation.z = .009 * i;
  }
  const rack = group(p, 1.14, .08, .57);
  for (const a of [-1, 1])
    for (const b of [-1, 1])
      box(rack, iron, a * .42, .67, b * .23, .047, 1.32, .047);
  for (let layer = 0; layer < 4; layer++) {
    const y = .24 + layer * .31;
    box(rack, iron, 0, y, 0, .9, .035, .51);
    for (let i = 0; i < 4; i++)
      bun(rack, -.27 + i * .18, y + .018, .025);
  }
  placard(p, "KANELBULLAR", "BAGERI", .30, 1.43, h.d / 2 - .115, .78, .45, "#48655a", "#ecd9aa");
  sack(h.outside, h.w * .5 + .33, 0, -.66);
  sack(h.outside, h.w * .5 + .37, 0, -.27);
}

function cardSurface(stamped: boolean) {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 320;
  const g = c.getContext("2d")!;
  g.fillStyle = "#eee3c5";
  g.fillRect(0, 0, 512, 320);
  g.strokeStyle = "#ab9c7e";
  g.lineWidth = 3;
  g.strokeRect(12, 12, 488, 296);
  g.fillStyle = "#52645f";
  g.font = "bold 31px Georgia";
  g.fillText("BREVKORT", 29, 57);
  g.font = "19px Georgia";
  g.fillText("Tallvik", 31, 93);
  g.fillRect(253, 73, 2, 176);
  for (let i = 0; i < 3; i++)
    g.fillRect(286, 159 + i * 34, 155 - i * 9, 2);
  g.fillStyle = "#7a9080";
  g.fillRect(407, 29, 52, 69);
  g.fillStyle = "#e4d4ac";
  g.fillRect(415, 36, 36, 54);
  g.fillStyle = "#637970";
  g.fillRect(425, 48, 15, 31);
  if (stamped) {
    g.save();
    g.translate(142, 180);
    g.rotate(-.22);
    g.strokeStyle = g.fillStyle = "#965744";
    g.lineWidth = 8;
    for (const r of [61, 53]) {
      g.beginPath();
      g.arc(0, 0, r, 0, Math.PI * 2);
      g.stroke();
    }
    g.textAlign = "center";
    g.font = "bold 22px Georgia";
    g.fillText("TALLVIK", 0, -8);
    g.font = "bold 17px Georgia";
    g.fillText("SJÖPOST", 0, 17);
    g.restore();
  }
  const t = new CanvasTexture(c);
  t.colorSpace = SRGBColorSpace;
  t.anisotropy = 4;
  return new MeshStandardMaterial({ map: t, roughness: .88 });
}

function townChart() {
  const c = document.createElement("canvas");
  c.width = 400;
  c.height = 284;
  const g = c.getContext("2d")!;
  g.fillStyle = "#dfd3b4";
  g.fillRect(0, 0, 400, 284);
  g.fillStyle = "#819d9c";
  g.fillRect(12, 13, 376, 258);
  g.fillStyle = "#c8c0a0";
  g.beginPath();
  g.moveTo(14, 18);
  g.lineTo(242, 18);
  for (let i = 0; i < 27; i++)
    g.lineTo(190 + Math.sin(i * .56) * 24 + Math.cos(i * 1.1) * 13, 20 + i * 9.4);
  g.lineTo(14, 269);
  g.fill();
  for (const [x, y] of [[296, 71], [327, 178], [271, 198]]) {
    g.beginPath();
    g.ellipse(x, y, 15, 6, -.4, 0, Math.PI * 2);
    g.fill();
  }
  g.strokeStyle = "#a85746";
  g.lineWidth = 4;
  g.setLineDash([5, 6]);
  g.beginPath();
  g.moveTo(193, 129);
  g.bezierCurveTo(285, 114, 251, 68, 366, 43);
  g.stroke();
  g.fillStyle = "#4c5a53";
  g.font = "bold 21px Georgia";
  g.fillText("TALLVIK", 28, 49);
  const t = new CanvasTexture(c);
  t.colorSpace = SRGBColorSpace;
  return new MeshStandardMaterial({ map: t, roughness: .92 });
}

function postalInterior(h: House) {
  const p = h.inside;
  const shelf = group(p, -.56, .12, .77);
  box(shelf, walnut, 0, .81, .07, 1.79, 1.44, .18);
  for (let k = 0; k < 4; k++)
    box(shelf, pine, 0, .17 + k * .425, -.06, 1.84, .063, .35);
  for (let k = 0; k < 5; k++)
    box(shelf, pine, -.91 + k * .455, .8, -.06, .054, 1.37, .35);
  for (let k = 0; k < 12; k++) {
    const x = -.68 + (k % 4) * .455, y = .23 + Math.floor(k / 4) * .425;
    for (let n = 0; n < (k % 3) + 1; n++)
      box(shelf, k % 4 === 1 ? cream : paper, x, y + n * .043, -.11, .29, .036, .19).rotation.y = (k % 3 - 1) * .11;
  }
  placard(shelf, "MARGINS", "BOOK POST", -.21, .586, -.25, .38, .14, "#e8dbbc", "#4f5c54");
  const bench = group(p, .22, .08, -.58);
  table(bench, 0, 0, 1.92, .75, .79);
  box(bench, paint("#506b5c"), .18, .851, -.02, .92, .022, .55);
  cyl(bench, brass, -.65, .9, .02, .30, .07);
  cyl(bench, brass, -.65, 1.06, .02, .06, .31);
  const cross = box(bench, brass, -.65, 1.21, .02, .50, .043, .04);
  cross.rotation.z = .035;
  for (const x of [-.86, -.44]) {
    for (const dx of [-.08, .08])
      beam(bench, walnut, [x + .005, 1.205, .02], [x + dx, 1.0, .02], .012);
    oval(bench, brass, x, .996, .02, .216, .047, .17);
  }
  const stamp = group(bench, .35, .863, -.04);
  stamp.name = "hotspot-portstamp";
  const card = part(stamp, new PlaneGeometry(.68, .42), cardSurface(false), -.06, .008, 0);
  card.rotation.x = -Math.PI / 2;
  card.rotation.z = Math.PI - .12;
  card.userData.keep = true;
  const handle = group(stamp, .235, 0, .115);
  handle.userData.keep = true;
  box(handle, brass, 0, .038, 0, .141, .071, .12);
  cyl(handle, walnut, 0, .126, 0, .052, .14);
  oval(handle, paint("#794d40"), 0, .21, 0, .125, .115, .11);
  batch(handle);
  const imprinted = cardSurface(true);
  crate(p, 1.17, .08, .10, .50, .40);
  crate(p, 1.18, .394, .11, .45, .36);
  placard(p, "MARGINS", "BOOK POST", 1.17, .265, -.11, .38, .18, "#e9dfc3", "#49605d");
  const map = townChart();
  const chart = part(p, new PlaneGeometry(.90, .67), map, .86, 1.35, h.d / 2 - .121);
  chart.position.set(-h.w / 2 + .111, 1.25, .22);
  chart.rotation.y = Math.PI / 2;
  for (let i = 0; i < 3; i++)
    box(bench, paint(i % 2 ? "#8b6854" : "#607566"), .47 - i * .22, .257, .03, .19, .111, .32);
  const ferryDoor = group(p, .90, .078, h.d / 2 - .14);
  box(ferryDoor, walnut, 0, .735, 0, .66, 1.47, .056);
  for (let i = 0; i < 4; i++)
    box(ferryDoor, pine, -.24 + i * .16, .73, -.037, .143, 1.34, .035);
  oval(ferryDoor, brass, .23, .69, -.079, .051, .050, .051);
  const tray = group(p, -1.07, .09, -.62);
  box(tray, iron, 0, .04, 0, .52, .064, .36);
  for (const x of [-.12, .13]) {
    box(tray, walnut, x, .125, -.04, .14, .12, .23);
    cyl(tray, walnut, x, .229, .01, .133, .20);
  }
  return { showInk() { card.material = imprinted; }, handle };
}

function sled(root: Group, x: number, z: number, rotation: number, delivery = false) {
  const g = group(root, x, heightAt(x, z) + .055, z);
  g.rotation.y = rotation;
  for (const s of [-1, 1]) {
    box(g, iron, s * .22, .047, 0, .045, .054, 1.08);
    beam(g, iron, [s * .22, .055, -.52], [s * .22, .19, -.68], .042);
    box(g, walnut, s * .19, .145, 0, .068, .19, .68);
  }
  for (let i = 0; i < 5; i++)
    box(g, pine, -.20 + i * .10, .258, .025, .084, .067, .83);
  if (delivery)
    crate(g, 0, .294, 0, .39, .44);
}

export function buildBuildings(root: Group) {
  const bakery = house(root, { ...BAKERY, rotation: -.13, w: 3.48, d: 2.63, h: 2.12, rise: 1.03, color: "#c09356", roof: "#6e6659", site: "bakery" });
  // The bakery awning and booth identify the shop even at town scale.
  const canopy = group(bakery.lid, -.58, 1.76, -bakery.d / 2 - .11);
  canopy.rotation.x = .18;
  for (let i = 0; i < 11; i++) {
    const m = i % 2 ? cream : paint("#6b7b61");
    box(canopy, m, -.84 + i * .17, 0, -.22, .175, .05, .51);
    box(canopy, m, -.84 + i * .17, -.05, -.48, .175, .11, .045);
  }
  box(bakery.lid, walnut, -.57, .48, -bakery.d / 2 - .22, 1.64, .10, .29);
  for (let i = 0; i < 5; i++)
    bun(bakery.lid, -1.13 + i * .25, .537, -bakery.d / 2 - .24);
  sign(bakery, "BAGERI", "KARDEMUMMA & KANEL", "#4a6355", "#f2e0bc");
  bakeryInterior(bakery);
  finishHouse(bakery);
  const post = house(root, { ...POST, rotation: .09, w: 3.0, d: 2.37, h: 1.95, rise: 1.02, color: "#974e47", roof: "#455963", site: "post" });
  sign(post, "SJÖPOST", "TALLVIK", "#e4d6b7", "#6e453e");
  const stamp = postalInterior(post);
  finishHouse(post);
  const village = group(root);
  const houses = [
    { x: -11.6, z: -2.19, rotation: .30, w: 2.73, d: 2.53, h: 2.06, rise: 1.17, color: "#9c554a", roof: "#656767" },
    { x: -16.64, z: -1.02, rotation: 1.97, w: 2.51, d: 2.36, h: 1.83, rise: 1.14, color: "#a6a388", roof: "#4b6064" },
    { x: -14.03, z: 5.00, rotation: -.37, w: 2.76, d: 2.38, h: 2.32, rise: 1.16, color: "#6a8384", roof: "#555969" }
  ];
  for (let i = 0; i < houses.length; i++) {
    const home = house(village, houses[i]);
    if (i === 0) {
      const log = paint("#79604a");
      for (let row = 0; row < 3; row++)
        for (let col = 0; col < 5 - row; col++) {
          const l = cyl(home.outside, log, -1.13 + col * .18 + row * .08, .14 + row * .14, -1.49, .17, .37);
          l.rotation.x = Math.PI / 2;
        }
      box(home.outside, slate, -.77, .62, -1.40, 1.18, .10, .53).rotation.x = -.13;
    }
    if (i === 2) {
      const win = group(home.lid, -.24, 0, -home.d / 2 - .13);
      pane(win, 0, 2.65, 0, .44, .42);
    }
    finishHouse(home);
  }
  // Shared yard between the cottages: a wool blanket on the line and chopped kindling.
  const yard = group(village, -15.65, heightAt(-15.65, 1.9), 1.9);
  for (const x of [-1.12, 1.12])
    box(yard, walnut, x, .76, 0, .059, 1.53, .065);
  beam(yard, iron, [-1.12, 1.45, 0], [0, 1.36, .035], .018);
  beam(yard, iron, [0, 1.36, .035], [1.12, 1.45, 0], .018);
  box(yard, paint("#8f594f"), -.30, 1.04, .03, .73, .63, .026).rotation.z = .043;
  for (const y of [.85, .91, 1.22])
    box(yard, cream, -.30, y, .048, .73, .021, .012).rotation.z = .043;
  for (const x of [-.61, -.02])
    box(yard, pine, x, 1.37, .034, .032, .096, .046);
  const smallPorch = group(village, -14.3, heightAt(-14.3, 3.45) + .05, 3.45);
  for (let i = 0; i < 4; i++)
    box(smallPorch, pine, 0, .13 - i * .035, -i * .18, .87, .118, .19);
  sled(village, -16.1, -3.05, .5);
  sled(village, 12.65, -3.82, .09, true);
  for (let i = 0; i < 2; i++)
    for (let n = 0; n < 12; n++) {
      const z = -4.6 + n * .12, x = 12.57 + i * .39 + .06 * Math.sin(n * .17);
      box(village, paint("#9aa8ae"), x, heightAt(x, z) + .013, z, .028, .025, .16);
    }
  // Deliveries link the waterfront, HEARTH's pastry counter and the MARGINS bookshop.
  crate(village, 6.04, .00, -4.88, .42, .34);
  for (let i = 0; i < 3; i++)
    bun(village, 5.93 + i * .11, .302, -4.88);
  sled(village, -7.69, -4.94, .32, true);
  for (let i = 0; i < 14; i++) {
    const x = -17 + i * .55, z = 3.50 + .20 * Math.sin(i * .35), y = heightAt(x, z);
    if (i === 5 || i === 6)
      continue;
    box(village, walnut, x, y + .38, z, .105, .78, .105);
    if (i === 4 || i === 13)
      continue;
    for (const h of [.25, .55])
      beam(village, pine, [x, y + h, z], [x + .55, heightAt(x + .55, z) + h, z + .045 * Math.cos(i * .35)], .066);
  }
  for (const [x, z] of [[-13.1, 1.3], [-10.4, 8.5], [8.7, -5.4], [12.4, -6.4], [11.3, .45]]) {
    const y = heightAt(x, z);
    cyl(village, iron, x, y + .80, z, .078, 1.6);
    cyl(village, iron, x, y + .12, z, .17, .23);
    cyl(village, windowLight, x, y + 1.70, z, .195, .27);
    oval(village, iron, x, y + 1.89, z, .31, .12, .31);
  }
  const bench = group(village, -9.25, heightAt(-9.25, 8.9) + .05, 8.9);
  for (const x of [-.46, .46])
    box(bench, iron, x, .22, 0, .08, .44, .32);
  for (const z of [-.14, 0, .14])
    box(bench, pine, 0, .46, z, 1.35, .06, .12);
  batch(village);
  let time = 0;
  return {
    open(place: string) {
      for (const [name, model] of [["bakery", bakery], ["post", post]] as const) {
        model.lid.visible = place !== name;
        model.inside.visible = place === name;
      }
    },
    stamp(reduced: boolean) { stamp.showInk(); time = reduced ? 0 : .40; stamp.handle.position.y = 0; },
    tick(dt: number, still: boolean) {
      if (!time)
        return;
      time = still ? 0 : Math.max(0, time - dt);
      stamp.handle.position.y = Math.sin(Math.PI * time / .40) * .12;
    },
    lighting(amount: number) { windowLight.emissiveIntensity = .08 + amount * .95; glazed.emissiveIntensity = .04 + amount * .62; ovenLight.emissiveIntensity = .48 + amount * 1.5; }
  };
}
