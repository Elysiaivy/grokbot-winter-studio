import { BufferGeometry, InstancedMesh, Mesh, MeshStandardMaterial, Object3D } from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";

/**
 * Bake static meshes that share a material into one draw.
 * Skips robots, hotspots, transparent surfaces, and anything marked userData.keep.
 * A group named roof-slab or window-dress is left for its own pass.
 */
export function mergeStatic(root: Object3D): number {
  root.updateWorldMatrix(true, true);
  const inv = root.matrixWorld.clone().invert();
  const buckets = new Map<string, { mat: MeshStandardMaterial; geos: BufferGeometry[]; cast: boolean; receive: boolean }>();
  const doomed: Mesh[] = [];

  root.traverse((obj) => {
    if (obj === root) return;
    if (!(obj instanceof Mesh) || (obj as InstancedMesh).isInstancedMesh) return;
    if (held(obj, root)) return;
    const mat = obj.material;
    if (Array.isArray(mat) || !(mat instanceof MeshStandardMaterial) || mat.transparent) return;
    const source = obj.geometry;
    if (!source.getAttribute("position") || !source.getAttribute("normal") || !source.getAttribute("uv")) return;
    const geo = source.clone();
    geo.applyMatrix4(inv.clone().multiply(obj.matrixWorld));
    const cast = obj.castShadow;
    const receive = obj.receiveShadow;
    const attrs = Object.keys(source.attributes).sort().join(",");
    const key = `${mat.uuid}|${cast ? 1 : 0}|${receive ? 1 : 0}|${source.index ? 1 : 0}|${attrs}`;
    let bucket = buckets.get(key);
    if (!bucket) {
      bucket = { mat, geos: [], cast, receive };
      buckets.set(key, bucket);
    }
    bucket.geos.push(geo);
    doomed.push(obj);
  });

  for (const mesh of doomed) mesh.removeFromParent();

  let draws = 0;
  for (const bucket of buckets.values()) {
    const merged = bucket.geos.length === 1 ? bucket.geos[0] : mergeGeometries(bucket.geos, false);
    if (!merged) {
      for (const geo of bucket.geos) {
        const mesh = new Mesh(geo, bucket.mat);
        mesh.castShadow = bucket.cast;
        mesh.receiveShadow = bucket.receive;
        root.add(mesh);
        draws += 1;
      }
      continue;
    }
    const mesh = new Mesh(merged, bucket.mat);
    mesh.castShadow = bucket.cast;
    mesh.receiveShadow = bucket.receive;
    root.add(mesh);
    draws += 1;
    for (const geo of bucket.geos) {
      if (geo !== merged) geo.dispose();
    }
  }
  return draws;
}

function held(obj: Object3D, root: Object3D): boolean {
  let current: Object3D | null = obj;
  while (current && current !== root) {
    if (current.userData.keep || current.userData.role) return true;
    const name = current.name || "";
    if (name.startsWith("hotspot") || name === "steam") return true;
    if ((name === "roof-slab" || name === "window-dress") && root.name !== name) return true;
    current = current.parent;
  }
  return false;
}
