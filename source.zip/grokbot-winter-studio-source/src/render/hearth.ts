import {
  AdditiveBlending,
  BufferGeometry,
  CanvasTexture,
  CircleGeometry,
  Color,
  CylinderGeometry,
  DodecahedronGeometry,
  Float32BufferAttribute,
  Group,
  Mesh,
  MeshBasicMaterial,
  MeshStandardMaterial,
  PlaneGeometry,
  PointLight,
  SRGBColorSpace,
} from "three";

export function buildHearthFire(x: number, fireboxFloor: number) {
  const root = new Group();
  root.name = "hearth-fire";
  root.position.set(x, 0, 3.78);
  const firebox = new Group();
  firebox.position.y = fireboxFloor - 0.126;
  root.add(firebox);

  const coal = new MeshStandardMaterial({ color: "#3f2625", roughness: 0.91 });
  const ember = new MeshStandardMaterial({ color: "#6d382c", roughness: 0.81, emissive: "#ff4d18" });
  const pebble = new DodecahedronGeometry(1);
  for (let i = 0; i < 17; i += 1) {
    const offset = (i - 8) / 8;
    const depth = -0.02 + Math.sin(i * 5.1) * 0.095;
    const size = 0.034 + Math.abs(Math.sin(i * 3.7)) * 0.031;
    const cinder = new Mesh(pebble, i % 3 === 1 ? ember : coal);
    cinder.scale.set(size * 1.42, size * 0.58, size);
    cinder.rotation.set(i * 0.3, i * 1.7, i * 1.6);
    cinder.position.set(offset * 0.43, 0.132 + size * 0.3, depth);
    firebox.add(cinder);
  }

  const bark = new MeshStandardMaterial({ color: "#3a231d", roughness: 0.93, flatShading: true });
  const splitWood = new MeshStandardMaterial({ map: makeEndGrain(), color: "#c9a285", roughness: 0.86 });
  const logSpecs = [
    { length: 0.58, radius: 0.070, x: -0.115, y: 0.197, z: -0.066, yaw: 1.20, tilt: -0.03 },
    { length: 0.51, radius: 0.061, x: 0.10, y: 0.192, z: 0.020, yaw: 1.94, tilt: 0.08 },
    { length: 0.47, radius: 0.053, x: -0.035, y: 0.259, z: 0.011, yaw: 1.08, tilt: -0.09 },
  ];
  for (const { length, radius, x: dx, y, z, yaw, tilt } of logSpecs) {
    const log = new Group();
    log.position.set(dx, y, z);
    log.rotation.set(tilt, yaw, 0);
    const rind = new Mesh(new CylinderGeometry(radius * 0.91, radius, length, 8), bark);
    rind.rotation.x = Math.PI / 2;
    log.add(rind);
    for (const end of [-1, 1]) {
      const cap = new Mesh(new CircleGeometry(radius * (end > 0 ? 0.85 : 0.93), 8), splitWood);
      cap.position.z = end * (length / 2 + 0.001);
      cap.rotation.y = end < 0 ? Math.PI : 0;
      log.add(cap);
    }
    firebox.add(log);
  }

  const flameMaterial = new MeshBasicMaterial({ vertexColors: true });
  const flames = [
    { x: -0.19, z: 0.065, width: 0.084, height: 0.32, lean: -0.092, turn: 0.55 },
    { x: -0.055, z: 0.146, width: 0.115, height: 0.46, lean: 0.106, turn: -0.22 },
    { x: 0.12, z: 0.082, width: 0.089, height: 0.34, lean: -0.061, turn: 0.27 },
  ].map(({ x: dx, z, width, height, lean, turn }) => {
    const mesh = new Mesh(flameGeometry(width, height, lean), flameMaterial);
    mesh.position.set(dx, 0.212, z);
    mesh.rotation.y = turn;
    firebox.add(mesh);
    return mesh;
  });

  const light = new PointLight("#ff9957", 0, 3.6, 2);
  light.position.set(0.16, fireboxFloor + 0.5, 0.03);
  root.add(light);

  const rugSpill = new MeshBasicMaterial({
    map: makeSpillMap(),
    color: "#ff8650",
    blending: AdditiveBlending,
    transparent: true,
    depthWrite: false,
  });
  const spill = new Mesh(new PlaneGeometry(2.7, 1.7), rugSpill);
  spill.rotation.x = -Math.PI / 2;
  spill.position.set(0.24, 0.047, -0.62);
  spill.userData.selectionIgnore = true;
  root.add(spill);

  return {
    root,
    update(time: number, still: boolean, amount: number) {
      const flicker = still ? 0 : Math.sin(time * 3.7) * 0.055 + Math.sin(time * 7.1) * 0.025;
      const heat = amount * (1 + flicker);
      light.intensity = heat * 2.1;
      rugSpill.opacity = heat * 0.12;
      ember.emissiveIntensity = 0.24 + heat * 0.96;
      flameMaterial.color.setScalar(0.65 + heat * 0.48);
      flames.forEach((flame, index) => {
        const wave = still ? 0 : Math.sin(time * (3.7 + index * 0.8) + index * 2);
        flame.scale.y = 0.72 + amount * 0.28 + wave * 0.085;
        flame.rotation.z = wave * 0.09;
      });
    },
  };
}

function flameGeometry(width: number, height: number, lean: number): BufferGeometry {
  const sections = [
    { y: 0, width: 0.32, bend: 0, color: new Color("#ff8f36").multiplyScalar(1.5) },
    { y: 0.18, width: 1, bend: -0.11, color: new Color("#ffcb67").multiplyScalar(1.42) },
    { y: 0.44, width: 0.74, bend: -0.16, color: new Color("#ffa83e").multiplyScalar(1.16) },
    { y: 0.72, width: 0.39, bend: 0.50, color: new Color("#ed6727") },
    { y: 1, width: 0.008, bend: 1, color: new Color("#d85120") },
  ];
  const sides = 10;
  const positions: number[] = [];
  const colors: number[] = [];
  const indices: number[] = [];
  sections.forEach((section, level) => {
    for (let side = 0; side < sides; side += 1) {
      const angle = side * Math.PI * 2 / sides;
      const radius = width * section.width;
      positions.push(lean * section.bend + Math.cos(angle) * radius, section.y * height, Math.sin(angle) * radius * 0.57);
      colors.push(section.color.r, section.color.g, section.color.b);
      if (level === 0) continue;
      const upper = level * sides + side;
      const nextUpper = level * sides + (side + 1) % sides;
      indices.push(upper - sides, upper, nextUpper, upper - sides, nextUpper, nextUpper - sides);
    }
  });
  const geometry = new BufferGeometry();
  geometry.setAttribute("position", new Float32BufferAttribute(positions, 3));
  geometry.setAttribute("color", new Float32BufferAttribute(colors, 3));
  geometry.setIndex(indices);
  return geometry;
}

function makeEndGrain(): CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 64;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not draw the firewood end grain.");
  ctx.fillStyle = "#b2764a";
  ctx.fillRect(0, 0, 64, 64);
  for (const radius of [6, 12, 18, 24, 30]) {
    ctx.beginPath();
    ctx.ellipse(31, 32, radius, radius * 0.9, -0.35, 0, Math.PI * 2);
    ctx.lineWidth = radius === 30 ? 3 : 1.6;
    ctx.strokeStyle = radius === 30 ? "#4d3027" : "#734a35";
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(5, 20);
  ctx.lineTo(16, 26);
  ctx.lineTo(25, 26);
  ctx.moveTo(51, 55);
  ctx.lineTo(44, 43);
  ctx.lineTo(44, 38);
  ctx.stroke();
  const texture = new CanvasTexture(canvas);
  texture.colorSpace = SRGBColorSpace;
  return texture;
}

function makeSpillMap(): CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 64;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not draw the hearth light on the carpet.");
  const lamp = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  lamp.addColorStop(0, "rgba(255,255,255,0.95)");
  lamp.addColorStop(0.48, "rgba(255,255,255,0.48)");
  lamp.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = lamp;
  ctx.fillRect(0, 0, 64, 64);
  return new CanvasTexture(canvas);
}
