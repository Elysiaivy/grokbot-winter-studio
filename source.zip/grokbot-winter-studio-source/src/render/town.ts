import { Group, Mesh, MeshStandardMaterial, PlaneGeometry, PointLight, Object3D, type Quaternion, Vector3 } from "three";
import { buildBuildings, BAKERY, POST } from "./townBuildings";
import { buildHarbor, PIER } from "./townHarbor";
import { buildLand, heightAt, LAND } from "./townLand";
import { snowFlakes } from "./snowCover";
import { group, paint, randomStream, rock } from "./townCraft";

export const TOWN_VIEWS = {
  town: { name: "松湾冬港", note: "沿街点选面包房、邮务所或栈桥港灯。" },
  bakery: { name: "街角面包房", note: "砖炉边是当天的肉桂卷，门外的雪橇正等着送货。" },
  post: { name: "渡口邮务所", note: "点柜台上的邮戳，在明信片上留下松湾港印。" },
  quay: { name: "栈桥尽头", note: "越过邮船与木屋，回望工作室阅览室的暖窗。" },
  lookout: { name: "白桦山径", note: "从林间长椅望向街区、船桅与海湾。" },
  seaward: { name: "阅览室窗边", note: "顺着窗外的码头，找到水边的琥珀色港灯。" }
} as const;

export type TownView = keyof typeof TOWN_VIEWS;
export const isTownView = (value: string): value is TownView => Object.hasOwn(TOWN_VIEWS, value);

export function buildTown() {
  const root = new Group();
  root.name = "pine-harbor";
  buildLand(root);
  const harborLight = buildHarbor(root);
  const buildings = buildBuildings(root);
  buildings.open("");
  const ovenLamp = new PointLight("#ffb165", 0, 5.0, 2);
  ovenLamp.position.set(BAKERY.x - .82, heightAt(BAKERY.x, BAKERY.z) + .94, BAKERY.z - .04);
  const postLamp = new PointLight("#f3cb96", 0, 4.3, 2);
  postLamp.position.set(POST.x + .20, heightAt(POST.x, POST.z) + 1.86, POST.z - .1);
  root.add(ovenLamp, postLamp);
  const horizon = group(root);
  const water = new Mesh(new PlaneGeometry(80, 95), new MeshStandardMaterial({ color: "#365966", roughness: .58, metalness: .16 }));
  water.rotation.x = -Math.PI / 2;
  water.position.set(LAND.right + 40, -.925, 0);
  horizon.add(water);
  const distant = randomStream(803);
  for (let i = 0; i < 28; i++) {
    const z = -25 + i * 1.95 + Math.sin(i);
    if (z > -2 && z < 4)
      continue;
    const w = 2.5 + distant() * 5;
    rock(horizon, paint("#657e87"), 46 + distant() * 8, -.83, z, w, 1.2 + distant() * 1.5, w * .80);
  }
  horizon.visible = false;
  // Extra snow belongs to the outer town and never falls through the two open shops.
  const count = 180, positions = new Float32Array(count * 3), speed = new Float32Array(count);
  const rand = randomStream(198);
  function seed(i: number, born: boolean) {
    let x: number, z: number;
    do {
      x = LAND.left + rand() * (LAND.right - LAND.left);
      z = LAND.front + rand() * (LAND.back - LAND.front);
    } while ((Math.abs(x) < 8.5 && z < 6.7 && z > -10.4) ||
      (Math.abs(x - BAKERY.x) < 2.1 && Math.abs(z - BAKERY.z) < 1.8) ||
      (Math.abs(x - POST.x) < 1.85 && Math.abs(z - POST.z) < 1.55));
    positions[3 * i] = x;
    positions[3 * i + 1] = heightAt(x, z) + (born ? rand() * 5 : 4.6 + rand());
    positions[3 * i + 2] = z;
    speed[i] = .19 + rand() * .28;
  }
  for (let i = 0; i < count; i++)
    seed(i, true);
  const snow=snowFlakes(count), flake=new Object3D();
  const sizes=Float32Array.from({length:count},()=>.28+rand()**1.6*.77);
  root.add(snow);
  const point = (x: number, y: number, z: number) => new Vector3(x, y, z);
  function roomShot(site: typeof BAKERY, w: number) {
    const t = point(site.x, heightAt(site.x, site.z) + .88, site.z);
    return { p: t.clone().add(point(3.35, 4.65, -6.75)), t, z: w };
  }
  const shots = {
    town: { p: point(13.0, 25.6, -35.0), t: point(1.05, .28, .04), z: .48 },
    bakery: roomShot(BAKERY, 4.28), post: roomShot(POST, 4.65),
    quay: { p: point(18.70, 2.18, 4.62), t: point(2.35, 2.65, 2.7), z: 1 },
    lookout: { p: point(-9.8, 5.0, 9.2), t: point(5.5, 1.39, 2.35), z: 1 },
    seaward: { p: point(4.18, 3.96, 3.12), t: point(PIER.x, 1.50, PIER.z), z: 1 }
  };
  return {
    root, shots, stamp: buildings.stamp,
    open(place: string) { buildings.open(place); horizon.visible = place === "seaward"; },
    tick(dt: number, still: boolean) { buildings.tick(dt, still); },
    lighting(amount: number) { buildings.lighting(amount); harborLight(amount); ovenLamp.intensity = .86 + amount * 2.53; postLamp.intensity = .4 + amount * 2.35; },
    snow(dt: number, visible: boolean, facing: Quaternion) {
      snow.visible = visible;
      if (!visible)
        return;
      for (let i = 0; i < count; i++) {
        positions[i * 3 + 1] -= speed[i] * dt;
        if (positions[i * 3 + 1] < heightAt(positions[i * 3], positions[i * 3 + 2]))
          seed(i, false);
      }
      flake.quaternion.copy(facing);
      for(let i=0;i<count;i++){
        flake.position.fromArray(positions,i*3);flake.scale.setScalar(sizes[i]);
        flake.updateMatrix();snow.setMatrixAt(i,flake.matrix);
      }
      snow.instanceMatrix.needsUpdate=true;
    }
  };
}
