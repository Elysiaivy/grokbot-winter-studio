import {
  CanvasTexture,
  ClampToEdgeWrapping,
  Color,
  DoubleSide,
  Matrix3,
  Mesh,
  MeshStandardMaterial,
  NoColorSpace,
  RepeatWrapping,
  SRGBColorSpace,
  Vector3,
  type Texture,
} from "three";

export const textures: Texture[] = [];
let textureAnisotropy = 4;

function canvas(size = 256): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const el = document.createElement("canvas");
  el.width = size;
  el.height = size;
  const ctx = el.getContext("2d");
  if (!ctx) throw new Error("Could not draw the texture");
  return [el, ctx];
}

function texOf(el: HTMLCanvasElement, repeat = false): CanvasTexture {
  const tex = new CanvasTexture(el);
  tex.colorSpace = SRGBColorSpace;
  tex.wrapS = repeat ? RepeatWrapping : ClampToEdgeWrapping;
  tex.wrapT = repeat ? RepeatWrapping : ClampToEdgeWrapping;
  tex.anisotropy = textureAnisotropy;
  tex.needsUpdate = true;
  textures.push(tex);
  return tex;
}

export function tuneTextures(anisotropy: number): void {
  textureAnisotropy = anisotropy;
  for (const tex of textures) tex.anisotropy = anisotropy;
}

function noise(x: number, y: number): number {
  const n = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
  return n - Math.floor(n);
}

const reliefMaps = new WeakMap<CanvasTexture, { map: CanvasTexture; depth: number }>();
const masonryMaps = new WeakSet<CanvasTexture>();

// A small periodic noise table gives paint, stone and grain variation that joins at the tile edges.
function surfaceNoise(u: number, v: number): number {
  const ix = Math.floor(u);
  const iy = Math.floor(v);
  const tx = u - ix, ty = v - iy;
  const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
  const at = (x: number, y: number) => noiseTable[((y & 63) << 6) + (x & 63)];
  const top = at(ix, iy) * (1 - sx) + at(ix + 1, iy) * sx;
  const bottom = at(ix, iy + 1) * (1 - sx) + at(ix + 1, iy + 1) * sx;
  return top * (1 - sy) + bottom * sy;
}

const noiseTable = Float32Array.from({ length: 64 * 64 }, (_, i) => noise(i % 64, Math.floor(i / 64)));
type SurfaceSample = (x: number, y: number) => [red: number, green: number, blue: number, height: number];

function paintSurface(size: number, depth: number, sample: SurfaceSample): CanvasTexture {
  const [colorCanvas, colorContext] = canvas(size);
  const [reliefCanvas, reliefContext] = canvas(size);
  const color = colorContext.createImageData(size, size);
  const relief = reliefContext.createImageData(size, size);
  let offset = 0;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const [r, g, b, height] = sample(x, y);
      color.data[offset] = r;
      color.data[offset + 1] = g;
      color.data[offset + 2] = b;
      relief.data[offset] = relief.data[offset + 1] = relief.data[offset + 2] = height;
      color.data[offset + 3] = relief.data[offset + 3] = 255;
      offset += 4;
    }
  }
  colorContext.putImageData(color, 0, 0);
  reliefContext.putImageData(relief, 0, 0);
  const map = texOf(colorCanvas, true);
  const bump = texOf(reliefCanvas, true);
  bump.colorSpace = NoColorSpace;
  reliefMaps.set(map, { map: bump, depth });
  return map;
}

const tau = Math.PI * 2;

export function makeWoodTexture(planks = false): CanvasTexture {
  const size = 512;
  const rows = planks ? 24 : 1;
  const boards = Array.from({ length: rows * 3 }, (_, i) => ({
    tone: noise(i, 12) - 0.5, bend: noise(i, 17), knot: noise(i, 23), phase: noise(i, 8),
  }));
  const joints = Array.from({ length: rows }, (_, i) => [
    (i * 0.4142) % 1, 0.30 + noise(i, 5) * 0.07, 0.64 + noise(i, 6) * 0.07,
  ]);
  return paintSurface(size, planks ? 0.014 : 0.0025, (x, y) => {
    const v = (y + 0.5) / size * rows;
    const row = Math.floor(v);
    const across = v - row;
    const [offset, first, second] = joints[row];
    const u = ((x + 0.5) / size + (planks ? offset : 0)) % 1;
    const col = !planks || u < first ? 0 : u < second ? 1 : 2;
    const start = col === 0 ? 0 : col === 1 ? first : second;
    const end = !planks || col === 2 ? 1 : col === 1 ? second : first;
    const along = (u - start) / (end - start);
    const board = boards[row * 3 + col];

    // Rings sweep towards a knot and straighten farther out along the board.
    const axis = tau * (along + board.phase);
    const grain = across * (planks ? 5 : 13) + board.bend * 4
      + 0.58 * Math.sin(axis) + 0.16 * Math.cos(axis * 2 + across * tau);
    const ring = Math.pow(0.5 + 0.5 * Math.cos(grain * tau), 5);
    const pores = surfaceNoise(along * 64, grain * 8 + board.phase * 28) - 0.5;
    const knotX = (along - 0.48) / 0.075;
    const knotY = (across - 0.44) / 0.24;
    const knot = board.knot > 0.86 ? Math.exp(-knotX * knotX - knotY * knotY) : 0;
    const tone = board.tone * 24 + Math.sin(grain * 2.0) * 4 - ring * 11 + pores * 8 - knot * 23;
    const edge = planks
      ? Math.min(Math.min(across, 1 - across) * size / rows, Math.min(u - start, end - u) * size)
      : 3;
    const joint = Math.max(0, 1 - edge / 1.22);
    return [158 + tone - joint * 42, 117 + tone * 0.84 - joint * 33,
      80 + tone * 0.65 - joint * 24, 185 - joint * 125 - ring * 7 + pores * 14];
  });
}

export function makeBrickTexture(): CanvasTexture {
  const map = paintSurface(512, 0.012, (x, y) => {
    const rowHeight = 512 / 14;
    const row = Math.floor(y / rowHeight);
    const shift = (row % 2) * 32;
    const col = Math.floor((x + shift) / 64) % 8;
    const dx = (x + shift) % 64, dy = y - row * rowHeight;
    const brick = noise(col + 2, row + 5);
    const clay = surfaceNoise(x / 8, y / 8) - 0.5;
    const sand = noiseTable[(x & 63) + ((y & 63) << 6)] - 0.5;
    const edge = Math.min(dx, 64 - dx, dy, rowHeight - dy) + clay * 1.28;
    const face = Math.min(1, Math.max(0, (edge - 0.35) / 2.2));
    const mortar = 9 * sand + 6 * clay;
    const heat = 23 * (brick - 0.5) + clay * 11 + sand * 5;
    return [(162 + mortar) * (1 - face) + (155 + heat) * face,
      (148 + mortar) * (1 - face) + (88 + heat * 0.8 + 6 * Math.cos(brick * tau)) * face,
      (131 + mortar) * (1 - face) + (70 + heat * 0.58) * face,
      76 + face * (119 + clay * 19) + sand * 7];
  });
  masonryMaps.add(map);
  return map;
}

/** Project full-size running bond continuously across piers, corners and the fireplace. */
export function alignMasonry(mesh: Mesh): void {
  const material = mesh.material as MeshStandardMaterial;
  const repeat = material.map!.repeat;
  const geometry = mesh.geometry.clone();
  mesh.updateMatrix();
  const position = new Vector3(), normal = new Vector3();
  const normalMatrix = new Matrix3().getNormalMatrix(mesh.matrix);
  const vertices = geometry.attributes.position, normals = geometry.attributes.normal;
  const uv = geometry.attributes.uv;
  for (let i = 0; i < vertices.count; i++) {
    position.fromBufferAttribute(vertices, i).applyMatrix4(mesh.matrix);
    normal.fromBufferAttribute(normals, i).applyNormalMatrix(normalMatrix);
    const top = Math.abs(normal.y) > 0.65;
    const horizontal = top || Math.abs(normal.z) > Math.abs(normal.x) ? position.x : position.z;
    uv.setXY(i, horizontal / (2.24 * repeat.x), (top ? position.z : position.y) / (1.05 * repeat.y));
  }
  mesh.geometry = geometry;
}

export function makePlasterTexture(): CanvasTexture {
  return paintSurface(256, 0.0017, (x, y) => {
    const lime = surfaceNoise(x / 4, y / 4) - 0.5;
    const grain = noiseTable[(x & 63) + ((y & 63) << 6)] - 0.5;
    const tone = lime * 8 + grain * 5;
    return [203 + tone, 191 + tone, 173 + tone, 147 + lime * 24 + grain * 14];
  });
}

export function makeRugTexture(main: string, motif: string): CanvasTexture {
  const [el, g] = canvas(256);
  g.fillStyle = main;
  g.fillRect(0, 0, 256, 256);
  g.strokeStyle = motif;
  g.globalAlpha = 0.58;
  for (const [inset, thickness] of [[9, 2], [13, 1], [24, 2], [28, 1]]) {
    g.lineWidth = thickness;
    g.strokeRect(inset, inset, 256 - inset * 2, 256 - inset * 2);
  }
  function diamond(x: number, y: number, w: number, h: number): void {
    g.beginPath();
    g.moveTo(x - w, y);
    g.lineTo(x, y - h);
    g.lineTo(x + w, y);
    g.lineTo(x, y + h);
    g.closePath();
    g.stroke();
  }
  g.lineWidth = 1.3;
  for (let p = 36; p < 225; p += 12) {
    diamond(p, 18.5, 4, 2.4); diamond(p, 237.5, 4, 2.4);
    diamond(18.5, p, 2.4, 4); diamond(237.5, p, 2.4, 4);
  }
  g.globalAlpha = 0.32;
  for (const cx of [72, 128, 184]) {
    diamond(cx, 128, 26, 36);
    diamond(cx, 128, 20, 29);
    diamond(cx, 128, 6, 10);
  }
  g.globalAlpha = 1;
  for (let y = 0; y < 256; y += 2) {
    g.fillStyle = y % 4 ? "rgba(24,12,9,.07)" : "rgba(254,229,196,.05)";
    g.fillRect(0, y, 256, 1);
  }
  return texOf(el, true);
}

export function makeWindowGlass(): MeshStandardMaterial {
  const [el, g] = canvas(128);
  const tint = g.createLinearGradient(12, 0, 82, 128);
  tint.addColorStop(0, "#818181");
  tint.addColorStop(0.30, "#414141");
  tint.addColorStop(0.57, "#373737");
  tint.addColorStop(0.72, "#4d4d4d");
  tint.addColorStop(1, "#777777");
  g.fillStyle = tint;
  g.fillRect(0, 0, 128, 128);
  const alpha = texOf(el);
  alpha.colorSpace = NoColorSpace;
  return new MeshStandardMaterial({
    alphaMap: alpha, transparent: true, depthWrite: false, side: DoubleSide, forceSinglePass: true,
    opacity: 0.34, color: "#c2dce2", emissive: "#638da0", emissiveIntensity: 0.10,
    roughness: 0.15, metalness: 0.08, envMapIntensity: 0.80,
  });
}

export function makeSignTexture(title: string, subtitle: string, paper: string, ink: string): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 512;
  el.height = 192;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the sign");
  g.fillStyle = paper;
  g.fillRect(0, 0, 512, 192);
  g.globalAlpha = 0.78;
  g.strokeStyle = ink;
  g.lineWidth = 3;
  g.strokeRect(12, 12, 488, 168);
  g.globalAlpha = 0.36;
  g.lineWidth = 1;
  g.strokeRect(21, 21, 470, 150);
  g.globalAlpha = 1;
  g.fillStyle = ink;
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.font = "bold 73px Georgia, 'Times New Roman', serif";
  g.fillText(title.toUpperCase(), 256, 79, 434);
  g.font = "600 29px system-ui, sans-serif";
  g.fillText(subtitle.toUpperCase(), 256, 136, 312);
  for (const x of [90, 422]) {
    g.beginPath();
    g.moveTo(x, 130);
    g.lineTo(x + 5, 135);
    g.lineTo(x, 140);
    g.lineTo(x - 5, 135);
    g.fill();
  }
  return texOf(el);
}

export function makeLabelTexture(text: string, ink = "#2a241e", paper = "#f7f1e4"): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 256;
  el.height = 80;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the nameplate");
  g.fillStyle = paper;
  g.fillRect(0, 0, 256, 80);
  g.strokeStyle = "#7a3140";
  g.lineWidth = 4;
  g.strokeRect(4, 4, 248, 72);
  g.fillStyle = ink;
  g.font = "600 28px system-ui, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(text.toUpperCase(), 128, 41, 225);
  return texOf(el);
}

export function makeChartTexture(kind: "line" | "bars", title: string, accent: string, background: string): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 256;
  el.height = 160;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the monitor texture");
  g.fillStyle = background;
  g.fillRect(0, 0, 256, 160);
  g.fillStyle = accent;
  g.font = "bold 15px system-ui, sans-serif";
  g.fillText(title, 16, 24);
  g.fillRect(219, 15, 18, 7);
  g.strokeStyle = accent;
  g.globalAlpha = 0.35;
  g.lineWidth = 1;
  for (let i = 1; i < 4; i += 1) {
    g.beginPath();
    g.moveTo(16, 20 + i * 30);
    g.lineTo(240, 20 + i * 30);
    g.stroke();
  }
  g.globalAlpha = 1;
  if (kind === "line") {
    g.strokeStyle = accent;
    g.lineWidth = 4;
    g.beginPath();
    const ys = [132, 109, 115, 79, 89, 69, 72, 44, 51];
    ys.forEach((y, i) => {
      const x = 20 + i * 28;
      if (i === 0) g.moveTo(x, y);
      else g.lineTo(x, y);
    });
    g.stroke();
  } else {
    const heights = [40, 70, 48, 90, 62, 84];
    heights.forEach((h, i) => {
      g.fillStyle = i % 2 ? "#e5ac7a" : accent;
      g.fillRect(24 + i * 36, 130 - h, 22, h);
    });
  }
  return texOf(el);
}

export function makeNoteTexture(): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 512;
  el.height = 384;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the noticeboard");
  g.fillStyle = "#efe2cc";
  g.fillRect(0, 0, 512, 384);
  const notes = [
    { x: 24, y: 24, w: 200, h: 140, c: "#f7f1e4", t: "Keep hall clear" },
    { x: 250, y: 36, w: 220, h: 120, c: "#f3e4e2", t: "Tea in kitchen" },
    { x: 40, y: 190, w: 180, h: 150, c: "#e7efe8", t: "Lights on steady" },
    { x: 250, y: 186, w: 220, h: 160, c: "#f8f4ea", t: "Winter rota" },
  ];
  for (const note of notes) {
    g.fillStyle = note.c;
    g.fillRect(note.x, note.y, note.w, note.h);
    g.strokeStyle = "rgba(80,60,40,0.25)";
    g.strokeRect(note.x, note.y, note.w, note.h);
    g.fillStyle = "#3a3128";
    g.font = "22px Georgia, serif";
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillText(note.t, note.x + note.w / 2, note.y + note.h / 2, note.w - 20);
  }
  return texOf(el);
}

export function makeRadial(): CanvasTexture {
  const [el, g] = canvas(128);
  const grd = g.createRadialGradient(64, 64, 8, 64, 64, 64);
  grd.addColorStop(0, "rgba(0,0,0,0.45)");
  grd.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  return texOf(el);
}

const matteCache = new Map<string, MeshStandardMaterial>();

export function fork(material: MeshStandardMaterial): MeshStandardMaterial {
  return material.clone();
}

export function makeSlateTexture(): CanvasTexture {
  return paintSurface(512, 0.010, (x, y) => {
    const row = Math.floor(y / 32);
    const shifted = x + (row % 2) * 32;
    const col = Math.floor(shifted / 64) % 8;
    const dx = shifted % 64, dy = y % 32;
    const slate = noise(col + 3, row + 1);
    const flake = surfaceNoise(x * 0.125, y * 0.5) - 0.5;
    const edge = Math.min(dx, 64 - dx, dy, 32 - dy) + 0.8 * flake;
    const joint = Math.max(0, 1 - edge / 1.55);
    const lip = Math.max(0, 1 - Math.abs(dy + flake - 29.5) / 1.45);
    const value = 81 + 15 * (slate - 0.5) + 13 * flake - 22 * joint + 7 * lip;
    return [value - 3, value + 1, value + 5 + 4 * slate, 137 + dy * 1.4 - joint * 60 + flake * 19];
  });
}

export function makeKeyboardMaterial(worn = false): MeshStandardMaterial {
  const el = document.createElement("canvas");
  const resolution = worn ? 2 : 1;
  el.width = 256 * resolution;
  el.height = 128 * resolution;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the keyboard");
  g.scale(resolution, resolution);
  g.fillStyle = "#1a1e24";
  g.fillRect(0, 0, 256, 128);
  const [roughnessCanvas, roughness] = worn ? canvas(256) : [];
  if (roughness) {
    roughness.scale(1, 2);
    roughness.fillStyle = "#bababa";
    roughness.fillRect(0, 0, 256, 128);
  }
  for (let row = 0; row < 4; row += 1) {
    for (let col = 0; col < 13; col += 1) {
      const space = row === 3 && col >= 4 && col <= 8;
      if (space && col > 4) continue;
      const w = space ? 86 : 14;
      const x = 8 + col * 18 + (!worn && row === 3 && col > 8 ? 68 : 0);
      const y = 10 + row * 28;
      const accent = row === 1 && col === 12;
      if (roughness) {
        const polished = row === 2 && (col === 4 || col === 7);
        g.fillStyle = accent ? "#9b6555" : polished ? "#cfdbd2" : "#a4b6af";
        g.beginPath();
        g.roundRect(x, y, w, 18, 2.3);
        g.fill();
        g.fillStyle = "rgba(17, 34, 33, 0.30)";
        g.fillRect(x + 2, y + 15, w - 4, 2);
        if (polished) {
          const shine = g.createLinearGradient(x, y, x + w, y + 10);
          shine.addColorStop(0, "rgba(235, 249, 236, 0.1)");
          shine.addColorStop(0.6, "rgba(235, 249, 236, 0.7)");
          shine.addColorStop(1, "rgba(235, 249, 236, 0.05)");
          g.fillStyle = shine;
          g.fillRect(x + 2, y + 1, w - 4, 10);
          g.fillStyle = "#50645d";
          g.font = "bold 8px system-ui, sans-serif";
          g.fillText(col === 4 ? "F" : "J", x + 4, y + 10);
          roughness.fillStyle = "#4f4f4f";
          roughness.fillRect(x + 1, y + 1, w - 2, 15);
        }
        continue;
      }
      g.fillStyle = accent ? "#8d3a32" : `rgb(${186 + (col % 3) * 8}, ${190 + (row % 2) * 6}, ${196})`;
      g.fillRect(x, y, w, 18);
      g.fillStyle = "rgba(20, 16, 14, 0.35)";
      g.fillRect(x, y + 16, w, 2);
    }
  }
  const material = new MeshStandardMaterial({ map: texOf(el), roughness: worn ? 0.96 : 0.62, metalness: 0.04 });
  if (roughnessCanvas) {
    material.roughnessMap = texOf(roughnessCanvas);
    material.roughnessMap.colorSpace = NoColorSpace;
  }
  return material;
}

export function makeKnitBump(): CanvasTexture {
  const [el, g] = canvas(128);
  g.fillStyle = "#333";
  g.fillRect(0, 0, 128, 128);
  g.strokeStyle = "#aaa";
  g.lineWidth = 2.7;
  g.lineCap = "round";
  for (let x = 2; x < 128; x += 8) {
    for (let y = 0; y < 128; y += 8) {
      g.beginPath();
      g.moveTo(x, y + 1);
      g.lineTo(x + 3, y + 4);
      g.lineTo(x + 1, y + 7);
      g.stroke();
    }
  }
  const bump = texOf(el, true);
  bump.colorSpace = NoColorSpace;
  return bump;
}

export function makeBookAtlas(): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 512;
  el.height = 128;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the book spines");
  const colors = ["#6e2430", "#1e3d32", "#8d6844", "#1c2636", "#6a3030", "#a6843c", "#4a3424", "#3e4654"];
  for (let i = 0; i < 8; i += 1) {
    const x = i * 64;
    g.fillStyle = colors[i];
    g.fillRect(x, 0, 64, 128);
    g.fillStyle = "rgba(255,255,255,0.16)";
    g.fillRect(x + 5, 0, 3, 128);
    g.fillStyle = "rgba(0,0,0,0.28)";
    g.fillRect(x + 56, 0, 8, 128);
    g.fillStyle = "rgba(247,241,228,0.88)";
    g.fillRect(x + 14, 26, 34, 5);
    g.fillRect(x + 14, 38, 26, 3);
    g.fillRect(x + 14, 96, 30, 3);
    g.fillStyle = "rgba(224,177,90,0.9)";
    g.fillRect(x + 14, 68, 16, 3);
  }
  return texOf(el);
}

const upholsteryCache = new Map<string, MeshStandardMaterial>();
let wovenBase: MeshStandardMaterial | undefined;

export function upholstery(color: string): MeshStandardMaterial {
  const cached = upholsteryCache.get(color);
  if (cached) return cached;
  if (!wovenBase) {
    const linen = paintSurface(128, 0.0018, (x, y) => {
      const warp = Math.cos(x * tau / 4), weft = Math.cos(y * tau / 4);
      const over = (Math.floor(x / 4) + Math.floor(y / 4)) % 2 === 0;
      const yarn = over ? warp * 8 + weft * 4 : weft * 8 + warp * 4;
      const slub = surfaceNoise(x * 0.5, y * 0.125) - 0.5;
      const shade = 242 + 0.65 * yarn + 8 * slub;
      return [shade, shade, shade - 1, 152 + yarn * 4 + slub * 17];
    });
    wovenBase = textured(linen, 0.91);
  }
  const material = wovenBase.clone();
  material.color.set(color);
  upholsteryCache.set(color, material);
  return material;
}

export function makeClothTexture(): CanvasTexture {
  return paintSurface(256, 0.002, (x, y) => {
    const cross = Math.cos(x * tau / 4 + (Math.floor(y / 4) % 2) * Math.PI);
    const weft = Math.cos(y * tau / 4);
    const warp = (x % 64) < 16 ? 12 : 0;
    const stripe = (y % 64) < 34 ? 18 : 0;
    const fine = (y % 64) < 2 || (x + 23) % 64 < 2 ? 27 : 0;
    const yarn = 3 * cross + 5 * weft;
    return [100 + stripe + warp + fine + yarn, 51 + stripe * 0.6 + warp + fine + yarn,
      58 + stripe * 0.42 + warp + fine + yarn, 142 + 23 * cross + 19 * weft];
  });
}

export function matte(color: string, roughness = 0.72, metalness = 0): MeshStandardMaterial {
  const key = `${color}|${roughness}|${metalness}`;
  let material = matteCache.get(key);
  if (!material) {
    material = new MeshStandardMaterial({ color: new Color(color), roughness, metalness });
    matteCache.set(key, material);
  }
  return material;
}

export function textured(map: CanvasTexture, roughness = 0.7, repeatX = 1, repeatY = 1): MeshStandardMaterial {
  function repeat(texture: CanvasTexture): CanvasTexture {
    const image = texture.clone();
    image.repeat.set(repeatX, repeatY);
    image.wrapS = RepeatWrapping;
    image.wrapT = RepeatWrapping;
    image.anisotropy = textureAnisotropy;
    image.needsUpdate = true;
    textures.push(image);
    return image;
  }
  const material = new MeshStandardMaterial({ map: repeat(map), roughness, metalness: 0 });
  const relief = reliefMaps.get(map);
  if (relief) {
    material.bumpMap = repeat(relief.map);
    material.bumpScale = relief.depth;
  }
  if (masonryMaps.has(map)) material.userData.masonry = true;
  return material;
}
