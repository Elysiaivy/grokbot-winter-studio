import {
  CanvasTexture,
  ClampToEdgeWrapping,
  Color,
  DoubleSide,
  MeshStandardMaterial,
  NoColorSpace,
  RepeatWrapping,
  SRGBColorSpace,
  type Texture,
} from "three";

export const textures: Texture[] = [];

function canvas(size = 256): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const el = document.createElement("canvas");
  el.width = size;
  el.height = size;
  const ctx = el.getContext("2d");
  if (!ctx) throw new Error("Could not draw the texture");
  return [el, ctx];
}

function texOf(el: HTMLCanvasElement, repeat = false): CanvasTexture {
  const tex = new CanvasTexture(el);
  tex.colorSpace = SRGBColorSpace;
  tex.wrapS = repeat ? RepeatWrapping : ClampToEdgeWrapping;
  tex.wrapT = repeat ? RepeatWrapping : ClampToEdgeWrapping;
  tex.anisotropy = 4;
  tex.needsUpdate = true;
  textures.push(tex);
  return tex;
}

export function tuneTextures(anisotropy: number): void {
  for (const tex of textures) tex.anisotropy = anisotropy;
}

function noise(x: number, y: number): number {
  const n = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
  return n - Math.floor(n);
}

export function makeWoodTexture(): CanvasTexture {
  const [el, g] = canvas(512);
  g.fillStyle = "#e4c196";
  g.fillRect(0, 0, 512, 512);
  const planks = [0, 78, 150, 236, 318, 392, 470, 512];
  for (let i = 0; i < planks.length - 1; i += 1) {
    const y0 = planks[i];
    const y1 = planks[i + 1];
    const n = noise(i, 3);
    const r = Math.floor(146 + n * 28);
    const gg = Math.floor(104 + n * 18);
    const b = Math.floor(68 + n * 12);
    g.fillStyle = `rgb(${r}, ${gg}, ${b})`;
    g.fillRect(0, y0 + 2, 512, y1 - y0 - 3);
    for (let x = 0; x < 512; x += 4) {
      const grain = noise(x * 0.15, i + 1);
      g.fillStyle = `rgba(120, 72, 36, ${0.04 + grain * 0.08})`;
      g.fillRect(x, y0 + 6, 2, y1 - y0 - 12);
    }
    g.fillStyle = "rgba(92, 58, 32, 0.35)";
    g.fillRect(0, y1 - 2, 512, 2);
  }
  return texOf(el, true);
}

export function makeBrickTexture(): CanvasTexture {
  const [el, g] = canvas(512);
  g.fillStyle = "#b7a898";
  g.fillRect(0, 0, 512, 512);
  const bw = 92;
  const bh = 40;
  for (let row = 0; row < 14; row += 1) {
    const offset = row % 2 ? bw / 2 : 0;
    for (let col = -1; col < 7; col += 1) {
      const x = col * bw + offset + 4;
      const y = row * bh + 4;
      const n = noise(col + 3, row + 5);
      const r = Math.floor(148 + n * 28);
      const gg = Math.floor(78 + n * 16);
      const b = Math.floor(68 + n * 10);
      g.fillStyle = `rgb(${r}, ${gg}, ${b})`;
      g.fillRect(x, y, bw - 8, bh - 8);
      g.fillStyle = `rgba(255, 220, 190, ${0.05 + n * 0.06})`;
      g.fillRect(x, y, bw - 8, 4);
    }
  }
  return texOf(el, true);
}

export function makePlasterTexture(): CanvasTexture {
  const [el, g] = canvas(256);
  g.fillStyle = "#cbbfae";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2200; i += 1) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const v = 150 + Math.floor(Math.random() * 40);
    g.fillStyle = `rgba(${v}, ${v - 8}, ${v - 16}, 0.22)`;
    g.fillRect(x, y, 2, 2);
  }
  return texOf(el, true);
}

export function makeRugTexture(main: string, motif: string): CanvasTexture {
  const [el, g] = canvas(256);
  g.fillStyle = main;
  g.fillRect(0, 0, 256, 256);
  g.strokeStyle = motif;
  g.globalAlpha = 0.35;
  g.lineWidth = 2;
  for (let i = 0; i < 5; i += 1) {
    g.beginPath();
    g.ellipse(128, 128, 36 + i * 22, 28 + i * 16, 0.2, 0, Math.PI * 2);
    g.stroke();
  }
  g.globalAlpha = 0.55;
  g.lineWidth = 6;
  g.strokeRect(14, 14, 228, 228);
  g.globalAlpha = 1;
  return texOf(el, true);
}

export function makeWindowGlass(): MeshStandardMaterial {
  const [el, g] = canvas(128);
  const tint = g.createLinearGradient(0, 0, 124, 128);
  tint.addColorStop(0, "#929292");
  tint.addColorStop(0.54, "#424242");
  tint.addColorStop(1, "#828282");
  g.fillStyle = tint;
  g.fillRect(0, 0, 128, 128);
  g.save();
  g.rotate(Math.PI / 5.5);
  g.fillStyle = "rgba(255, 255, 255, 0.29)";
  g.fillRect(24, -88, 13, 244);
  g.fillStyle = "rgba(255, 255, 255, 0.19)";
  g.fillRect(40, -88, 3, 244);
  g.restore();
  const alpha = texOf(el);
  alpha.colorSpace = NoColorSpace;
  return new MeshStandardMaterial({
    alphaMap: alpha,
    transparent: true,
    depthWrite: false,
    side: DoubleSide,
    forceSinglePass: true,
    opacity: 0.37,
    color: "#b0d5e0",
    emissive: "#77abc8",
    emissiveIntensity: 0.27,
    roughness: 0.26,
    metalness: 0.17,
  });
}

export function makeSignTexture(title: string, subtitle: string, paper: string, ink: string): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 512;
  el.height = 192;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the sign");
  g.fillStyle = paper;
  g.fillRect(0, 0, 512, 192);
  g.globalAlpha = 0.78;
  g.strokeStyle = ink;
  g.lineWidth = 3;
  g.strokeRect(12, 12, 488, 168);
  g.globalAlpha = 0.36;
  g.lineWidth = 1;
  g.strokeRect(21, 21, 470, 150);
  g.globalAlpha = 1;
  g.fillStyle = ink;
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.font = "bold 73px Georgia, 'Times New Roman', serif";
  g.fillText(title.toUpperCase(), 256, 79, 434);
  g.font = "600 29px system-ui, sans-serif";
  g.fillText(subtitle.toUpperCase(), 256, 136, 312);
  for (const x of [90, 422]) {
    g.beginPath();
    g.moveTo(x, 130);
    g.lineTo(x + 5, 135);
    g.lineTo(x, 140);
    g.lineTo(x - 5, 135);
    g.fill();
  }
  return texOf(el);
}

export function makeLabelTexture(text: string, ink = "#2a241e", paper = "#f7f1e4"): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 256;
  el.height = 80;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the nameplate");
  g.fillStyle = paper;
  g.fillRect(0, 0, 256, 80);
  g.strokeStyle = "#7a3140";
  g.lineWidth = 4;
  g.strokeRect(4, 4, 248, 72);
  g.fillStyle = ink;
  g.font = "600 28px system-ui, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(text.toUpperCase(), 128, 41, 225);
  return texOf(el);
}

export function makeChartTexture(kind: "line" | "bars", title: string, accent: string, background: string): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 256;
  el.height = 160;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the monitor texture");
  g.fillStyle = background;
  g.fillRect(0, 0, 256, 160);
  g.fillStyle = accent;
  g.font = "bold 15px system-ui, sans-serif";
  g.fillText(title, 16, 24);
  g.fillRect(219, 15, 18, 7);
  g.strokeStyle = accent;
  g.globalAlpha = 0.35;
  g.lineWidth = 1;
  for (let i = 1; i < 4; i += 1) {
    g.beginPath();
    g.moveTo(16, 20 + i * 30);
    g.lineTo(240, 20 + i * 30);
    g.stroke();
  }
  g.globalAlpha = 1;
  if (kind === "line") {
    g.strokeStyle = accent;
    g.lineWidth = 4;
    g.beginPath();
    const ys = [132, 109, 115, 79, 89, 69, 72, 44, 51];
    ys.forEach((y, i) => {
      const x = 20 + i * 28;
      if (i === 0) g.moveTo(x, y);
      else g.lineTo(x, y);
    });
    g.stroke();
  } else {
    const heights = [40, 70, 48, 90, 62, 84];
    heights.forEach((h, i) => {
      g.fillStyle = i % 2 ? "#e5ac7a" : accent;
      g.fillRect(24 + i * 36, 130 - h, 22, h);
    });
  }
  return texOf(el);
}

export function makeNoteTexture(): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 512;
  el.height = 384;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the noticeboard");
  g.fillStyle = "#efe2cc";
  g.fillRect(0, 0, 512, 384);
  const notes = [
    { x: 24, y: 24, w: 200, h: 140, c: "#f7f1e4", t: "Keep hall clear" },
    { x: 250, y: 36, w: 220, h: 120, c: "#f3e4e2", t: "Tea in kitchen" },
    { x: 40, y: 190, w: 180, h: 150, c: "#e7efe8", t: "Lights on steady" },
    { x: 250, y: 186, w: 220, h: 160, c: "#f8f4ea", t: "Winter rota" },
  ];
  for (const note of notes) {
    g.fillStyle = note.c;
    g.fillRect(note.x, note.y, note.w, note.h);
    g.strokeStyle = "rgba(80,60,40,0.25)";
    g.strokeRect(note.x, note.y, note.w, note.h);
    g.fillStyle = "#3a3128";
    g.font = "22px Georgia, serif";
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillText(note.t, note.x + note.w / 2, note.y + note.h / 2, note.w - 20);
  }
  return texOf(el);
}

export function makeRadial(): CanvasTexture {
  const [el, g] = canvas(128);
  const grd = g.createRadialGradient(64, 64, 8, 64, 64, 64);
  grd.addColorStop(0, "rgba(0,0,0,0.45)");
  grd.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  return texOf(el);
}

const matteCache = new Map<string, MeshStandardMaterial>();

export function fork(material: MeshStandardMaterial): MeshStandardMaterial {
  return material.clone();
}

export function makeSlateTexture(): CanvasTexture {
  const [el, g] = canvas(512);
  g.fillStyle = "#3a4046";
  g.fillRect(0, 0, 512, 512);
  const bh = 26;
  const bw = 58;
  for (let row = 0; row < 22; row += 1) {
    const offset = row % 2 ? bw / 2 : 0;
    for (let col = -1; col < 12; col += 1) {
      const x = col * bw + offset;
      const y = row * bh;
      const n = noise(col + 2, row + 4);
      const v = Math.floor(78 + n * 46);
      g.fillStyle = `rgb(${v - 4}, ${v}, ${v + 3})`;
      g.fillRect(x + 1, y + 1, bw - 3, bh - 4);
      g.fillStyle = `rgba(20, 22, 24, ${0.35 + n * 0.25})`;
      g.fillRect(x + 1, y + bh - 5, bw - 3, 4);
      g.fillStyle = `rgba(210, 206, 196, ${0.05 + n * 0.08})`;
      g.fillRect(x + 8, y + 5, 14, 2);
    }
  }
  g.fillStyle = "rgba(18, 20, 22, 0.4)";
  g.beginPath();
  g.ellipse(210, 260, 48, 20, 0.5, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = "rgba(90, 78, 64, 0.25)";
  g.fillRect(40, 300, 90, 18);
  return texOf(el, true);
}

export function makeKeyboardMaterial(worn = false): MeshStandardMaterial {
  const el = document.createElement("canvas");
  const resolution = worn ? 2 : 1;
  el.width = 256 * resolution;
  el.height = 128 * resolution;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the keyboard");
  g.scale(resolution, resolution);
  g.fillStyle = "#1a1e24";
  g.fillRect(0, 0, 256, 128);
  const [roughnessCanvas, roughness] = worn ? canvas(256) : [];
  if (roughness) {
    roughness.scale(1, 2);
    roughness.fillStyle = "#bababa";
    roughness.fillRect(0, 0, 256, 128);
  }
  for (let row = 0; row < 4; row += 1) {
    for (let col = 0; col < 13; col += 1) {
      const space = row === 3 && col >= 4 && col <= 8;
      if (space && col > 4) continue;
      const w = space ? 86 : 14;
      const x = 8 + col * 18 + (!worn && row === 3 && col > 8 ? 68 : 0);
      const y = 10 + row * 28;
      const accent = row === 1 && col === 12;
      if (roughness) {
        const polished = row === 2 && (col === 4 || col === 7);
        g.fillStyle = accent ? "#9b6555" : polished ? "#cfdbd2" : "#a4b6af";
        g.beginPath();
        g.roundRect(x, y, w, 18, 2.3);
        g.fill();
        g.fillStyle = "rgba(17, 34, 33, 0.30)";
        g.fillRect(x + 2, y + 15, w - 4, 2);
        if (polished) {
          const shine = g.createLinearGradient(x, y, x + w, y + 10);
          shine.addColorStop(0, "rgba(235, 249, 236, 0.1)");
          shine.addColorStop(0.6, "rgba(235, 249, 236, 0.7)");
          shine.addColorStop(1, "rgba(235, 249, 236, 0.05)");
          g.fillStyle = shine;
          g.fillRect(x + 2, y + 1, w - 4, 10);
          g.fillStyle = "#50645d";
          g.font = "bold 8px system-ui, sans-serif";
          g.fillText(col === 4 ? "F" : "J", x + 4, y + 10);
          roughness.fillStyle = "#4f4f4f";
          roughness.fillRect(x + 1, y + 1, w - 2, 15);
        }
        continue;
      }
      g.fillStyle = accent ? "#8d3a32" : `rgb(${186 + (col % 3) * 8}, ${190 + (row % 2) * 6}, ${196})`;
      g.fillRect(x, y, w, 18);
      g.fillStyle = "rgba(20, 16, 14, 0.35)";
      g.fillRect(x, y + 16, w, 2);
    }
  }
  const material = new MeshStandardMaterial({ map: texOf(el), roughness: worn ? 0.96 : 0.62, metalness: 0.04 });
  if (roughnessCanvas) {
    material.roughnessMap = texOf(roughnessCanvas);
    material.roughnessMap.colorSpace = NoColorSpace;
  }
  return material;
}

export function makeKnitBump(): CanvasTexture {
  const [el, g] = canvas(128);
  g.fillStyle = "#333";
  g.fillRect(0, 0, 128, 128);
  g.strokeStyle = "#aaa";
  g.lineWidth = 2.7;
  g.lineCap = "round";
  for (let x = 2; x < 128; x += 8) {
    for (let y = 0; y < 128; y += 8) {
      g.beginPath();
      g.moveTo(x, y + 1);
      g.lineTo(x + 3, y + 4);
      g.lineTo(x + 1, y + 7);
      g.stroke();
    }
  }
  const bump = texOf(el, true);
  bump.colorSpace = NoColorSpace;
  return bump;
}

export function makeBookAtlas(): CanvasTexture {
  const el = document.createElement("canvas");
  el.width = 512;
  el.height = 128;
  const g = el.getContext("2d");
  if (!g) throw new Error("Could not draw the book spines");
  const colors = ["#6e2430", "#1e3d32", "#8d6844", "#1c2636", "#6a3030", "#a6843c", "#4a3424", "#3e4654"];
  for (let i = 0; i < 8; i += 1) {
    const x = i * 64;
    g.fillStyle = colors[i];
    g.fillRect(x, 0, 64, 128);
    g.fillStyle = "rgba(255,255,255,0.16)";
    g.fillRect(x + 5, 0, 3, 128);
    g.fillStyle = "rgba(0,0,0,0.28)";
    g.fillRect(x + 56, 0, 8, 128);
    g.fillStyle = "rgba(247,241,228,0.88)";
    g.fillRect(x + 14, 26, 34, 5);
    g.fillRect(x + 14, 38, 26, 3);
    g.fillRect(x + 14, 96, 30, 3);
    g.fillStyle = "rgba(224,177,90,0.9)";
    g.fillRect(x + 14, 68, 16, 3);
  }
  return texOf(el);
}

export function makeClothTexture(): CanvasTexture {
  const [el, g] = canvas(256);
  g.fillStyle = "#6a3140";
  g.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 4) {
    g.fillStyle = y % 20 === 0 ? "rgba(236, 224, 204, 0.38)" : "rgba(30, 10, 14, 0.08)";
    g.fillRect(0, y, 256, y % 20 === 0 ? 3 : 1);
  }
  for (let x = 0; x < 256; x += 3) {
    g.fillStyle = `rgba(40, 16, 20, ${0.03 + noise(x, 4) * 0.06})`;
    g.fillRect(x, 0, 1, 256);
  }
  return texOf(el, true);
}

export function matte(color: string, roughness = 0.72, metalness = 0): MeshStandardMaterial {
  const key = `${color}|${roughness}|${metalness}`;
  let material = matteCache.get(key);
  if (!material) {
    material = new MeshStandardMaterial({ color: new Color(color), roughness, metalness });
    matteCache.set(key, material);
  }
  return material;
}

export function textured(map: CanvasTexture, roughness = 0.7, repeatX = 1, repeatY = 1): MeshStandardMaterial {
  const image = map.clone();
  image.repeat.set(repeatX, repeatY);
  image.wrapS = RepeatWrapping;
  image.wrapT = RepeatWrapping;
  image.colorSpace = SRGBColorSpace;
  image.needsUpdate = true;
  textures.push(image);
  return new MeshStandardMaterial({ map: image, roughness, metalness: 0 });
}
