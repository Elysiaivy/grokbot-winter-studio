import {
  BoxGeometry, CanvasTexture, CylinderGeometry, DoubleSide, ExtrudeGeometry, Group, Mesh, Object3D, PlaneGeometry,
  PointLight, RingGeometry, Shape, ShapeGeometry, SphereGeometry, SpotLight, SRGBColorSpace, Vector3, type BufferGeometry, type MeshStandardMaterial,
} from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { UPPER_COLUMNS, UPPER_FLOOR, UPPER_STAIR } from "../sim/upperFloor";
import { makeRugTexture, matte, textured, upholstery } from "./factory";
import { mergeStatic } from "./merge";

interface LoftFinishes {
  floor: MeshStandardMaterial;
  wood: MeshStandardMaterial;
  woodDark: MeshStandardMaterial;
  gold: MeshStandardMaterial;
  shade: MeshStandardMaterial;
  pineFabric: MeshStandardMaterial;
  fabric: MeshStandardMaterial;
}

type Point = [x: number, y: number, z: number];
const up = new Vector3(0, 1, 0);
const floorHeight = UPPER_FLOOR.level;

function place(parent: Object3D, geometry: BufferGeometry, finish: MeshStandardMaterial, x: number, y: number, z: number) {
  const mesh = new Mesh(geometry, finish);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function board(parent: Object3D, finish: MeshStandardMaterial, size: Point, position: Point, radius = 0) {
  const geometry = radius ? new RoundedBoxGeometry(...size, 2, radius) : new BoxGeometry(...size);
  return place(parent, geometry, finish, ...position);
}

function rod(parent: Object3D, finish: MeshStandardMaterial, start: Point, end: Point, radius: number) {
  const axis = new Vector3(...end).sub(new Vector3(...start));
  const mesh = place(parent, new CylinderGeometry(radius, radius, axis.length(), 8), finish,
    (start[0] + end[0]) / 2, (start[1] + end[1]) / 2, (start[2] + end[2]) / 2);
  mesh.quaternion.setFromUnitVectors(up, axis.normalize());
}

type PlanPoint = readonly [x: number, z: number];

function beam(parent: Object3D, finish: MeshStandardMaterial, a: Point, b: Point, width: number, depth: number) {
  const delta = new Vector3(...b).sub(new Vector3(...a));
  const length = delta.length();
  const mesh = board(parent, finish, [width, length, depth],
    [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]);
  mesh.quaternion.setFromUnitVectors(up, delta.normalize());
}

function edgeBoard(parent: Object3D, finish: MeshStandardMaterial, from: PlanPoint, to: PlanPoint,
  y: number, height: number, thickness: number) {
  const dx = to[0] - from[0], dz = to[1] - from[1];
  const piece = board(parent, finish, [Math.hypot(dx, dz), height, thickness],
    [(from[0] + to[0]) / 2, y, (from[1] + to[1]) / 2]);
  piece.rotation.y = -Math.atan2(dz, dx);
}

export function buildReadingLoft(parent: Object3D, finishes: LoftFinishes) {
  const loft = new Group();
  loft.name = "reading-loft";
  loft.position.y = floorHeight;
  // Keep the upper storey together for cutaways and picking the original desks below.
  loft.userData.keep = true;
  parent.add(loft);

  const iron = matte("#344543", 0.58, 0.35);
  const oak = matte("#9a6946", 0.50);
  addFloorStructure(loft, finishes, iron, oak);
  addStair(loft, finishes, iron, oak);

  const readingCorner = new Group();
  readingCorner.position.set(-1.87, 0, -0.10);
  loft.add(readingCorner);
  const floorLamp = addReadingCorner(readingCorner, finishes);
  const tableLamp = addLibraryTable(loft, finishes, iron);
  mergeStatic(loft);
  return { root: loft, setLamps(amount: number) {
    floorLamp.intensity = 0.10 + amount * 1.10;
    tableLamp.intensity = 0.035 + amount * 0.42;
  } };
}

function addFloorStructure(loft: Group, { wood, woodDark, gold, floor, shade }: LoftFinishes,
  iron: MeshStandardMaterial, oak: MeshStandardMaterial) {
  const { outline, minX, maxX, backZ, frontZ, treeCutX, treeCutZ } = UPPER_FLOOR;
  const shape = new Shape();
  const [first, ...remaining] = outline;
  shape.moveTo(first[0], -first[1]);
  for (const [x, z] of remaining) shape.lineTo(x, -z);
  shape.closePath();
  const slabThickness = 0.15;
  const deck = new ExtrudeGeometry(shape, { depth: slabThickness, bevelEnabled: false });
  deck.rotateX(-Math.PI / 2);
  // The floorboards have a constant physical scale across the clipped tree corner.
  const uv = deck.attributes.uv;
  const pos = deck.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    uv.setXY(i, (pos.getX(i) - minX) / 5.5, (pos.getZ(i) - frontZ) / 4.8);
  }
  place(loft, deck, floor, 0, -slabThickness, 0);

  for (const {x, z} of UPPER_COLUMNS) {
    const postHeight = floorHeight - 0.22;
    board(loft, iron, [0.114, postHeight, 0.114], [x, -floorHeight + postHeight / 2, z]);
    board(loft, iron, [0.215, 0.040, 0.215], [x, -floorHeight + 0.023, z]);
    board(loft, iron, [0.228, 0.059, 0.213], [x, -0.236, z]);
  }
  // Joists butt into the diagonal perimeter beam rather than bridging the tree opening.
  for (const x of [-0.66, 0.10, 0.86, 1.62, 2.38, 3.14, 3.90, 4.66]) {
    const clippedFront = x < treeCutX
      ? treeCutZ + (frontZ - treeCutZ) * (x - minX) / (treeCutX - minX)
      : frontZ;
    const span = backZ - clippedFront - 0.14;
    board(loft, woodDark, [0.075, 0.118, span], [x, -0.207, backZ - span / 2 - 0.045]);
  }
  for (let i = 0; i < 3; i++) {
    const from = outline[i], to = outline[i + 1];
    edgeBoard(loft, woodDark, from, to, -0.20, 0.207, 0.123);
    edgeBoard(loft, wood, from, to, -0.086, 0.15, 0.142);
    edgeBoard(loft, oak, from, to, -0.018, 0.040, 0.164);
  }
  // Three modest flush lights under the mezzanine mark each bar stool.
  for (const x of [1.25, 2.85, 4.45]) {
    place(loft, new CylinderGeometry(0.115, 0.120, 0.036, 16), iron, x, -0.169, 3.44);
    place(loft, new CylinderGeometry(0.087, 0.090, 0.016, 16), shade, x, -0.192, 3.44);
  }

  const rail = (a: PlanPoint, b: PlanPoint) => {
    const dx = b[0] - a[0], dz = b[1] - a[1], span = Math.hypot(dx, dz);
    const bays = Math.max(1, Math.round(span / 0.86));
    rod(loft, oak, [a[0], 0.79, a[1]], [b[0], 0.79, b[1]], 0.035);
    edgeBoard(loft, iron, a, b, 0.133, 0.036, 0.030);
    for (let i = 0; i < bays; i++) {
      for (let j = 1; j < 5; j++) {
        const t = (i + j / 5) / bays;
        const x = a[0] + t * dx, z = a[1] + t * dz;
        board(loft, iron, [0.016, 0.642, 0.016], [x, 0.452, z]);
      }
    }
    for (let i = 0; i < bays; i++) {
      const t = i / bays;
      const x = a[0] + dx * t, z = a[1] + dz * t;
      board(loft, iron, [0.042, 0.766, 0.042], [x, 0.383, z]);
      board(loft, gold, [0.055, 0.031, 0.055], [x, 0.742, z]);
    }
  };

  rail(outline[0], outline[1]);
  rail(outline[1], outline[2]);
  rail(outline[2], [UPPER_STAIR.minX + 0.04, frontZ]);
  rail([UPPER_STAIR.maxX - 0.04, frontZ], [maxX, frontZ]);
  board(loft, iron, [0.042, 0.766, 0.042], [maxX, 0.383, frontZ]);
}

function addStair(loft: Group, { wood, woodDark, gold }: LoftFinishes, iron: MeshStandardMaterial, oak: MeshStandardMaterial) {
  const { minX, maxX, footZ, landingZ, steps } = UPPER_STAIR;
  const rise = floorHeight / steps;
  const going = (landingZ - footZ) / (steps - 1);
  const center = (minX + maxX) / 2;
  const width = maxX - minX;
  // Twelve independent treads and the upper floor form thirteen equal risers.
  for (let i = 0; i < steps - 1; i++) {
    const top = -floorHeight + (i + 1) * rise;
    const z = footZ + i * going;
    board(loft, wood, [width, 0.065, going + 0.020], [center, top - 0.0325, z + going / 2], 0.009);
    board(loft, oak, [width - 0.03, 0.020, 0.018], [center, top - 0.014, z - 0.007]);
  }
  for (const x of [minX + 0.04, maxX - 0.04]) {
    const lower: Point = [x, -floorHeight + rise - 0.066, footZ];
    const upper: Point = [x, -0.066, landingZ];
    beam(loft, woodDark, lower, upper, 0.075, 0.133);
    rod(loft, oak, [x, lower[1] + 0.856, footZ], [x, 0.79, landingZ], 0.034);
    rod(loft, iron, [x, lower[1] + 0.41, footZ], [x, 0.344, landingZ], 0.013);
    for (const i of [0, 3, 6, 9, 12]) {
      const top = lower[1] + i * rise;
      const z = footZ + i * going;
      board(loft, iron, [0.037, 0.845, 0.037], [x, top + 0.422, z]);
      board(loft, gold, [0.048, 0.028, 0.048], [x, top + 0.817, z]);
    }
  }
}

function addReadingCorner(loft: Group, { wood, woodDark, gold, shade, pineFabric, fabric }: LoftFinishes) {
  const rust = upholstery("#a35a45");
  const spruce = upholstery("#41766e");
  const linen = upholstery("#e7cba3");
  const plum = matte("#79404a", 0.72);
  const rug = place(loft, new CylinderGeometry(1, 1, 0.018, 32), rust, 2.69, 0.010, 3.37);
  rug.scale.set(1.08, 1, 0.63);
  for (const radius of [0.89, 0.94]) {
    const border = place(loft, new RingGeometry(radius - 0.012, radius, 40), linen, 2.69, 0.020, 3.37);
    border.rotation.x = -Math.PI / 2;
    border.scale.set(1.08, 0.63, 1);
  }

  // An upholstered slipper chair, turned towards the tree and the open side of the gallery.
  const chair = new Group();
  chair.position.set(2.77, 0.02, 3.48);
  chair.rotation.y = 0.34;
  loft.add(chair);
  for (const x of [-0.28, 0.28]) for (const z of [-0.25, 0.26]) {
    rod(chair, woodDark, [x * 1.09, 0.01, z * 1.12], [x, 0.23, z], 0.045);
  }
  board(chair, woodDark, [0.76, 0.115, 0.69], [0, 0.197, 0], 0.036);
  board(chair, spruce, [0.72, 0.17, 0.61], [0, 0.30, -0.049], 0.076);
  const back = board(chair, pineFabric, [0.77, 0.59, 0.166], [0, 0.515, 0.256], 0.079);
  back.rotation.x = 0.14;
  for (const side of [-1, 1]) {
    board(chair, spruce, [0.136, 0.275, 0.59], [side * 0.333, 0.386, 0.011], 0.064);
    board(chair, wood, [0.115, 0.042, 0.51], [side * 0.34, 0.518, -0.022], 0.018);
  }
  const cushion = board(chair, rust, [0.34, 0.265, 0.105], [-0.11, 0.492, 0.097], 0.048);
  cushion.rotation.set(0.23, -0.13, -0.14);
  board(chair, linen, [0.20, 0.038, 0.255], [0.339, 0.550, -0.064], 0.017);
  board(chair, linen, [0.037, 0.196, 0.255], [0.426, 0.464, -0.064], 0.015);
  for (const z of [-0.137, 0.014]) {
    board(chair, plum, [0.197, 0.005, 0.018], [0.339, 0.571, z]);
    board(chair, plum, [0.005, 0.17, 0.018], [0.447, 0.468, z]);
  }

  // A low bookcase preserves the view across the rear garland.
  const shelfX = 1.88, shelfZ = 3.89;
  board(loft, woodDark, [1.30, 0.60, 0.045], [shelfX, 0.32, shelfZ + 0.10]);
  for (const x of [shelfX - 0.64, shelfX + 0.64]) {
    board(loft, wood, [0.057, 0.64, 0.27], [x, 0.32, shelfZ]);
  }
  const covers = [pineFabric, rust, plum, woodDark, spruce];
  for (let row = 0; row < 2; row += 1) {
    const shelfY = 0.068 + 0.278 * row;
    board(loft, wood, [1.31, 0.038, 0.285], [shelfX, shelfY - 0.019, shelfZ]);
    for (let i = 0; i < 9; i += 1) {
      const x = shelfX - 0.533 + i * 0.119;
      const height = 0.176 + (i * 2 + row) % 4 * 0.02;
      board(loft, covers[(i * 2 + row) % covers.length], [0.096, height, 0.155], [x, shelfY + height / 2, shelfZ - 0.039]);
      board(loft, linen, [0.061, 0.013, 0.006], [x, shelfY + height * 0.75, shelfZ - 0.119]);
    }
  }
  board(loft, wood, [1.39, 0.059, 0.33], [shelfX, 0.645, shelfZ], 0.018);

  const tableX = 1.99, tableZ = 3.12;
  for (const y of [0.059, 0.41]) {
    const radius = y < 0.1 ? 0.15 : 0.278;
    place(loft, new CylinderGeometry(radius, radius * 0.96, 0.048, 18), wood, tableX, y, tableZ);
  }
  rod(loft, gold, [tableX, 0.061, tableZ], [tableX, 0.401, tableZ], 0.032);
  const book = new Group();
  book.position.set(tableX, 0.435, tableZ);
  book.rotation.y = -0.28;
  loft.add(book);
  board(book, plum, [0.36, 0.020, 0.25], [0, 0.011, 0], 0.007);
  for (const side of [-1, 1]) {
    const leaf = board(book, fabric, [0.162, 0.025, 0.23], [side * 0.084, 0.034, 0], 0.008);
    leaf.rotation.z = side * 0.095;
    for (const z of [-0.054, -0.015, 0.025, 0.062]) {
      board(leaf, woodDark, [0.092, 0.002, 0.008], [0.006, 0.014, z]);
    }
  }

  // Brass reading lamp with an opaque, warm pleated shade and bound edges.
  const lampX = 3.51, lampZ = 3.65;
  place(loft, new CylinderGeometry(0.132, 0.164, 0.056, 16), woodDark, lampX, 0.034, lampZ);
  place(loft, new CylinderGeometry(0.088, 0.13, 0.043, 16), gold, lampX, 0.078, lampZ);
  rod(loft, gold, [lampX, 0.089, lampZ], [lampX, 0.885, lampZ], 0.024);
  rod(loft, gold, [lampX, 0.878, lampZ], [lampX - 0.14, 0.959, lampZ], 0.022);
  const shadeX = lampX - 0.14;
  const pleats = new CylinderGeometry(0.122, 0.241, 0.226, 32);
  const positions = pleats.getAttribute("position");
  for (let i = 0; i < positions.count; i += 1) {
    const x = positions.getX(i), z = positions.getZ(i);
    const fold = Math.round(Math.atan2(x, z) * 16 / Math.PI);
    const scale = Math.abs(fold) % 2 ? 0.91 : 1;
    positions.setXYZ(i, x * scale, positions.getY(i), z * scale);
  }
  pleats.computeVertexNormals();
  place(loft, pleats, shade, shadeX, 0.987, lampZ);
  for (const [y, radius] of [[0.878, 0.233], [1.096, 0.119]]) {
    place(loft, new CylinderGeometry(radius, radius, 0.016, 24), gold, shadeX, y, lampZ);
  }
  const light = new PointLight("#ffd3a1", 0, 1.75, 2);
  light.position.set(shadeX, 0.85, lampZ);
  loft.add(light);
  return light;
}

function addLibraryTable(loft: Group, { wood, woodDark, gold, shade }: LoftFinishes, iron: MeshStandardMaterial) {
  const table = new Group();
  table.position.set(3.76, 0, 2.40);
  loft.add(table);
  const carpet = textured(makeRugTexture("#475d55", "#cbbb99"), 0.94, 1, 1);
  const rug = place(table, new PlaneGeometry(2.38, 2.70), carpet, 0, 0.013, 0);
  rug.rotation.x = -Math.PI / 2;

  // Quarter-sawn oak refectory table with two trestles and a through stretcher.
  board(table, wood, [1.03, 0.085, 2.05], [0, 0.77, 0], 0.022);
  board(table, woodDark, [0.92, 0.037, 1.93], [0, 0.713, 0], 0.012);
  for (const z of [-0.69, 0.69]) {
    board(table, woodDark, [0.74, 0.082, 0.17], [0, 0.055, z], 0.018);
    for (const side of [-1, 1]) {
      beam(table, wood, [side * 0.276, 0.093, z], [side * 0.153, 0.682, z], 0.077, 0.12);
    }
    board(table, wood, [0.74, 0.082, 0.15], [0, 0.681, z], 0.016);
  }
  board(table, wood, [0.095, 0.093, 1.56], [0, 0.265, 0], 0.009);
  for (const x of [-0.85, 0.85]) for (const z of [-0.52, 0.52]) {
    const chair = new Group();
    chair.position.set(x, 0.016, z);
    chair.rotation.y = x > 0 ? Math.PI / 2 : -Math.PI / 2;
    chair.rotation.y += z < 0 && x < 0 ? 0.09 : 0;
    table.add(chair);
    for (const side of [-1, 1]) {
      beam(chair, woodDark, [side * 0.175, 0, -0.165], [side * 0.147, 0.405, -0.141], 0.039, 0.041);
      beam(chair, woodDark, [side * 0.188, 0, 0.197], [side * 0.159, 0.835, 0.233], 0.042, 0.042);
    }
    board(chair, woodDark, [0.436, 0.066, 0.418], [0, 0.404, 0.012], 0.028);
    board(chair, upholstery("#6e8071"), [0.397, 0.058, 0.361], [0, 0.452, -0.006], 0.027);
    const crest = board(chair, wood, [0.431, 0.164, 0.053], [0, 0.764, 0.229], 0.024);
    crest.rotation.x = 0.10;
    for (const side of [-1, 1]) {
      beam(chair, wood, [side * 0.074, 0.449, 0.18], [side * 0.096, 0.705, 0.219], 0.030, 0.033);
    }
  }
  const top = 0.814;
  const binding = matte("#643930", 0.74);
  const paper = matte("#e3d4b1", 0.83);
  const chart = new Group();
  chart.position.set(-0.035, top, 0.51);
  chart.rotation.y = -0.19;
  table.add(chart);
  board(chart, binding, [0.61, 0.023, 0.425], [0, 0.014, 0], 0.008);
  const maps = textured(atlasTexture(), 0.88, 1, 1);
  for (const side of [-1, 1]) {
    const leaf = new Group();
    leaf.position.set(side * 0.144, 0.042, 0);
    leaf.rotation.z = side * 0.057;
    chart.add(leaf);
    board(leaf, paper, [0.284, 0.039, 0.397], [0, 0, 0], 0.006);
    const print = new PlaneGeometry(0.281, 0.393);
    const uv = print.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setX(i, (uv.getX(i) + (side > 0 ? 1 : 0)) / 2);
    place(leaf, print, maps, 0, 0.0205, 0).rotation.x = -Math.PI / 2;
  }
  const stack = new Group();
  stack.position.set(0.18, top, -0.62);
  stack.rotation.y = 0.17;
  table.add(stack);
  for (const [i, finish] of [iron, binding].entries()) {
    board(stack, finish, [0.28, 0.049, 0.385], [i * 0.018, 0.025 + i * 0.052, 0], 0.008);
    board(stack, paper, [0.257, 0.029, 0.367], [0.014 + i * 0.018, 0.025 + i * 0.052, -0.007]);
  }
  board(stack, gold, [0.168, 0.003, 0.012], [0.023, 0.103, -0.092]);

  // Enamel library lamp with a brass yoke and an opal lower diffuser.
  const lampX = 0.10, lampZ = -0.09;
  const enamel = matte("#254b3d", 0.31, 0.20);
  const base = place(table, new CylinderGeometry(0.133, 0.15, 0.044, 20), gold, lampX, top + 0.026, lampZ);
  base.scale.z = 0.69;
  rod(table, gold, [lampX, top + 0.048, lampZ], [lampX, top + 0.36, lampZ], 0.021);
  for (const side of [-1, 1]) {
    rod(table, gold, [lampX, top + 0.31, lampZ], [lampX + side * 0.187, top + 0.413, lampZ], 0.012);
  }
  const hood = place(table, new SphereGeometry(1, 20, 8, 0, Math.PI * 2, 0, Math.PI * 0.56),
    enamel, lampX, top + 0.426, lampZ);
  hood.scale.set(0.22, 0.088, 0.092);
  const diffuser = place(table, new CylinderGeometry(0.192, 0.192, 0.012, 20), shade,
    lampX, top + 0.410, lampZ);
  diffuser.scale.z = 0.43;

  addCornerPlant(loft, 0.02, 2.41);
  const light = new SpotLight("#ffdfa8", 0, 2.3, 1.14, 0.82, 2);
  light.position.set(lampX, top + 0.38, lampZ);
  light.target.position.set(lampX - 0.04, top - 0.22, lampZ + 0.16);
  light.castShadow = true;
  light.shadow.mapSize.set(256, 256);
  light.shadow.camera.near = 0.06;
  light.shadow.bias = -0.0012;
  light.shadow.autoUpdate = false;
  light.shadow.needsUpdate = true;
  table.add(light, light.target);
  return light;
}

// Small engravings remain readable when the camera reaches the open atlas.
function atlasTexture(): CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 328;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#e9ddbf";
  ctx.fillRect(0, 0, 512, 328);
  ctx.save();
  ctx.beginPath();
  ctx.rect(18, 38, 476, 266);
  ctx.clip();
  const islands = [[94, 117, 100, 72], [319, 262, 104, 65], [425, 104, 87, 58]];
  ctx.strokeStyle = "#bba988";
  ctx.lineWidth = 1.15;
  for (const [x, y, w, h] of islands) for (let ring = 1; ring < 10; ring++) {
    ctx.beginPath();
    for (let i = 0; i <= 80; i++) {
      const angle = i * Math.PI / 40;
      const radius = (ring / 7) * (1 + 0.13 * Math.sin(angle * 3 + y) + 0.08 * Math.cos(angle * 5 + x));
      const px = x + Math.cos(angle) * w * radius, py = y + Math.sin(angle) * h * radius;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();
  }
  ctx.lineWidth = 8;
  ctx.strokeStyle = "#90adab";
  ctx.beginPath();
  ctx.moveTo(4, 258);
  ctx.bezierCurveTo(86, 178, 122, 327, 238, 162);
  ctx.bezierCurveTo(307, 78, 370, 149, 514, 54);
  ctx.stroke();
  ctx.lineWidth = 2;
  ctx.strokeStyle = "#9f6c4e";
  ctx.setLineDash([8, 4]);
  ctx.beginPath();
  ctx.moveTo(37, 271);
  ctx.bezierCurveTo(157, 276, 176, 57, 347, 112);
  ctx.quadraticCurveTo(418, 149, 490, 121);
  ctx.stroke();
  ctx.restore();
  ctx.strokeStyle = "#8a7659";
  ctx.strokeRect(18, 38, 476, 266);
  ctx.fillStyle = "#565247";
  ctx.font = "15px Georgia, serif";
  ctx.fillText("WINTER  ATLAS", 19, 25);
  ctx.font = "10px Georgia, serif";
  ctx.fillText("PLATE  IV", 437, 25);
  const crease = ctx.createLinearGradient(239, 0, 270, 0);
  crease.addColorStop(0, "rgba(80,61,48,0)");
  crease.addColorStop(0.5, "rgba(80,61,48,0.17)");
  crease.addColorStop(1, "rgba(80,61,48,0)");
  ctx.fillStyle = crease;
  ctx.fillRect(239, 0, 31, 328);
  const map = new CanvasTexture(canvas);
  map.colorSpace = SRGBColorSpace;
  return map;
}

function addCornerPlant(loft: Group, x: number, z: number) {
  const terracotta = matte("#975f43", 0.84);
  const soil = matte("#4a3929", 0.98);
  place(loft, new CylinderGeometry(0.184, 0.129, 0.283, 18), terracotta, x, 0.151, z);
  place(loft, new CylinderGeometry(0.199, 0.185, 0.051, 18), terracotta, x, 0.287, z);
  place(loft, new CylinderGeometry(0.168, 0.168, 0.022, 18), soil, x, 0.313, z);
  const leaves = ["#496442", "#66754b", "#3f5944"].map((color) => {
    const material = matte(color, 0.72).clone();
    material.side = DoubleSide;
    return material;
  });
  const leaf = new Shape();
  leaf.moveTo(0, 0);
  leaf.bezierCurveTo(-0.158, 0.15, -0.096, 0.43, 0, 0.59);
  leaf.bezierCurveTo(0.128, 0.35, 0.119, 0.096, 0, 0);
  const blade = new ShapeGeometry(leaf, 10);
  for (let i = 0; i < 9; i++) {
    const yaw = i * 2.40;
    const foliage = place(loft, blade, leaves[i % 3], x + Math.sin(yaw) * 0.021, 0.319, z + Math.cos(yaw) * 0.021);
    foliage.rotation.order = "YXZ";
    foliage.rotation.set(0.34 + (i % 4) * 0.21, yaw, 0.05);
    foliage.scale.setScalar(0.79 + (i % 3) * 0.115);
  }
}
