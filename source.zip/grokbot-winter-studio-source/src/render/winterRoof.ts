import {
  BoxGeometry, CanvasTexture, CylinderGeometry, ExtrudeGeometry,
  Group, Mesh, MeshStandardMaterial, PlaneGeometry, RepeatWrapping, Shape, SRGBColorSpace,
} from "three";
import { UPPER_FLOOR } from "../sim/upperFloor";
import { laySnow, snowNoise } from "./snowCover";
import { matte } from "./factory";

interface RoofOptions {
  cx: number;
  cz: number;
  eaveY: number;
  width: number;
  run: number;
  rise: number;
  slate: MeshStandardMaterial;
  glass: MeshStandardMaterial;
  shade: MeshStandardMaterial;
}

type Field = (x: number, z: number) => number;

const cube = new BoxGeometry();
function box(parent: Group, material: MeshStandardMaterial, x: number, y: number, z: number, w: number, h: number, d: number) {
  const mesh = new Mesh(cube, material);
  mesh.position.set(x, y, z);
  mesh.scale.set(w, h, d);
  mesh.castShadow = mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function grain(x: number, z: number): number {
  const n = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
  return n - Math.floor(n);
}

function noise(x: number, z: number): number {
  const ix = Math.floor(x), iz = Math.floor(z);
  let tx = x - ix, tz = z - iz;
  tx *= tx * (3 - 2 * tx);
  tz *= tz * (3 - 2 * tz);
  const row = (j: number) => grain(ix, j) * (1 - tx) + grain(ix + 1, j) * tx;
  return row(iz) * (1 - tz) + row(iz + 1) * tz;
}

function sidingFinish(): MeshStandardMaterial {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 256;
  const ctx = canvas.getContext("2d")!;
  for (let i = 0; i < 8; i++) {
    const v = 85 + Math.round(grain(i, 8) * 5), y = i * 32;
    const wash = ctx.createLinearGradient(0, y, 0, y + 32);
    wash.addColorStop(0, `rgb(${v - 6}, ${v + 10}, ${v + 1})`);
    wash.addColorStop(0.90, `rgb(${v + 4}, ${v + 22}, ${v + 13})`);
    wash.addColorStop(1, `rgb(${v - 10}, ${v + 7}, ${v})`);
    ctx.fillStyle = wash;
    ctx.fillRect(0, y, 256, 32);
    for (let j = 0; j < 36; j++) {
      ctx.fillStyle = j % 2 ? "rgba(211,200,161,0.07)" : "rgba(26,36,31,0.09)";
      ctx.fillRect(grain(i + 1, j) * 254, y + grain(j, i + 5) * 30, 6 + grain(i, j) * 23, 0.83);
    }
  }
  const map = new CanvasTexture(canvas);
  map.colorSpace = SRGBColorSpace;
  map.wrapS = map.wrapT = RepeatWrapping;
  map.repeat.set(0.72, 0.84);
  return new MeshStandardMaterial({ map, roughness: 0.79, bumpMap: map, bumpScale: 0.012 });
}

function windowFinish(base: MeshStandardMaterial): MeshStandardMaterial {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 192;
  const ctx = canvas.getContext("2d")!;
  const img = ctx.createImageData(192, 192);
  for (let y = 0; y < 192; y++) for (let x = 0; x < 192; x++) {
    const u = x / 191, v = y / 191;
    const edge = Math.min(u, 1 - u, v * 1.2, (1 - v) * 0.81);
    const frost = Math.exp(-edge * (24 + 18 * noise(u * 14, v * 13)));
    const reflection = Math.exp(-(((u + 0.39 * v - 0.79) / 0.21) ** 2));
    const k = 64 + 46 * (1 - v) + 28 * reflection + frost * (42 + 63 * grain(x, y));
    const offset = (y * 192 + x) * 4;
    img.data[offset] = img.data[offset + 1] = img.data[offset + 2] = k;
    img.data[offset + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  const alpha = new CanvasTexture(canvas);
  alpha.wrapS = RepeatWrapping;
  const pane = base.clone();
  pane.alphaMap = alpha;
  pane.color.set("#b6d1d4");
  pane.emissive.set("#7999a0");
  pane.emissiveIntensity = 0.13;
  pane.roughness = 0.20;
  pane.opacity = 0.68;
  // Keep glass reflections when a pane has only sky behind it in the depth pass.
  pane.depthWrite = true;
  return pane;
}

const inset = {
  left: UPPER_FLOOR.minX - 0.09, right: UPPER_FLOOR.maxX + 0.15,
  front: UPPER_FLOOR.frontZ - 0.90, back: UPPER_FLOOR.backZ + 0.14,
};

export const upperRoofOpening = inset;

function makeWall(parent: Group, x: number, z: number, turn: number, width: number): Group {
  const wall = new Group();
  wall.position.set(x, 0, z);
  wall.rotation.y = turn;
  wall.name = width > 4 ? "reading-hall-window-wall" : "reading-hall-return";
  parent.add(wall);
  return wall;
}

export function buildWinterRoof(roof: Group, upperWalls: Group, options: RoofOptions): void {
  const { cx, cz, eaveY, width, run, rise, slate, glass, shade } = options;
  const { left, right, front, back } = inset;
  const roofLeft = cx - width / 2, roofRight = cx + width / 2;
  const baseAt = (z: number) => eaveY + rise * (1 - Math.abs(z - cz) / run);
  const pitch = Math.atan2(rise, run);
  const apron = matte("#57645f", 0.56, 0.45);
  const trim = matte("#354941", 0.57, 0.16);
  const oak = matte("#ad8561", 0.57);
  const lining = matte("#c1b69f", 0.83);
  const painted = matte("#68796f", 0.72);
  const siding = sidingFinish();
  const zinc = matte("#536b66", 0.59, 0.40);
  const rib = matte("#71837b", 0.55, 0.45);
  const copper = matte("#926e52", 0.57, 0.48);
  const across = right - left, length = back - front;
  const midX = (left + right) / 2, midZ = (front + back) / 2;
  const upperEave = UPPER_FLOOR.level + 2.48, upperRidge = upperEave + 1.03;
  const upperSlope = (upperRidge - upperEave) / (across / 2);

  const lowerSnow: Field = (x, z) => {
    const s = (z - cz) / run;
    const eddy = noise(x * 0.52 + z * 0.17 + 4.1, z * 0.88 - x * 0.24 + 1.8);
    const ridges = noise(x * 1.48 + z * 0.43, z * 2.12 + 3.4);
    const shelteredEave = Math.exp(-(((1 - Math.abs(s)) / 0.15) ** 2));
    const lee = Math.exp(-(((z - cz + 0.38 - 0.6 * eddy) / 0.67) ** 2));
    const ventMelt = Math.exp(-(((x-cx+2.4)/.44)**2 + ((z-cz+.85)/.53)**2));
    return -.34*ventMelt + (eddy - 0.49) * 0.70 + (snowNoise(x * .69 - z * .28, z * 2.55 + x * .88) - .5) * .21 + (ridges - 0.5) * 0.29 + (noise(x * 4.4, z * 4.7) - 0.5) * 0.10
      + s * 0.10 + shelteredEave * (0.12 + 0.18 * eddy) + lee * 0.18 - 0.025;
  };
  const lowerHeight: Field = (_x, z) => baseAt(z) + 0.032
    + 0.028 * Math.max(0, 1 - Math.abs(z - cz) / 0.12);
  function deck(x0: number, x1: number, z0: number, z1: number) {
    if (x1 - x0 < 0.001 || z1 - z0 < 0.001) return;
    const depth = z1 - z0;
    const geo = new BoxGeometry(x1 - x0, 0.055, depth / Math.cos(pitch));
    const uv = geo.attributes.uv;
    for (let i = 0; i < uv.count; i++) {
      if (Math.abs(geo.attributes.normal.getY(i)) < 0.99) continue;
      uv.setXY(i, (x0 - roofLeft + uv.getX(i) * (x1 - x0)) / width, (cz + run - z1 + uv.getY(i) * depth) / run);
    }
    const z = (z0 + z1) / 2;
    const mesh = new Mesh(geo, slate);
    mesh.position.set((x0 + x1) / 2, baseAt(z), z);
    mesh.rotation.x = Math.sign(z - cz) * pitch;
    mesh.castShadow = mesh.receiveShadow = true;
    roof.add(mesh);
    laySnow(roof, { left: x0, right: x1, front: z0, back: z1 }, lowerHeight, lowerSnow, 0.19,
      { left: roofLeft, right: roofRight, front: cz - run, back: cz + run });
  }
  // The raised reading room straddles the old ridge. Cut both pitches rather
  // than leaving a sheet of slate at head height above the upper stair treads.
  for (const [nearZ, farZ] of [[cz - run, cz], [cz, cz + run]]) {
    deck(roofLeft, left, nearZ, farZ);
    deck(right, roofRight, nearZ, farZ);
    deck(left, right, nearZ, Math.min(farZ, front));
    deck(left, right, Math.max(nearZ, back), farZ);
  }

  // The rear wall stays with the model when its roof is lifted. Its last bay
  // returns around the corner. The other high faces lift away on the cut side.
  const clearGlass = windowFinish(glass);
  const windowHead = upperEave - 0.18;
  function wallWindows(wall: Group, width: number, bottomL: number, bottomR: number, bays: number, blinds: boolean) {
    const sill = Math.max(UPPER_FLOOR.level + 0.91, Math.max(bottomL, bottomR) + 0.18);
    const h = windowHead - sill;
    const sash = width / bays;
    const profile = new Shape();
    profile.moveTo(-width / 2, bottomL);
    profile.lineTo(width / 2, bottomR);
    profile.lineTo(width / 2, sill);
    profile.lineTo(-width / 2, sill);
    profile.closePath();
    const skirt = new Mesh(new ExtrudeGeometry(profile, { depth: 0.112, bevelEnabled: false }), painted);
    skirt.position.z = -0.056;
    skirt.castShadow = skirt.receiveShadow = true;
    wall.add(skirt);
    box(wall, oak, 0, sill + 0.009, 0, width + 0.025, 0.075, 0.203);
    box(wall, trim, 0, upperEave - 0.081, 0, width + 0.02, 0.167, 0.14);
    box(wall, oak, 0, windowHead - 0.018, 0, width, 0.043, 0.143);
    const paneGeometry = new PlaneGeometry(width - 0.045, h);
    const uv = paneGeometry.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setX(i, uv.getX(i) * bays);
    const pane = new Mesh(paneGeometry, clearGlass);
    pane.position.y = (windowHead + sill) / 2;
    wall.add(pane);
    for (let i = 0; i <= bays; i++) {
      const px = -width / 2 + i * sash;
      box(wall, trim, px, (windowHead + sill) / 2, 0, 0.066, h, 0.116);
      if (i === bays) break;
      const center = px + sash / 2;
      box(wall, oak, center, (windowHead + sill) / 2, 0, 0.028, h, 0.053);
      if (blinds) {
        const drop = i % 3 === 1 ? 0.33 : 0.17;
        box(wall, shade, center, windowHead - drop / 2 - 0.04, 0.077, sash - 0.105, drop, 0.017);
        box(wall, lining, center, windowHead - drop - 0.04, 0.077, sash - 0.105, 0.014, 0.023);
      }
    }
    box(wall, trim, 0, windowHead - h * 0.25, 0, width, 0.030, 0.074);
  }
  wallWindows(makeWall(upperWalls, midX, back, 0, across), across, eaveY - 0.095, eaveY - 0.095, 4, false);
  wallWindows(makeWall(roof, midX, front, 0, across), across, baseAt(front) - 0.04, baseAt(front) - 0.04, 4, true);
  // Split side strips at the main ridge so their lower edge follows the slate.
  const returnZ = back - 1.30;
  for (const x of [left, right]) {
    for (const [z1, z2] of [[front, cz], [cz, returnZ], [returnZ, back]]) {
      const fixed = x === right && z1 === returnZ;
      const wall = makeWall(fixed ? upperWalls : roof, x, (z1 + z2) / 2, -Math.PI / 2, z2 - z1);
      const baseL = x === right ? eaveY - 0.10 : baseAt(z1) - 0.035;
      const baseR = x === right ? eaveY - 0.10 : baseAt(z2) - 0.035;
      wallWindows(wall, z2 - z1, baseL, baseR, Math.max(1, Math.round((z2 - z1) / 1.2)), false);
    }
  }
  for (const z of [front, back]) {
    const shape = new Shape();
    shape.moveTo(-across / 2, 0);
    shape.lineTo(across / 2, 0);
    shape.lineTo(0, upperRidge - upperEave);
    shape.closePath();
    const panel = new Mesh(new ExtrudeGeometry(shape, { depth: 0.09, bevelEnabled: false }), siding);
    panel.position.set(midX, upperEave - 0.012, z - 0.045);
    panel.castShadow = panel.receiveShadow = true;
    roof.add(panel);
    // A little screened ridge vent breaks the field of painted gable siding.
    for (let i = 0; i < 4; i++) {
      box(roof, trim, midX, upperEave + 0.35 + i * 0.061, z, 0.49 - i * 0.034, 0.026, 0.13);
    }
    box(roof, apron, midX, baseAt(z) + 0.040, z, across + 0.10, 0.047, 0.26);
  }
  for (const x of [left, right]) {
    for (const [z1, z2] of [[front, cz], [cz, back]]) {
      const z = (z1 + z2) / 2;
      const strip = box(roof, apron, x, baseAt(z) + 0.036, z, 0.23, 0.05, (z2 - z1) / Math.cos(pitch));
      strip.rotation.x = Math.sign(z - cz) * pitch;
    }
  }

  // Folded standing-seam zinc and a timber soffit read differently from the
  // slate downstairs. The seams run down both slopes into half-round gutters.
  const slopeAngle = Math.atan(upperSlope);
  const overhang = 0.18, upperRun = across / 2 + overhang, upperLength = length + overhang * 2;
  const upperHeight: Field = (x) => upperRidge - Math.abs(x - midX) * upperSlope + 0.064
    + 0.038 * Math.max(0, 1 - Math.abs(x - midX) / 0.13);
  const highSnow: Field = (x, z) => {
    const u = x + 0.33 * noise(x * 1.02 + z * 0.31, z * 1.38);
    const v = z + 0.29 * noise(x * 0.92, z * 1.07 + 4.2);
    const wind = noise(u * 0.74 + v * 0.26 + 5.1, v * 0.75 - u * 0.26 + 2.4);
    return (wind - 0.46) * 0.72 + (snowNoise(u * .83, v * 3.4 - u * .65) - .5) * .19 + (noise(u * 1.51 + v * 0.45, v * 1.95 - u * 0.52) - 0.5) * 0.27
      + (noise(u * 3.3 - v * 0.9, v * 3.7 + u * 0.8) - 0.5) * 0.08 + (midX - x) * 0.035;
  };
  for (const side of [-1, 1]) {
    const panelX = midX + side * upperRun / 2;
    const panelY = upperRidge - upperRun * upperSlope / 2;
    const sheet = box(roof, zinc, panelX, panelY, midZ, upperRun / Math.cos(slopeAngle), 0.095, upperLength);
    sheet.rotation.z = -side * slopeAngle;
    const fasciaX = midX + side * upperRun, fasciaY = upperRidge - upperRun * upperSlope;
    box(roof, trim, fasciaX, fasciaY - 0.026, midZ, 0.072, 0.137, upperLength);
    const gutter = new Mesh(new CylinderGeometry(0.055, 0.055, upperLength + 0.05, 12, 1, false), rib);
    gutter.position.set(fasciaX + side * 0.044, fasciaY - 0.079, midZ);
    gutter.rotation.x = Math.PI / 2;
    roof.add(gutter);
    const seams = Math.ceil(upperLength / 0.51);
    for (let i = 0; i <= seams; i++) {
      const z = midZ - upperLength / 2 + i * upperLength / seams;
      const joint = box(roof, rib, panelX, panelY + 0.052, z, upperRun / Math.cos(slopeAngle), 0.033, 0.030);
      joint.rotation.z = sheet.rotation.z;
    }
    laySnow(roof, {
      left: Math.min(fasciaX, midX), right: Math.max(fasciaX, midX),
      front: midZ - upperLength / 2, back: midZ + upperLength / 2,
    }, upperHeight, highSnow, 0.145, {
      left: midX - upperRun, right: midX + upperRun, front: midZ - upperLength / 2, back: midZ + upperLength / 2,
    });
  }
  box(roof, copper, midX, upperRidge + 0.060, midZ, 0.11, 0.046, upperLength + 0.04);
}
