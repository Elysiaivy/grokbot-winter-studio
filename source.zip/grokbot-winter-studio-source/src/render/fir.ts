import { BufferGeometry, CanvasTexture, Color, DoubleSide, Float32BufferAttribute, MeshStandardMaterial, SRGBColorSpace } from "three";

function needleTexture(): CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 96;
  canvas.height = 128;
  const ctx = canvas.getContext("2d")!;
  ctx.lineCap = "round";
  const draw = (x: number, y: number, endX: number, endY: number, width: number, color: string) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(endX, endY);
    ctx.stroke();
  };
  draw(49, 128, 47, 3, 5.3, "#a8b49e");
  for (let i = 0; i < 42; i++) {
    const t = i / 42;
    for (const side of [-1, 1]) {
      const length = (9 + 38 * Math.sin(Math.PI * (0.15 + t * 0.81))) * (0.82 + 0.16 * Math.cos(i * 4.17 + side));
      const y = 131 - t * 118 + side * 1.2;
      const shade = Math.round(207 + 35 * Math.sin(i * 2.79 + side));
      draw(48 + side * 1.2, y, 48 + side * length, y - length * 0.64, 2.8, `rgb(${shade},${shade + 4},${shade - 4})`);
    }
  }
  const map = new CanvasTexture(canvas);
  map.colorSpace = SRGBColorSpace;
  return map;
}

export const firNeedles = new MeshStandardMaterial({
  map: needleTexture(), alphaTest: 0.28, vertexColors: true, roughness: 0.93, side: DoubleSide,
});

/** Layered, flattened sprays break up the solid silhouette beneath the lights. */
export function makeFirBoughs(radius: number, height: number, tier: number, twigRows = 7): BufferGeometry {
  const positions: number[] = [], colors: number[] = [], indices: number[] = [], uvs: number[] = [];
  const shade = new Color("#213e34"), tips = new Color("#658361"), tint = new Color();
  const count = Math.round(18 + 23 * radius);
  for (let b = 0; b < count; b++) {
    const angle = (b + 0.21 * Math.sin(b * 7.13) + tier * 0.61) * Math.PI * 2 / count;
    const c = Math.cos(angle), s = Math.sin(angle);
    const reach = radius * (0.99 + 0.068 * Math.sin(angle * 5 + tier) + 0.043 * Math.cos(13 * b + tier));
    const breadth = 3.95 * reach / count;
    const sag = height * (0.044 + 0.047 * Math.sin(b * 4.39 + tier));
    function vertex(r: number, side: number, y: number, light: number) {
      positions.push(c * r - s * side, y, s * r + c * side);
      tint.copy(shade).lerp(tips, light);
      colors.push(tint.r, tint.g, tint.b);
    }
    // Each lateral twig has a raised midrib and fine, tapered needle tips.
    for (let j = 0; j < twigRows; j++) {
      const t = j / twigRows;
      const stem = reach * (0.28 + 0.67 * t);
      const y = height * (0.74 - 0.69 * t) + sag * t;
      const length = reach * (0.24 - t * 0.12);
      for (const side of [-1, 1]) {
        const spread = side * breadth * (0.65 + 0.47 * Math.sin(t * Math.PI) - 0.35 * t);
        const i = positions.length / 3;
        const light = 0.35 + 0.18 * Math.cos(b * 2.7 + j * 1.32);
        vertex(stem, side * breadth * 0.025, y, light * 0.55);
        vertex(stem + length * 0.53, spread * 0.95, y - height * 0.125, light);
        vertex(stem + length * 0.71, spread * 0.52, y - height * 0.11, light + 0.10);
        vertex(stem + length, spread * 1.16, y - height * 0.185, light + 0.22);
        vertex(stem + length * 1.12, spread * 0.67, y - height * 0.20, light + 0.16);
        uvs.push(0.5, 0, 0.02, 0.45, 0.95, 0.52, 0.10, 0.91, 0.54, 1);
        indices.push(i, i + 1, i + 2, i + 2, i + 1, i + 3, i + 2, i + 3, i + 4);
      }
    }
  }
  const geo = new BufferGeometry();
  geo.setAttribute("position", new Float32BufferAttribute(positions, 3));
  geo.setAttribute("color", new Float32BufferAttribute(colors, 3));
  geo.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}
