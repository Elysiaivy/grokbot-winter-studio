import { BufferGeometry, CanvasTexture, Color, Float32BufferAttribute, Group, Mesh, MeshStandardMaterial, SRGBColorSpace, Vector3, CatmullRomCurve3 } from "three";
import { batch, beam, box, cyl, group, paint, randomStream, rock } from "./townCraft";

import { snowNoise, snowOnRock, winterBough } from "./snowCover";

export const LAND = { left: -20, right: 22.5, front: -13.6, back: 13.6 };
const { left, right, front, back } = LAND;
export const SEA = -0.91;

export function shoreline(z: number) { return 15.35 + 0.9 * Math.cos(0.42 * z) - 0.012 * z * z + 0.4 * Math.sin(z * 1.03); }
const clamp = (x: number) => Math.max(0, Math.min(1, x));
const smooth = (x: number) => { const t = clamp(x); return t * t * (3 - 2 * t); };

export function heightAt(x: number, z: number) {
  const hill = smooth((-x - 7.9) / 10);
  const shore = smooth((x - 8.2) / 7);
  const outside = smooth(Math.max(-8.2 - x, x - 8.2, z - 6.45, -10.25 - z) / 1.8);
  return -0.185 + hill * (1.9 + 0.17 * Math.sin(z * 0.53)) - shore * 0.42
    + outside * (0.09 * Math.sin(z * 0.91 + x * 0.23) + 0.055 * Math.cos(x * 1.4 - z * 0.54))
    + smooth((z - 5.6) / 6) * 0.36 - 1.2 * smooth((x - shoreline(z) + 0.08) / 0.9);
}
type Knot = [
  number,
  number
];
const lanes: {
  width: number;
  trail?: boolean;
  knots: Knot[];
}[] = [
  { width: 3.75, knots: [[5.8, -8.25], [8.3, -8.25], [10.4, -7.45], [12.2, -6.0], [13.35, -4.25], [14, -2.9]] },
  { width: 2.0, knots: [[13.3, -5.1], [12.25, -4.8], [10.7, -5.05], [9.1, -5.45], [8, -5.45]] },
  { width: 1.55, knots: [[13.7, -4.25], [14.1, -2.75], [13.3, -1.4], [12, -0.3], [11.65, 1.45], [12.0, 3.9], [13.4, 4.3], [15.5, 4.25]] },
  { width: 3.6, knots: [[-6.8, -8.3], [-8.25, -8.3], [-10, -7.6], [-11.1, -6.1], [-12.4, -5.0], [-14.1, -4.9]] },
  { width: 1.4, knots: [[-13.3, -5.0], [-14.45, -3.7], [-14.8, -1.6], [-15.05, 0.3], [-14.4, 2.25], [-14.3, 3.3], [-15, 4.8]] },
  { width: 1.1, trail: true, knots: [[-15, 4.8], [-14.6, 6.1], [-12.3, 7.8], [-9.4, 9.4], [-6.7, 8.3], [-2.8, 8.5], [1, 9.7], [4.5, 9.3], [7.4, 7.55], [9.4, 5.8], [11.9, 4.0]] }
];

// Signed distances are sampled once, not per pixel or per animation frame.
function snowpack() {
  const scale = 6, cols = Math.ceil((right - left) * scale) + 1, rows = Math.ceil((back - front) * scale) + 1;
  const streets = new Float32Array(cols * rows).fill(8), trails = new Float32Array(cols * rows).fill(8);
  function mark(x: number, z: number, width: number, field: Float32Array) {
    const ix = (x - left) * scale, iz = (z - front) * scale, reach = (width * .5 + 1.5) * scale;
    for (let j = Math.max(0, Math.floor(iz - reach)); j <= Math.min(rows - 1, Math.ceil(iz + reach)); j++) {
      for (let i = Math.max(0, Math.floor(ix - reach)); i <= Math.min(cols - 1, Math.ceil(ix + reach)); i++) {
        const k = i + j * cols, dist = Math.hypot(i - ix, j - iz) / scale - width * .5;
        if (dist < field[k])
          field[k] = dist;
      }
    }
  }
  for (const lane of lanes) {
    const curve = new CatmullRomCurve3(lane.knots.map(([x, z]) => new Vector3(x, 0, z)));
    for (const p of curve.getSpacedPoints(Math.ceil(curve.getLength() * 9)))
      mark(p.x, p.z, lane.width, lane.trail ? trails : streets);
  }
  for (let x = -8.3; x <= 8.31; x += .115)
    mark(x, -8.18, 4.16, streets);
  const thickness = new Float32Array(cols * rows), cover = new Float32Array(cols * rows), dirt = new Float32Array(cols * rows);
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < cols; i++) {
      const k = i + j * cols, x = left + i / scale, z = front + j / scale;
      const basin = snowNoise(x * .31 + 6, z * .48 - 2);
      const wind = snowNoise(x * .83 - z * .28, z * 2.10 + x * .58);
      const streak = snowNoise(x * .51, z * 4 + x * .76);
      const street = streets[k] + (basin - .5) * .49 + (wind - .5) * .29;
      const softTrail = smooth((trails[k] + .34) / .79);
      const dryBank = Math.exp(-((street - .26 - (basin - .5) * .34) ** 2) / .14);
      const dryShore = smooth((shoreline(z) - x + .15 + (wind - .5) * .86 + (basin - .5) * .76) / .91);
      const traffic = smooth((street + .30) / .68);
      const frame = smooth(Math.max(Math.abs(x) - 8.31, z - 6.48, -10.27 - z) / .58);
      const dep = (.046 + .136 * basin + (wind - .5) * .089 + .041 * streak) * softTrail;
      thickness[k] = dryShore * frame * (traffic * (.018 + dep) + dryBank * (.065 + .11 * basin));
      cover[k] = dryShore * smooth((street + .24 + (streak - .5) * .34) / .48);
      dirt[k] = clamp(dryBank * (.35 + wind * .45) + (1 - softTrail) * .62 + (1 - dryShore) * .64);
    }
  function sample(field: Float32Array, x: number, z: number) {
    const gx = Math.max(0, Math.min(cols - 1.001, (x - left) * scale));
    const gz = Math.max(0, Math.min(rows - 1.001, (z - front) * scale));
    const i = Math.floor(gx), j = Math.floor(gz), u = gx - i, v = gz - j, k = i + cols * j;
    return (field[k] * (1 - u) + field[k + 1] * u) * (1 - v) + (field[k + cols] * (1 - u) + field[k + cols + 1] * u) * v;
  }
  return { cols, rows, scale, thickness, cover, dirt, depth: (x: number, z: number) => sample(thickness, x, z) };
}
type Snowpack = ReturnType<typeof snowpack>;

function groundSurface(pack: Snowpack) {
  const c = document.createElement("canvas"), r = document.createElement("canvas");
  c.width = r.width = 1700;
  c.height = r.height = 1088;
  const g = c.getContext("2d", { willReadFrequently: true })!, rg = r.getContext("2d")!;
  const unit = c.width / (right - left);
  const rand = randomStream(912);
  g.fillStyle = "#787b79";
  g.fillRect(0, 0, c.width, c.height);
  g.setTransform(unit, 0, 0, unit, -left * unit, -front * unit);
  const path = (points: Vector3[]) => { g.beginPath(); points.forEach((p, i) => i ? g.lineTo(p.x, p.z) : g.moveTo(p.x, p.z)); };
  const stoneLanes = lanes.filter(l => !l.trail);
  for (const [color, scale] of [["#c4cfd5", 1.07], ["#99a5ab", 1.025], ["#495966", .99]] as const) {
    for (const l of stoneLanes) {
      const curve = new CatmullRomCurve3(l.knots.map(([x, z]) => new Vector3(x, 0, z)));
      g.lineCap = "round";
      path(curve.getSpacedPoints(120));
      g.strokeStyle = color;
      g.lineWidth = l.width * scale;
      g.stroke();
    }
  }
  for (const lane of lanes) {
    const curve = new CatmullRomCurve3(lane.knots.map(([x, z]) => new Vector3(x, 0, z)));
    const w = lane.width;
    if (lane.trail)
      continue;
    const rows = Math.floor(curve.getLength() / .20);
    for (let r = 0; r < rows; r++) {
      const t = (r + .5) / rows, p = curve.getPointAt(t), dir = curve.getTangentAt(t);
      g.save();
      g.translate(p.x, p.z);
      g.rotate(Math.atan2(dir.z, dir.x));
      {
        const count = Math.ceil(w / .34);
        for (let col = 0; col < count; col++) {
          const s = 72 + Math.floor(rand() * 32);
          g.fillStyle = 'rgb(' + s + ',' + (s + 10) + ',' + (s + 16) + ')';
          const side = (col + .5 + (r % 2) * .36) / count - .5;
          g.fillRect(-.092, side * w * .91 - .115, .172, .225 + rand() * .048);
        }
      }
      g.restore();
    }
  }
  // Ploughed shoulders taper into the street extensions at the two old curb cuts.
  for (const sign of [-1, 1]) {
    for (let i = 0; i < 440; i++) {
      const x = sign * (8.19 + rand() * 1.62), z = -10.28 + rand() * 4.18;
      if (Math.abs(x) > 8.4 && (z > -6.75 || z < -9.58))
        continue;
      const tone = 57 + rand() * 32;
      g.fillStyle = 'rgba(' + tone + ',' + (tone + 11) + ',' + (tone + 20) + ',' + (.32 * (1 - (Math.abs(x) - 8.19) / 1.62)) + ')';
      g.fillRect(x, z, .14 + rand() * .28, .064);
    }
  }
  // Paint and height share the same accumulation. Fine relief survives a close
  // camera, while the larger lee-side banks read in the overview.
  const img = g.getImageData(0, 0, c.width, c.height), relief = rg.createImageData(c.width, c.height);
  for (let j = 0; j < c.height; j++) {
    const z = front + j / unit, gz = (z - front) * pack.scale, j0 = Math.floor(gz), v = gz - j0;
    for (let i = 0; i < c.width; i++) {
      const x = left + i / unit, gx = (x - left) * pack.scale, i0 = Math.floor(gx), u = gx - i0, k = i0 + j0 * pack.cols;
      const a = (1 - u) * (1 - v), b = u * (1 - v), d = (1 - u) * v, e = u * v, k2 = k + pack.cols;
      const field = (f: Float32Array) => a * f[k] + b * f[k + 1] + d * f[k2] + e * f[k2 + 1];
      const micro = snowNoise(x * 8 + z * 1.3, z * 17 - x * 4);
      const broad = snowNoise(x * .65 + z * .24, z * 1.55 - x * .42);
      const granule = rand(), depth = field(pack.thickness), dirt = field(pack.dirt);
      const cover = clamp((field(pack.cover) - .5) * 1.43 + .50 + (micro - .5) * .45);
      const ripple = Math.max(0, 1 - Math.abs(broad - .51) * 4.4);
      const light = 193 + depth * 76 + (broad - .5) * 22 + (micro - .5) * 12 + (granule - .5) * 7 + ripple * ripple * 5;
      const dust = dirt * (.59 + .41 * micro);
      const offset = (i + j * c.width) * 4;
      const shoreGrain = (micro - .5) * 28 + (broad - .5) * 19 + (granule - .5) * 16;
      const base = img.data[offset] === 120 && img.data[offset + 1] === 123 ? shoreGrain : 0;
      img.data[offset] = (img.data[offset] + base) * (1 - cover) + (light - 18 * dust) * cover;
      img.data[offset + 1] = (img.data[offset + 1] + base) * (1 - cover) + (light + 11 - 24 * dust) * cover;
      img.data[offset + 2] = (img.data[offset + 2] + base) * (1 - cover) + (light + 19 - 31 * dust) * cover;
      const h = 38 + depth * 180 + micro * 35 + granule * 15 + broad * 41 + ripple * ripple * 21;
      relief.data[offset] = cover * h + (1 - cover) * (42 + img.data[offset] * .45);
      relief.data[offset + 1] = (1 - cover) * 134 + cover * (233 - dust * 49 + (granule - .5) * 12);
      relief.data[offset + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
  rg.putImageData(relief, 0, 0);
  rg.setTransform(unit, 0, 0, unit, -left * unit, -front * unit);
  // Paired heel and toe catch light on one side of the depression. Vary
  // the gait with the turn so the trail doesn't read like a dotted line.
  const trail = lanes.find(l => l.trail)!;
  const curve = new CatmullRomCurve3(trail.knots.map(([x, z]) => new Vector3(x, 0, z)));
  const length = curve.getLength();
  let step = 0;
  for (let travel = .16; travel < length; travel += .32 + rand() * .14, step++) {
    const t = travel / length, pos = curve.getPointAt(t), dir = curve.getTangentAt(t);
    const lateral = (step % 2 ? .116 : -.116) + .055 * Math.sin(travel * 1.4) + (rand() - .5) * .07;
    const angle = Math.atan2(dir.z, dir.x) + (step % 2 ? .12 : -.13) + (rand() - .5) * .13;
    for (const ctx of [g, rg]) {
      const height = ctx === rg;
      ctx.save();
      ctx.translate(pos.x - dir.z * lateral, pos.z + dir.x * lateral);
      ctx.rotate(angle);
      const sole = (x: number, y: number, w: number, h: number) => { ctx.beginPath(); ctx.ellipse(x, y, w, h, 0, 0, Math.PI * 2); ctx.fill(); };
      ctx.fillStyle = height ? "rgb(182,213,0)" : "rgba(235,241,239,.69)";
      sole(.026, .012, .080, .049);
      sole(-.073, .011, .036, .041);
      ctx.fillStyle = height ? "rgb(58,174,0)" : "rgba(113,137,150,.62)";
      sole(.022, -.002, .078, .045);
      sole(-.078, -.003, .036, .036);
      ctx.restore();
    }
  }
  const t = new CanvasTexture(c), finish = new CanvasTexture(r);
  t.colorSpace = SRGBColorSpace;
  t.anisotropy = finish.anisotropy = 4;
  return new MeshStandardMaterial({ map: t, bumpMap: finish, bumpScale: .055, roughnessMap: finish, roughness: 1, envMapIntensity: .42 });
}

function terrainGeometry(pack: Snowpack) {
  const nx = 189, nz = 122, p: number[] = [], uv: number[] = [], ix: number[] = [];
  for (let j = 0; j <= nz; j++)
    for (let i = 0; i <= nx; i++) {
      const x = left + (right - left) * i / nx, z = front + (back - front) * j / nz;
      p.push(x, heightAt(x, z) + pack.depth(x,z), z);
      uv.push(i / nx, 1 - j / nz);
      if (i < nx && j < nz) {
        const a = j * (nx + 1) + i;
        ix.push(a, a + nx + 1, a + 1, a + 1, a + nx + 1, a + nx + 2);
      }
    }
  const g = new BufferGeometry();
  g.setIndex(ix);
  g.setAttribute("position", new Float32BufferAttribute(p, 3));
  g.setAttribute("uv", new Float32BufferAttribute(uv, 2));
  g.computeVertexNormals();
  return g;
}

function skirt(root: Group, pack: Snowpack) {
  const outline: Knot[] = [];
  for (let i = 0; i < 100; i++)
    outline.push([left + (right - left) * i / 100, front]);
  for (let i = 0; i < 70; i++)
    outline.push([right, front + (back - front) * i / 70]);
  for (let i = 0; i < 100; i++)
    outline.push([right - (right - left) * i / 100, back]);
  for (let i = 0; i < 70; i++)
    outline.push([left, back - (back - front) * i / 70]);
  const p: number[] = [], colors: number[] = [];
  for (let i = 0; i < outline.length; i++) {
    const [ax, az] = outline[i], [bx, bz] = outline[(i + 1) % outline.length];
    const ya = Math.max(SEA - .005, heightAt(ax, az)+pack.depth(ax,az)), yb = Math.max(SEA - .005, heightAt(bx, bz)+pack.depth(bx,bz));
    p.push(ax, -1.99, az, ax, ya, az, bx, yb, bz, ax, -1.99, az, bx, yb, bz, bx, -1.99, bz);
    for (const v of [0, 1, 1, 0, 1, 0]) {
      const color = new Color(v ? (ax >= shoreline(az) ? "#32535d" : "#87939b") : "#55606a");
      colors.push(color.r, color.g, color.b);
    }
  }
  const g = new BufferGeometry();
  g.setAttribute("position", new Float32BufferAttribute(p, 3));
  g.setAttribute("color", new Float32BufferAttribute(colors, 3));
  g.computeVertexNormals();
  const mesh = new Mesh(g, new MeshStandardMaterial({ vertexColors: true, roughness: .93 }));
  root.add(mesh);
  box(root, paint("#3b414b"), 1.25, -2.06, 0, 42.72, .17, 27.42);
  box(root, paint("#ac9270"), 1.25, -2.165, 0, 42.6, .045, 27.32);
  box(root, paint("#283945"), 1.25, -2.26, 0, 42.85, .16, 27.5);
}
// Each tree reuses the tier meshes; the town's static batching bakes their transforms.
const forestTiers=Array.from({length:7},(_,layer)=>winterBough(.29*(1-layer/8.1),.25-layer*.009,layer*1.39));
function fir(root: Group, x: number, z: number, h: number) {
  const y = heightAt(x, z);
  cyl(root, paint("#62574c"), x, y + h * .22, z, h * .051, h * .46);
  const tree = group(root, x, y, z);
  tree.scale.setScalar(h);
  tree.rotation.y = x * 2.17;
  forestTiers.forEach((tier, layer) => {
    const bough = tier.clone();
    bough.position.y = .20 + layer * .103;
    tree.add(bough);
  });
}

export function buildLand(root: Group) {
  const land = group(root);
  const pack = snowpack();
  const terrain = new Mesh(terrainGeometry(pack), groundSurface(pack));
  terrain.receiveShadow = true;
  land.add(terrain);
  skirt(land, pack);
  const rand = randomStream(1504);
  for (const [cx, cz, n] of [[-17, 9.7, 9], [-7, 11.6, 9], [4.4, 11.2, 6], [-17.8, -9.7, 6], [10.7, 9.6, 4], [-18, 3, 3]]) {
    for (let i = 0; i < n; i++) {
      const x = cx + (rand() - .5) * 4, z = cz + (rand() - .5) * 2.5;
      fir(land, x, z, 1.45 + rand() * 2.3);
    }
  }
  for (const [x, z] of [[-12.4, 7.05], [-10.6, 9.8], [-5.9, 7.5], [.4, 10.8], [7.2, 8.6], [-17.3, -4.2], [9.1, 2.3], [-9.8, -3.7]]) {
    const b = group(land, x, heightAt(x, z), z), white = paint("#dacfc2");
    beam(b, white, [0, 0, 0], [.08, 2.3, .04], .095);
    for (let i = 0; i < 8; i++) {
      const y = .77 + i * .17, a = i * 2.4;
      const dx = Math.cos(a), dz = Math.sin(a);
      beam(b, white, [.05, y, 0], [dx * .54, y + .57, dz * .54], .045);
      beam(b, paint("#716b66"), [dx * .54, y + .57, dz * .54], [dx * .75, y + 1, dz * .75], .025);
      box(b, paint("#807973"), .015, y, .052, .073, .031, .02);
    }
  }
  for (const [cx, cz, n] of [[-9.8, 10.35, 10], [3, 12, 7], [10.6, 7.5, 5], [-18.8, -2.7, 6], [13, -7.9, 5]]) {
    for (let i = 0; i < n; i++) {
      const x = cx + (rand() - .5) * 3, z = cz + (rand() - .5) * 1.8, w = .5 + rand() * 1.05, y = heightAt(x, z);
      const stone = rock(land, paint("#78838b"), x, y + .10, z, w, .23 + w * .21, w * .77);
      snowOnRock(stone, x * 2 + z);
    }
  }
  batch(land);
}
