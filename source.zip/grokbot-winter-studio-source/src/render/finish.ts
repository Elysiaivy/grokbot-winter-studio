import {
  Color, DepthTexture, HalfFloatType, Mesh, OrthographicCamera, PerspectiveCamera, PlaneGeometry, Scene,
  ShaderMaterial, UnsignedByteType, UnsignedIntType, Vector2, WebGLRenderTarget, type WebGLRenderer,
} from "three";

export function createFinish(renderer: WebGLRenderer, camera: OrthographicCamera) {
  const target = new WebGLRenderTarget(1, 1, {
    type: renderer.extensions.has("EXT_color_buffer_float") ? HalfFloatType : UnsignedByteType,
    depthTexture: new DepthTexture(1, 1, UnsignedIntType),
  });
  const uniforms = {
    sceneColor: { value: target.texture },
    sceneDepth: { value: target.depthTexture },
    texel: { value: new Vector2(1, 1) },
    viewSize: { value: new Vector2() },
    nearClip: { value: camera.near },
    perspectiveMode: { value: 0 },
    depthRange: { value: camera.far - camera.near },
    backdrop: { value: new Color("#242c47") },
  };
  const material = new ShaderMaterial({
    uniforms,
    depthTest: false,
    depthWrite: false,
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      uniform sampler2D sceneColor;
      uniform sampler2D sceneDepth;
      uniform vec2 texel;
      uniform vec2 viewSize;
      uniform float depthRange;
      uniform float nearClip;
      uniform float perspectiveMode;
      uniform vec3 backdrop;
      varying vec2 vUv;

      float depthAt(vec2 point) {
        float depth = texture2D(sceneDepth, point).r;
        if (perspectiveMode < 0.5 || depth >= 1.0) return depth;
        return depth * nearClip / (nearClip + (1.0-depth)*depthRange);
      }
      float lightness(vec3 rgb) {
        return dot(rgb, vec3(0.2126, 0.7152, 0.0722));
      }
      vec3 glowAt(vec2 point) {
        vec3 color = texture2D(sceneColor, point).rgb;
        return min(color * smoothstep(1.18, 2.8, max(color.r, max(color.g, color.b))), vec3(7.0));
      }
      // Orthographic depth is linear. Measure nearby occluders in model units
      // so furniture feet and wall junctions keep their scale as the camera zooms.
      float contact(vec2 sampleOffset, vec3 normal, float depth, float reach) {
        vec2 localSize = viewSize * mix(1.0, nearClip + depth * depthRange, perspectiveMode);
        float sampleDepth = depthAt(vUv + sampleOffset / localSize);
        vec3 delta = vec3(sampleOffset, (depth - sampleDepth) * depthRange);
        float distanceToSample = max(length(delta), 0.001);
        float aboveSurface = max(dot(normal, delta) / distanceToSample - 0.075, 0.0);
        return aboveSurface * (1.0 - smoothstep(reach * 0.28, reach, distanceToSample));
      }
      void main() {
        float depth = depthAt(vUv);
        vec3 color = texture2D(sceneColor, vUv).rgb;
        vec2 h = vec2(texel.x, 0.0);
        vec2 v = vec2(0.0, texel.y);

        vec2 localSize = viewSize * mix(1.0, nearClip + depth * depthRange, perspectiveMode);
        vec3 position = vec3((vUv - 0.5) * localSize, -depth * depthRange);
        vec3 normal = normalize(cross(dFdx(position), dFdy(position)));
        if (depth < 0.9999) {
          float occlusion = 0.0;
          for (int i = 0; i < 4; ++i) {
            float angle = 0.15 + float(i) * 1.5707963;
            vec2 axis = vec2(cos(angle), sin(angle));
            occlusion += contact(0.084 * axis, normal, depth, 0.31);
            occlusion += contact(0.195 * vec2(axis.x - axis.y, axis.x + axis.y) * 0.7071, normal, depth, 0.59);
          }
          color *= 1.0 - min(0.34, occlusion * 0.086);
        } else {
          vec2 p = (vUv - vec2(0.50, 0.60)) * vec2(clamp(texel.y / texel.x, 0.66, 2.2), 1.0);
          float vignette = smoothstep(0.08, 0.88, length(p));
          vec3 studio = backdrop * mix(1.18, 0.34, vignette);
          // The scene's transparent contact shadow remains visible on the backdrop.
          color = studio * clamp(lightness(color) / max(0.0001, lightness(backdrop)), 0.0, 1.0);
        }

        vec3 glow = glowAt(vUv + h * 3.0) + glowAt(vUv - h * 3.0)
          + glowAt(vUv + v * 3.0) + glowAt(vUv - v * 3.0);
        vec2 diagonal = (h + v) * 3.2;
        vec2 crossDiagonal = (h - v) * 3.2;
        glow += 0.35 * (glowAt(vUv + diagonal) + glowAt(vUv - diagonal)
          + glowAt(vUv + crossDiagonal) + glowAt(vUv - crossDiagonal));
        gl_FragColor = vec4(color + glow * 0.036, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });
  const screen = new Scene();
  const quad = new Mesh(new PlaneGeometry(2, 2), material);
  quad.frustumCulled = false;
  screen.add(quad);
  const screenCamera = new OrthographicCamera();
  const size = new Vector2();
  renderer.info.autoReset = false;

  return {
    backdrop: uniforms.backdrop.value,
    resize() {
      renderer.getDrawingBufferSize(size);
      target.setSize(size.x, size.y);
      uniforms.texel.value.set(1 / size.x, 1 / size.y);
    },
    setAntialias(enabled: boolean) {
      const samples = enabled ? Math.min(4, renderer.capabilities.maxSamples) : 0;
      if (target.samples === samples) return;
      target.dispose();
      target.samples = samples;
    },
    render(scene: Scene, active: OrthographicCamera | PerspectiveCamera = camera) {
      uniforms.perspectiveMode.value = active instanceof PerspectiveCamera ? 1 : 0;
      uniforms.nearClip.value = active.near;
      uniforms.depthRange.value = active.far - active.near;
      if (active instanceof PerspectiveCamera) {
        const height = 2 * Math.tan(active.fov * Math.PI / 360) / active.zoom;
        uniforms.viewSize.value.set(height * active.aspect, height);
      } else {
        uniforms.viewSize.value.set((camera.right - camera.left) / camera.zoom, (camera.top - camera.bottom) / camera.zoom);
      }
      renderer.info.reset();
      renderer.setRenderTarget(target);
      renderer.render(scene, active);
      renderer.setRenderTarget(null);
      renderer.render(screen, screenCamera);
    },
  };
}
