import {
  Color, DepthTexture, HalfFloatType, Mesh, OrthographicCamera, PlaneGeometry, Scene,
  ShaderMaterial, UnsignedByteType, UnsignedIntType, Vector2, WebGLRenderTarget, type WebGLRenderer,
} from "three";

export function createFinish(renderer: WebGLRenderer, camera: OrthographicCamera) {
  const target = new WebGLRenderTarget(1, 1, {
    type: renderer.extensions.has("EXT_color_buffer_float") ? HalfFloatType : UnsignedByteType,
    depthTexture: new DepthTexture(1, 1, UnsignedIntType),
  });
  const uniforms = {
    sceneColor: { value: target.texture },
    sceneDepth: { value: target.depthTexture },
    texel: { value: new Vector2(1, 1) },
    depthRange: { value: camera.far - camera.near },
    backdrop: { value: new Color("#242c47") },
  };
  const material = new ShaderMaterial({
    uniforms,
    depthTest: false,
    depthWrite: false,
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      uniform sampler2D sceneColor;
      uniform sampler2D sceneDepth;
      uniform vec2 texel;
      uniform float depthRange;
      uniform vec3 backdrop;
      varying vec2 vUv;

      float depthAt(vec2 point) {
        return texture2D(sceneDepth, point).r;
      }
      float lightness(vec3 rgb) {
        return dot(rgb, vec3(0.2126, 0.7152, 0.0722));
      }
      vec3 glowAt(vec2 point) {
        vec3 color = texture2D(sceneColor, point).rgb;
        return min(color * smoothstep(1.18, 2.8, max(color.r, max(color.g, color.b))), vec3(7.0));
      }
      void main() {
        float depth = depthAt(vUv);
        vec3 color = texture2D(sceneColor, vUv).rgb;
        vec2 h = vec2(texel.x, 0.0);
        vec2 v = vec2(0.0, texel.y);

        // Second differences respond to a contour while passing over a sloping face.
        float crease = max(abs(depthAt(vUv - h) + depthAt(vUv + h) - 2.0 * depth),
          abs(depthAt(vUv - v) + depthAt(vUv + v) - 2.0 * depth)) * depthRange;
        float brightness = lightness(color);
        if (depth < 0.9999) {
          float ink = smoothstep(0.14, 0.76, crease) * (0.46 - 0.27 * smoothstep(0.60, 1.65, brightness));
          color = mix(color, color * 0.24 + vec3(0.012, 0.015, 0.027), ink);
        } else {
          vec2 p = (vUv - vec2(0.50, 0.60)) * vec2(clamp(texel.y / texel.x, 0.66, 2.2), 1.0);
          float vignette = smoothstep(0.08, 0.88, length(p));
          vec3 studio = backdrop * mix(1.18, 0.34, vignette);
          // The scene's transparent contact shadow remains visible on the backdrop.
          color = studio * clamp(lightness(color) / max(0.0001, lightness(backdrop)), 0.0, 1.0);
        }

        vec3 glow = glowAt(vUv + h * 3.0) + glowAt(vUv - h * 3.0)
          + glowAt(vUv + v * 3.0) + glowAt(vUv - v * 3.0);
        vec2 diagonal = (h + v) * 3.2;
        vec2 crossDiagonal = (h - v) * 3.2;
        glow += 0.35 * (glowAt(vUv + diagonal) + glowAt(vUv - diagonal)
          + glowAt(vUv + crossDiagonal) + glowAt(vUv - crossDiagonal));
        gl_FragColor = vec4(color + glow * 0.055, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });
  const screen = new Scene();
  const quad = new Mesh(new PlaneGeometry(2, 2), material);
  quad.frustumCulled = false;
  screen.add(quad);
  const screenCamera = new OrthographicCamera();
  const size = new Vector2();
  renderer.info.autoReset = false;

  return {
    backdrop: uniforms.backdrop.value,
    resize() {
      renderer.getDrawingBufferSize(size);
      target.setSize(size.x, size.y);
      uniforms.texel.value.set(1 / size.x, 1 / size.y);
    },
    setAntialias(enabled: boolean) {
      const samples = enabled ? Math.min(4, renderer.capabilities.maxSamples) : 0;
      if (target.samples === samples) return;
      target.dispose();
      target.samples = samples;
    },
    render(scene: Scene) {
      renderer.info.reset();
      renderer.setRenderTarget(target);
      renderer.render(scene, camera);
      renderer.setRenderTarget(null);
      renderer.render(screen, screenCamera);
    },
  };
}
