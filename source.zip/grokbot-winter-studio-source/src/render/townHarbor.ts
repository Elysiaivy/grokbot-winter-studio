import { BufferGeometry, CanvasTexture, Color, Float32BufferAttribute, Group, Mesh, MeshStandardMaterial, SRGBColorSpace, TorusGeometry, type Material } from "three";
import { laySnow, snowNoise, snowOnRock, snowPatch } from "./snowCover";
import { LAND, SEA, shoreline, heightAt } from "./townLand";
import { batch, beam, box, cyl, group, lit, oval, paint, part, placard, randomStream, rock, timberPaint } from "./townCraft";
export const PIER = { x: 19.45, z: 4.32 };
const pine = timberPaint("#947c61"), endgrain = timberPaint("#76604c"), iron = paint("#35464b"), ivory = paint("#ece0c7"), green = paint("#27534f");

function buildWater(root: Group) {
  const c = document.createElement("canvas");
  c.width = 600;
  c.height = 1088;
  const ctx = c.getContext("2d")!, rand = randomStream(850);
  const xmin = 10.5, xmax = LAND.right, zmin = LAND.front, zmax = LAND.back;
  const img = ctx.createImageData(c.width, c.height);
  const shoreColor = new Color("#6b9097"), deep = new Color("#234b5b"), pigment = new Color();
  for (let row = 0; row < c.height; row++)
    for (let col = 0; col < c.width; col++) {
      const x = xmin + (xmax - xmin) * col / c.width, z = zmin + (zmax - zmin) * row / c.height;
      const depth = Math.min(1, Math.max(0, (x - shoreline(z)) * .39));
      pigment.copy(shoreColor).lerp(deep, depth).convertLinearToSRGB();
      const wave = Math.sin(row * .25 + Math.sin(col * .049 + row * .019) * 1.65 + col * .05) * 2.3 + Math.sin(row * .06 - col * .02) * 3;
      const i = 4 * (row * c.width + col);
      const grain = wave + (rand() - .5) * 4;
      img.data[i] = 255 * pigment.r + grain;
      img.data[i + 1] = 255 * pigment.g + grain;
      img.data[i + 2] = 255 * pigment.b + grain;
      img.data[i + 3] = 255;
    }
  ctx.putImageData(img, 0, 0);
  for (let i = 0; i < 3600; i++) {
    const x = rand() * 600, y = rand() * 1088;
    ctx.strokeStyle = i % 5 ? "rgba(166,198,201,.23)" : "rgba(20,56,72,.25)";
    ctx.lineWidth = .7 + rand();
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x + 4, y - 1, x + 2 + rand() * 16, y + .3);
    ctx.stroke();
  }
  // Broken amber reflections in the navigation channel sit beneath each practical lamp.
  for (const [wx, wz, len] of [[PIER.x, PIER.z, 2.4], [17.15, 5.7, 1.2]]) {
    for (let i = 0; i < 95; i++) {
      const t = rand(), x = (wx - xmin) / (xmax - xmin) * 600 + (rand() - .5) * (4 + t * 44);
      const y = (wz - t * len - zmin) / (zmax - zmin) * 1088;
      ctx.fillStyle = 'rgba(246,187,103,' + ((1 - t) * (.24 + rand() * .48)) + ')';
      ctx.fillRect(x, y, 2 + rand() * 12, .8 + rand() * 1.9);
    }
  }
  const tex = new CanvasTexture(c);
  tex.colorSpace = SRGBColorSpace;
  tex.anisotropy = 4;
  const mat = new MeshStandardMaterial({ map: tex, roughness: .35, metalness: .22, envMapIntensity: .55 });
  const p: number[] = [], uv: number[] = [], idx: number[] = [];
  for (let j = 0; j <= 140; j++) {
    const z = zmin + (zmax - zmin) * j / 140;
    const start = shoreline(z) - .12;
    p.push(start, SEA, z, xmax, SEA, z);
    uv.push((start - xmin) / (xmax - xmin), 1 - j / 140, 1, 1 - j / 140);
    if (j < 140) {
      const n = j * 2;
      idx.push(n, n + 2, n + 1, n + 1, n + 2, n + 3);
    }
  }
  const g = new BufferGeometry();
  g.setIndex(idx);
  g.setAttribute("position", new Float32BufferAttribute(p, 3));
  g.setAttribute("uv", new Float32BufferAttribute(uv, 2));
  g.computeVertexNormals();
  root.add(new Mesh(g, mat));
}

function hull(parent: Group) {
  const sections = [[-2.06, .07, .16], [-1.82, .45, .06], [-1.32, .65, 0], [.8, .67, 0], [1.56, .52, .06], [2.08, .035, .22]];
  const pos: number[] = [], colors: number[] = [], uv: number[] = [];
  const poly = (a: number[], b: number[], c: number[], d: number[], mat: string) => {
    pos.push(...a, ...b, ...d, ...b, ...c, ...d);
    const col = new Color(mat);
    for (let i = 0; i < 6; i++) {
      colors.push(col.r, col.g, col.b);
      uv.push(0, 0);
    }
  };
  for (let i = 1; i < sections.length; i++) {
    const [x, w, v] = sections[i - 1], [xx, ww, vv] = sections[i];
    const bands: [
      number,
      number,
      string
    ][] = [[.1, -.33, "#663f38"], [.76, -.13, "#214d48"], [1, .31, "#e7d9bf"], [1, .36, "#435c54"]];
    for (const side of [-1, 1]) {
      for (let k = 0; k < bands.length - 1; k++) {
        const [a, y, t] = bands[k], [b, yy] = bands[k + 1];
        poly([x, y + v, side * w * a], [xx, y + vv, side * ww * a], [xx, yy + vv, side * ww * b], [x, yy + v, side * w * b], t);
      }
    }
    poly([x, .36 + v, -w], [xx, .36 + vv, -ww], [xx, .36 + vv, ww], [x, .36 + v, w], "#967d60");
  }
  const g = new BufferGeometry();
  g.setAttribute("position", new Float32BufferAttribute(pos, 3));
  g.setAttribute("color", new Float32BufferAttribute(colors, 3));
  g.setAttribute("uv", new Float32BufferAttribute(uv, 2));
  g.computeVertexNormals();
  const m = new Mesh(g, new MeshStandardMaterial({ vertexColors: true, side: 2, roughness: .68 }));
  m.castShadow = true;
  parent.add(m);
}

export function mooring(p: Group, x: number, y: number, z: number, mat: Material) {
  cyl(p, mat, x, y + .10, z, .13, .20);
  cyl(p, mat, x, y + .21, z, .19, .055);
}

function ferry(p: Group, glass: Material) {
  hull(p);
  box(p, ivory, -.03, .71, 0, 1.92, .70, .96);
  box(p, green, -.01, .47, 0, 2.03, .12, 1.01);
  for (const side of [-1, 1]) {
    for (const x of [-.75, -.40, -.05, .30, .65]) {
      box(p, green, x, .82, side * .491, .277, .29, .028);
      box(p, glass, x, .824, side * .508, .219, .218, .019);
    }
    box(p, green, .91, .73, side * .42, .06, .66, .12);
  }
  for (const z of [-.26, .26])
    box(p, glass, .94, .83, z, .05, .28, .35);
  box(p, green, 0, 1.105, 0, 2.17, .14, 1.23);
  laySnow(p,{left:-1.04,right:1.04,front:-.57,back:.57},()=>1.177,(x,z)=>
    .015+.16*z+.34*(snowNoise(x*1.9,z*3.1)-.40),.058);
  cyl(p, ivory, -.44, 1.43, 0, .23, .52);
  cyl(p, iron, -.44, 1.69, 0, .26, .09);
  cyl(p, pine, .60, 1.75, 0, .062, 1.27);
  beam(p, endgrain, [.61, 2.38, 0], [1.72, .58, 0], .022);
  beam(p, endgrain, [.61, 2.29, 0], [-1.72, .53, 0], .018);
  box(p, paint("#ad4840"), .43, 2.22, 0, .30, .16, .026);
  box(p, ivory, .45, 2.23, -.017, .035, .15, .012);
  for (const x of [-1.55, -1.22, 1.18, 1.51]) {
    for (const s of [-1, 1]) {
      cyl(p, ivory, x, .64, s * .48, .035, .4);
      mooring(p, x, .38, s * .39, iron);
    }
  }
  for (const s of [-1, 1]) {
    beam(p, ivory, [-1.62, .83, s * .47], [-1.10, .83, s * .57], .037);
    beam(p, ivory, [1.08, .83, s * .56], [1.60, .83, s * .43], .037);
  }
  const ring = part(p, new TorusGeometry(.148, .042, 8, 20), paint("#c45d45"), -.56, .72, -.535);
  for (const a of [0, Math.PI / 2, Math.PI, Math.PI * 1.5])
    oval(p, ivory, ring.position.x + .15 * Math.cos(a), .72 + .15 * Math.sin(a), -.54, .065, .066, .075);
  for (const x of [-1.28, 1.34]) {
    cyl(p, iron, x, .24, -.64, .14, .36);
    beam(p, endgrain, [x, .4, -.58], [x, .57, -.5], .024);
  }
}

// Thin shore-fast ice follows the water level. Its broken outside edge is
// dark and translucent-looking where the open channel washes over it.
function shoreIce(parent: Group) {
  const p: number[] = [], colors: number[] = [], indices: number[] = [], uv: number[] = [];
  const wet = new Color("#597e88"), milk = new Color("#b7cdd1"), dust = new Color("#dbe5e3"), tint = new Color();
  function vertex(x: number, y: number, z: number, mix: number, frost: number) {
    const k = p.length / 3;
    p.push(x, y, z);
    uv.push(x, z);
    tint.copy(wet).lerp(milk, mix).lerp(dust, frost);
    colors.push(tint.r, tint.g, tint.b);
    return k;
  }
  function waterline(z: number) {
    let lo = shoreline(z) - .35, hi = lo + 1.65;
    for (let i = 0; i < 10; i++) {
      const x = (lo + hi) * .5;
      if (heightAt(x, z) > SEA)
        lo = x;
      else
        hi = x;
    }
    return (lo + hi) * .5;
  }
  const random = randomStream(614);
  for (let z = LAND.front + .12; z < LAND.back - .24;) {
    const length = Math.min(.36 + random() ** .65 * 1.75, LAND.back - z - .03);
    const reach = .10 + random() * .38, rows = Math.max(3, Math.ceil(length / .10));
    let previous = -1;
    for (let row = 0; row <= rows; row++) {
      const t = row / rows, zz = z + length * t, x = waterline(zz);
      const width = reach * (.18 + .82 * Math.sin(Math.PI * t) ** .52) * (.70 + .52 * snowNoise(zz * 7, 4));
      const n = vertex(x - .04, SEA + .031, zz, .88, .13);
      vertex(x + width * .48, SEA + .02, zz, .60 + .23 * snowNoise(zz * 3, 8), .11);
      vertex(x + width, SEA + .011, zz, .16 + .24 * random(), 0);
      if (previous >= 0)
        for (let j = 0; j < 2; j++)
          indices.push(previous + j, n + j, previous + j + 1, previous + j + 1, n + j, n + j + 1);
      previous = n;
    }
    if (random() > .46) {
      const zz = z + length * .55, cx = waterline(zz) + reach + .10 + random() * .14;
      const corners = 5, center = vertex(cx, SEA + .020, zz, .70, .13);
      for (let i = 0; i < corners; i++) {
        const angle = i * Math.PI * 2 / corners;
        vertex(cx + .11 * Math.cos(angle) * (.68 + random() * .65), SEA + .015, zz + .17 * Math.sin(angle), .38 + random() * .3, 0);
      }
      for (let i = 0; i < corners; i++)
        indices.push(center, center + 1 + (i + 1) % corners, center + i + 1);
    }
    z += length + .07 + random() ** 2 * .9;
  }
  const g = new BufferGeometry();
  g.setAttribute("position", new Float32BufferAttribute(p, 3));
  g.setAttribute("color", new Float32BufferAttribute(colors, 3));
  g.setAttribute("uv", new Float32BufferAttribute(uv, 2));
  g.setIndex(indices);
  g.computeVertexNormals();
  const mesh = new Mesh(g, new MeshStandardMaterial({ vertexColors: true, roughness: .39, metalness: .04 }));
  mesh.receiveShadow = true;
  parent.add(mesh);
}

export function buildHarbor(root: Group) {
  const harbor = group(root);
  buildWater(harbor);
  const amber = lit("#ffe3a8", "#ffd27c"), portGlass = lit("#aac0b9", "#ecb87a");
  const rand = randomStream(370);
  shoreIce(harbor);
  for (const [x, z, w] of [[20.25, 10.2, 2.85], [21.45, 9.8, 1.36], [18.95, 10.85, 1.2], [19.3, -10.3, .85]]) {
    const stone=rock(harbor,paint("#77868e"),x,SEA+.1,z,w,w*.48,w*.77);
    snowOnRock(stone,z);
    if (w > 2) {
      for (let i = 0; i < 3; i++) {
        const xx = x - .54 + i * .51, h = .72 + i * .20;
        cyl(harbor, endgrain, xx, SEA + .60, z, .065, .72);
        for (let k = 0; k < 3; k++)
          rock(harbor, paint("#36574e"), xx, SEA + .64 + k * .20, z, h * (.52 - k * .11), h * .55, h * (.5 - k * .11));
      }
    }
  }
  const pier = group(harbor);
  pier.name = "hotspot-quay";
  const y = -.36, z = PIER.z;
  for (let i = 0; i < 36; i++) {
    const x = 13.7 + i * .178;
    box(pier, i % 4 === 0 ? endgrain : pine, x, y, z, .166, .13, 1.27);

  }
  for(const [x,length] of [[14.4,.82],[16.07,1.23],[18.46,.94],[19.49,.56]]){
    snowPatch(pier,x,y+.067,z+.46,length,.21+rand()*.09,.031,rand()*16);
  }
  for (const x of [14.3, 15.9, 17.4, 19.7]) {
    for (const s of [-1, 1]) {
      cyl(pier, endgrain, x, -.79, z + s * .49, .18, 1.1);
      cyl(pier, iron, x, -.42, z + s * .49, .19, .055);
    }
    if (x > 15)
      mooring(pier, x, y + .07, z + .42, iron);
  }
  for (const s of [-1, 1])
    box(pier, endgrain, 16.72, -.51, z + s * .43, 6.35, .19, .12);
  for (let i = 0; i < 10; i++)
    box(pier, i % 3 ? pine : endgrain, 14.36, y - .012, 2.52 + i * .145, .79, .104, .135);
  for (const side of [-1, 1]) {
    box(pier, endgrain, 14.36 + side * .29, y - .102, 3.20, .09, .13, 1.5);
    cyl(pier, endgrain, 14.36 + side * .29, -.65, 3.57, .14, .62);
  }
  const bx = PIER.x, bz = PIER.z;
  cyl(pier, iron, bx, -.14, bz, .38, .35);
  cyl(pier, paint("#a85041"), bx, .57, bz, .25, 1.17);
  cyl(pier, ivory, bx, .67, bz, .258, .29);
  cyl(pier, iron, bx, 1.23, bz, .55, .12);
  cyl(pier, amber, bx, 1.49, bz, .38, .46);
  cyl(pier, iron, bx, 1.78, bz, .55, .12);
  for (let i = 0; i < 4; i++) {
    const a = i * Math.PI / 2;
    cyl(pier, iron, bx + Math.cos(a) * .18, 1.49, bz + Math.sin(a) * .18, .035, .46);
  }
  oval(pier, iron, bx, 1.89, bz, .48, .22, .48);
  cyl(pier, amber, bx, 2.04, bz, .065, .11);
  batch(pier);
  const boat = group(harbor, 17.66, SEA + .04, 5.9);
  boat.rotation.y = -.056;
  ferry(boat, portGlass);
  beam(harbor, endgrain, [19.5, SEA + .5, 5.75], [19.7, -.13, 4.76], .028);
  beam(harbor, endgrain, [15.83, SEA + .48, 5.65], [15.9, -.13, 4.76], .028);
  for (const x of [14.1, 14.9]) {
    box(harbor, pine, x, -.075, 4.52, .56, .43, .47);
    for (const dx of [-.21, .21])
      box(harbor, endgrain, x + dx, -.07, 4.52, .058, .45, .50);
  }
  placard(harbor, "MARGINS", "BOOK POST", 14.10, -.065, 4.277, .32, .17, "#e9dfc3", "#49605d");
  batch(harbor);
  return (light: number) => { amber.emissiveIntensity = .53 + light * 1.9; portGlass.emissiveIntensity = .06 + light * .42; };
}
