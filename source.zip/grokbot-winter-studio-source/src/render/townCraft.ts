import { BoxGeometry, BufferGeometry, CanvasTexture, RepeatWrapping, SRGBColorSpace, CylinderGeometry, Group, IcosahedronGeometry, Mesh, PlaneGeometry, SphereGeometry, Vector3, type Material, type Object3D } from "three";
import { makeSignTexture, matte } from "./factory";
import { mergeStatic } from "./merge";
const cube = new BoxGeometry(1, 1, 1);
const barrel = new CylinderGeometry(0.5, 0.5, 1, 16);
const round = new SphereGeometry(0.5, 14, 10);
const boulder = new IcosahedronGeometry(0.5, 1);
const paper = new PlaneGeometry(1, 1);
const paints = new Map<string, ReturnType<typeof matte>>();

export function paint(color: string) {
  if (!paints.has(color))
    paints.set(color, matte(color, 0.80));
  return paints.get(color)!;
}
let grain: CanvasTexture | undefined;
const timber = new Map<string, ReturnType<typeof matte>>();

export function timberPaint(color: string) {
  if (!grain) {
    const c = document.createElement("canvas");
    c.width = 512;
    c.height = 192;
    const g = c.getContext("2d")!, im = g.createImageData(512, 192);
    for (let y = 0; y < 192; y++)
      for (let x = 0; x < 512; x++) {
        const knot = Math.exp(-((x - 162) ** 2 / 2400 + (y - 82) ** 2 / 270));
        const curve = y + .92 * Math.sin(x * .028 + y * .07) + Math.sin(x * .012 + y * .03) * 2.1 + knot * 11;
        const v = 225 + 9 * Math.sin(curve * 1.17) + 7 * Math.cos(curve * .72) - 13 * knot + ((x * 17 ^ y * 23) % 11);
        const k = (y * 512 + x) * 4;
        im.data.set([v, v, v, 255], k);
      }
    g.putImageData(im, 0, 0);
    grain = new CanvasTexture(c);
    grain.colorSpace = SRGBColorSpace;
    grain.wrapS = grain.wrapT = RepeatWrapping;
    grain.anisotropy = 4;
  }
  if (!timber.has(color)) {
    const mat = paint(color).clone();
    mat.map = grain;
    mat.bumpMap = grain;
    mat.bumpScale = .012;
    timber.set(color, mat);
  }
  return timber.get(color)!;
}

export function lit(color: string, glow: string) {
  const m = matte(color, 0.44).clone();
  m.emissive.set(glow);
  return m;
}

export function group(parent: Object3D, x = 0, y = 0, z = 0) {
  const g = new Group();
  g.position.set(x, y, z);
  parent.add(g);
  return g;
}

export function part(parent: Object3D, geo: BufferGeometry, mat: Material, x: number, y: number, z: number, w = 1, h = 1, d = 1) {
  const m = new Mesh(geo, mat);
  m.position.set(x, y, z);
  m.scale.set(w, h, d);
  m.castShadow = m.receiveShadow = true;
  parent.add(m);
  return m;
}

export function box(p: Object3D, m: Material, x: number, y: number, z: number, w: number, h: number, d: number) { return part(p, cube, m, x, y, z, w, h, d); }

export function cyl(p: Object3D, m: Material, x: number, y: number, z: number, w: number, h: number, d = w) { return part(p, barrel, m, x, y, z, w, h, d); }

export function oval(p: Object3D, m: Material, x: number, y: number, z: number, w: number, h: number, d: number) { return part(p, round, m, x, y, z, w, h, d); }

export function rock(p: Object3D, m: Material, x: number, y: number, z: number, w: number, h: number, d: number) { return part(p, boulder, m, x, y, z, w, h, d); }

export function beam(p: Object3D, m: Material, a: number[], b: number[], width: number, depth = width) {
  const start = new Vector3(...a), end = new Vector3(...b);
  const direction = end.clone().sub(start);
  const mid = start.lerp(end, 0.5);
  const bar = box(p, m, mid.x, mid.y, mid.z, width, direction.length(), depth);
  bar.quaternion.setFromUnitVectors(new Vector3(0, 1, 0), direction.normalize());
  return bar;
}

export function placard(p: Object3D, title: string, subtitle: string, x: number, y: number, z: number, w: number, h: number, bg: string, ink: string) {
  const m = matte("#ffffff", 0.77).clone();
  m.map = makeSignTexture(title, subtitle, bg, ink);
  const sign = part(p, paper, m, x, y, z, w, h);
  sign.rotation.y = Math.PI;
  return sign;
}

export function batch(g: Group) {
  mergeStatic(g);
  g.userData.keep = true;
}

export function randomStream(seed: number) {
  let n = seed >>> 0;
  return () => { n = (Math.imul(n, 1664525) + 1013904223) >>> 0; return n / 4294967296; };
}
