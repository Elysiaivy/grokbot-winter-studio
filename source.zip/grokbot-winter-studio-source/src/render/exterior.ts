import {
  BoxGeometry,
  CanvasTexture,
  CylinderGeometry,
  Group,
  Mesh,
  MeshBasicMaterial,
  MeshStandardMaterial,
  NoColorSpace,
  PlaneGeometry,
  SphereGeometry,
  SRGBColorSpace,
  Vector3,
  type BufferGeometry,
  type Texture,
} from "three";
import { snowPatch } from "./snowCover";
import { matte } from "./factory";

export const PLINTH_SIZE = 17;
export const PLINTH_CENTER_Z = -1.9;

const ROAD_WIDTH = 16.74;
const ROAD_DEPTH = 4.18;
const ROAD_FRONT = PLINTH_CENTER_Z - ROAD_WIDTH / 2;

export function makeWinterRoad(environment: Texture): Mesh {
  const width = 1024;
  const height = 256;
  const diffuse = makeCanvas(width, height);
  const glow = makeCanvas(width, height);
  const surface = makeCanvas(width, height);
  const asphalt = diffuse.context;
  const light = glow.context;
  light.fillStyle = "#000";
  light.fillRect(0, 0, width, height);

  // Locally polished cobbles catch the light differently from drier, raised stone.
  // Height and roughness occupy the red and green channels of one linear texture.
  const stone = asphalt.createImageData(width, height);
  const finish = surface.context.createImageData(width, height);
  let pixel = 0;
  for (let y = 0; y < height; y++) {
    const row = Math.floor(y / 21), dy = y % 21;
    const bend = Math.sin(y * 0.047) + Math.cos(y * 0.032);
    for (let x = 0; x < width; x++) {
      const shifted = x + (row % 2) * 11;
      const dx = shifted % 23, col = Math.floor(shifted / 23);
      const variant = Math.sin(row * 29.47 + col * 17.31);
      const wet = Math.max(0, Math.min(1, (Math.cos(x * 0.018 + bend * 0.73) + Math.sin(x * 0.006 - y * 0.035)) * 0.65));
      const edge = Math.min(dx, 23 - dx, dy, 21 - dy);
      const corners = Math.hypot(Math.max(0, Math.abs(dx - 11.5) - 8.25), Math.max(0, Math.abs(dy - 10.5) - 7.25));
      const face = Math.min(1, Math.max(0, Math.min(edge - 0.2, 3.4 - corners) * 0.7));
      const aggregate = ((x * 31 ^ y * 473 ^ x * y * 13) & 63) / 63 - 0.5;
      const value = 39 + (7 + variant * 4 + aggregate * 7) * face - wet * 4;
      stone.data[pixel] = value;
      stone.data[pixel + 1] = value + 12;
      stone.data[pixel + 2] = value + 23 + variant * 2;
      finish.data[pixel] = 82 + face * (111 + variant * 10 + aggregate * 14);
      finish.data[pixel + 1] = 94 + face * (102 + variant * 13) - wet * 50 + aggregate * 6;
      finish.data[pixel + 2] = 0;
      stone.data[pixel + 3] = finish.data[pixel + 3] = 255;
      pixel += 4;
    }
  }
  asphalt.putImageData(stone, 0, 0);
  surface.context.putImageData(finish, 0, 0);

  // Reflections are painted as broken bands, pooled underneath the lit signs and lamps.
  for (const [worldX, breadth, reach, color] of [
    [-6.36, 48, 218, "255, 183, 107"],
    [-3.2, 70, 193, "248, 136, 99"],
    [-0.22, 55, 150, "105, 203, 231"],
    [2.8, 70, 184, "236, 164, 104"],
    [5.25, 48, 241, "149, 133, 235"],
    [6.42, 35, 180, "255, 197, 139"],
  ] as const) {
    const center = width * (worldX / ROAD_WIDTH + 0.5);
    light.save();
    light.translate(center, 223);
    light.scale(breadth, reach);
    const pool = light.createRadialGradient(0, 0, 0.06, 0, 0, 1);
    pool.addColorStop(0, `rgba(${color}, .48)`);
    pool.addColorStop(0.3, `rgba(${color}, .28)`);
    pool.addColorStop(0.7, `rgba(${color}, .07)`);
    pool.addColorStop(1, `rgba(${color}, 0)`);
    light.fillStyle = pool;
    light.fillRect(-1, -1, 2, 2);
    light.restore();
    for (let line = 0; line < 17; line += 1) {
      const ratio = line / 17;
      const wobble = Math.sin(line * 2.5 + worldX) * breadth * 0.38;
      const span = breadth * (0.15 + Math.abs(Math.cos(line * 4.4)) * 0.64);
      const x = center + wobble;
      const y = 229 - reach * (0.08 + ratio * 0.76);
      const ripple = light.createLinearGradient(x - span, y, x + span, y);
      ripple.addColorStop(0, `rgba(${color}, 0)`);
      ripple.addColorStop(0.45, `rgba(${color}, ${0.31 * (1 - ratio)})`);
      ripple.addColorStop(1, `rgba(${color}, 0)`);
      light.fillStyle = ripple;
      light.fillRect(x - span, y, span * 2, line % 3 === 0 ? 4 : 2);
    }
  }

  const colorMap = new CanvasTexture(diffuse.canvas);
  const lightMap = new CanvasTexture(glow.canvas);
  const surfaceMap = new CanvasTexture(surface.canvas);
  surfaceMap.colorSpace = NoColorSpace;
  colorMap.colorSpace = lightMap.colorSpace = SRGBColorSpace;
  colorMap.anisotropy = lightMap.anisotropy = surfaceMap.anisotropy = 4;
  const material = new MeshStandardMaterial({
    map: colorMap,
    emissive: "#ffffff",
    emissiveMap: lightMap,
    emissiveIntensity: 0.72,
    bumpMap: surfaceMap,
    bumpScale: 0.017,
    roughness: 1,
    roughnessMap: surfaceMap,
    metalness: 0.06,
    envMap: environment,
    envMapIntensity: 0.65,
  });
  material.userData.selectionGround = true;
  const road = new Mesh(new PlaneGeometry(ROAD_WIDTH, ROAD_DEPTH), material);
  road.rotation.x = -Math.PI / 2;
  road.position.set(0, -0.169, ROAD_FRONT + ROAD_DEPTH / 2);
  road.receiveShadow = true;
  return road;
}

export function buildWinterStreetscape() {
  const root = new Group();
  const iron = matte("#394758", 0.53, 0.38);
  const stone = matte("#596378", 0.85);
  const snow = matte("#d9e6ef", 0.92);
  const ice = matte("#aabfd2", 0.87);
  const bark = matte("#c0b7ad", 0.94);
  const twigs = matte("#756b66", 0.91);
  const spruce = matte("#315b53", 0.88);
  const juniper = matte("#3b6c67", 0.89);
  const berries = matte("#9f4658", 0.5);
  const lanternGlass = new MeshStandardMaterial({ color: "#ffe5b5", emissive: "#ffc98c", roughness: 0.38 });
  const pool = makeLampPool();
  const powderGeometry = new SphereGeometry(1, 10, 6);
  const stalkGeometry = new CylinderGeometry(0.62, 1, 1, 7);
  const foliageGeometry = new SphereGeometry(1, 9, 6);
  const berryGeometry = new SphereGeometry(0.038, 6, 5);

  // Break the row of illuminated conifers with leafless trees and low, berry-bearing plantings.
  birch(7.62, -2.35, 1.04, 0.58);
  birch(-7.66, 2.72, 1.14, 2.24);
  birch(4.55, 5.78, 0.82, -1.26);
  planter(7.53, 1.15, Math.PI / 2, 1);
  planter(-7.55, -1.66, -Math.PI / 2, 0.95);
  planter(-3.37, 5.72, 0, 1.13);
  planter(1.78, 5.78, Math.PI, 0.91);

  // Use pedestrian lanterns along the outer paths and leave the main shopfronts unobstructed.
  lantern(7.63, 0.06, 0.96);
  lantern(-7.61, -2.98, 1.06);
  lantern(-5.93, 5.57, 0.9);

  return {
    root,
    setStreetLight(amount: number) {
      lanternGlass.emissiveIntensity = 0.12 + amount * 1.35;
      pool.opacity = amount * 0.34;
    },
  };

  function part(parent: Group, geometry: BufferGeometry, material: MeshStandardMaterial, x: number, y: number, z: number): Mesh {
    const mesh = new Mesh(geometry, material);
    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
  }

  function cluster(x: number, z: number, scale: number, turn: number): Group {
    const group = new Group();
    group.position.set(x, -0.035, z);
    group.rotation.y = turn;
    group.scale.setScalar(scale);
    root.add(group);
    return group;
  }

  function stem(group: Group, from: Vector3, to: Vector3, radius: number, material: MeshStandardMaterial): void {
    const direction = to.clone().sub(from);
    const middle = from.clone().addScaledVector(direction, 0.5);
    const branch = part(group, stalkGeometry, material, middle.x, middle.y, middle.z);
    branch.scale.set(radius, direction.length(), radius);
    branch.quaternion.setFromUnitVectors(branch.up, direction.normalize());
  }

  function birch(x: number, z: number, scale: number, turn: number): void {
    const group = cluster(x, z, scale, turn);
    const base = new Vector3(0, 0.02, 0);
    const fork = new Vector3(0.02, 0.83, 0);
    const tip = new Vector3(-0.11, 1.79, 0.03);
    snowPatch(group,.035,.008,.014,.85,.57,.073,turn);
    stem(group, base, fork, 0.057, bark);
    stem(group, fork, tip, 0.038, bark);
    for (const [y, angle, length] of [
      [0.66, 0.45, 0.54], [0.86, 3.26, 0.64], [0.99, 1.69, 0.47],
      [1.18, 5.2, 0.48], [1.36, 2.55, 0.36], [1.53, 0.34, 0.26],
    ]) {
      const join = new Vector3(y < 0.83 ? 0 : 0.02 - (y - 0.83) * 0.135, y, 0);
      const elbow = join.clone().add(new Vector3(Math.cos(angle) * length * 0.6, 0.22, Math.sin(angle) * length * 0.6));
      const point = join.clone().add(new Vector3(Math.cos(angle) * length, 0.4, Math.sin(angle) * length));
      const split = elbow.clone().add(new Vector3(Math.cos(angle + 0.85) * 0.24, 0.27, Math.sin(angle + 0.85) * 0.24));
      stem(group, join, elbow, 0.027, y < 1 ? bark : twigs);
      stem(group, elbow, point, 0.015, twigs);
      stem(group, elbow, split, 0.011, twigs);
      const dusting = part(group, powderGeometry, snow, (join.x + elbow.x) / 2, (join.y + elbow.y) / 2 + 0.023, (join.z + elbow.z) / 2);
      dusting.scale.set(join.distanceTo(elbow) * 0.37, 0.017, 0.027);
      dusting.quaternion.setFromUnitVectors(new Vector3(1, 0, 0), elbow.clone().sub(join).normalize());
    }
    for (const [height, angle, thickness] of [[0.23, 0.1, 0.018], [0.38, 0.21, 0.013], [0.52, 0.12, 0.021], [0.69, 0.8, 0.012]]) {
      const width = 0.061 - height * 0.03;
      const patch = part(group, new BoxGeometry(width, thickness, 0.007), twigs, Math.sin(angle) * width, height, -Math.cos(angle) * width);
      patch.rotation.y = -angle;
      patch.rotation.z = -0.16;
    }
  }

  function planter(x: number, z: number, turn: number, scale: number): void {
    const group = cluster(x, z, scale, turn);
    part(group, new BoxGeometry(1.34, 0.22, 0.53), stone, 0, 0.12, 0).castShadow = true;
    part(group, new BoxGeometry(1.41, 0.06, 0.58), iron, 0, 0.241, 0);
    part(group, new BoxGeometry(1.37, 0.022, 0.55), ice, 0, 0.277, 0).receiveShadow = true;
    for (let i = 0; i < 7; i += 1) {
      const dx = -0.52 + i * 0.173;
      const dz = Math.sin(i * 3.7 + turn) * 0.105;
      const height = 0.14 + (i * 13 % 5) * 0.03;
      part(group, foliageGeometry, i % 2 ? spruce : juniper, dx, 0.3 + height * 0.63, dz).scale.set(0.205, height, 0.185);
      snowPatch(group,dx,.30+height*.63,dz,.26,.24,.019,turn+i,
        (x,z)=>height*Math.sqrt(Math.max(0,1-(x/.205)**2-(z/.185)**2)));
    }
    for (const [dx, angle] of [[-0.38, 0.9], [0.23, 2.3], [0.43, -1.1]]) {
      const start = new Vector3(dx, 0.34, 0);
      const top = new Vector3(dx + Math.cos(angle) * 0.14, 0.63 + Math.sin(angle) * 0.085, Math.sin(angle) * 0.21);
      stem(group, start, top, 0.013, twigs);
      for (const [offset, lift] of [[-0.051, -0.019], [0.007, 0.017], [0.044, -0.021]]) {
        const fruit = top.clone().add(new Vector3(offset, lift, offset * 0.41));
        part(group, berryGeometry, berries, fruit.x, fruit.y, fruit.z);
      }
    }
  }

  function lantern(x: number, z: number, scale: number): void {
    const group = cluster(x, z, scale, Math.PI / 4);
    part(group, new CylinderGeometry(0.096, 0.139, 0.082, 8), iron, 0, 0.043, 0);
    part(group, new CylinderGeometry(0.039, 0.064, 0.23, 8), iron, 0, 0.169, 0);
    part(group, new CylinderGeometry(0.027, 0.036, 0.88, 8), iron, 0, 0.674, 0).castShadow = true;
    part(group, new CylinderGeometry(0.104, 0.055, 0.07, 4), iron, 0, 1.13, 0);
    part(group, new CylinderGeometry(0.136, 0.088, 0.21, 4), lanternGlass, 0, 1.266, 0);
    part(group, new CylinderGeometry(0.039, 0.178, 0.114, 4), iron, 0, 1.419, 0);
    part(group, new CylinderGeometry(0.033, 0.139, 0.071, 4), snow, 0, 1.454, 0.008);
    part(group, powderGeometry, iron, 0, 1.503, 0).scale.setScalar(0.031);
    for (let i = 0; i < 4; i += 1) {
      const angle = i * Math.PI / 2;
      const axis = new Vector3(Math.cos(angle), 0, Math.sin(angle));
      stem(group, axis.clone().multiplyScalar(0.09).setY(1.156), axis.multiplyScalar(0.138).setY(1.373), 0.012, iron);
    }
    const halo = new Mesh(new PlaneGeometry(2.24 * scale, 2.24 * scale), pool);
    halo.rotation.x = -Math.PI / 2;
    halo.position.set(x, -0.03, z);
    halo.userData.selectionIgnore = true;
    root.add(halo);
  }
}

function makeLampPool(): MeshBasicMaterial {
  const { canvas, context } = makeCanvas(64, 64);
  const halo = context.createRadialGradient(32, 32, 2, 32, 32, 32);
  halo.addColorStop(0, "rgba(255,255,255,0.9)");
  halo.addColorStop(0.42, "rgba(255,255,255,0.34)");
  halo.addColorStop(1, "rgba(255,255,255,0)");
  context.fillStyle = halo;
  context.fillRect(0, 0, 64, 64);
  return new MeshBasicMaterial({
    color: "#ffcd98",
    map: new CanvasTexture(canvas),
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    toneMapped: false,
  });
}

function makeCanvas(width: number, height: number): { canvas: HTMLCanvasElement; context: CanvasRenderingContext2D } {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Could not paint the winter street.");
  return { canvas, context };
}
