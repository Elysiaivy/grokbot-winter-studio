import { Spherical, Vector3 } from "three";
import type { RoleId } from "../sim/roles";
import type { RobotSnapshot } from "../sim/types";
import type { OfficeView } from "./scene";

export interface CameraShot {
  p: Vector3;
  t: Vector3;
  z: number;
}

export function createCameraFocus(office: OfficeView, getRobot: (id: RoleId) => RobotSnapshot | undefined) {
  const { camera, controls } = office;
  const rigs = new Map(office.robots.map((rig) => [rig.id, rig]));
  const anchor = new Vector3();
  const heading = new Vector3();
  const head = new Vector3();
  const offset = new Vector3();
  const orbit = new Spherical();
  let role: RoleId | null = null;
  let follows = false;
  let transition: {
    age: number;
    shot: CameraShot;
    from: CameraShot;
    start: Spherical;
    end: Spherical;
    turn: number;
  } | null = null;

  function getAnchor(id: RoleId, subject: RobotSnapshot, out: Vector3): void {
    const rig = rigs.get(id)!;
    out.copy(rig.group.position);
    out.y = Math.max(0.72, rig.head.getWorldPosition(head).y * 0.64 + 0.12);
    const desk = subject.phase === "working" ? office.workstations.get(id) : undefined;
    if (desk) {
      out.x += (desk.root.position.x - out.x) * 0.36;
      out.z += (desk.root.position.z - out.z) * 0.36;
      out.y += 0.12;
    } else if (subject.phase === "sipping" || subject.phase === "seated_fire") {
      out.z += 0.17;
    }
  }

  function closeZoom(subject: RobotSnapshot): number {
    const working = subject.phase === "working";
    const width = working ? 2.65 : 3.25;
    const height = working ? 2.15 : 2.70;
    return Math.min(controls.maxZoom, (camera.right - camera.left) / width, (camera.top - camera.bottom) / height);
  }

  function show(shot: CameraShot): void {
    camera.position.copy(shot.p);
    controls.target.copy(shot.t);
    camera.zoom = shot.z;
    camera.updateProjectionMatrix();
    controls.update();
  }

  function begin(shot: CameraShot, reduced: boolean): void {
    const from = { p: camera.position.clone(), t: controls.target.clone(), z: camera.zoom };
    // Clear unfinished orbit damping before the camera takes over from a gesture.
    const damped = controls.enableDamping;
    controls.enableDamping = false;
    controls.update();
    show(reduced ? shot : from);
    controls.enableDamping = damped;
    if (reduced) {
      transition = null;
      return;
    }
    const start = new Spherical().setFromVector3(offset.copy(from.p).sub(from.t));
    const end = new Spherical().setFromVector3(offset.copy(shot.p).sub(shot.t));
    const angle = end.theta - start.theta;
    transition = { age: 0, shot, from, start, end, turn: Math.atan2(Math.sin(angle), Math.cos(angle)) };
  }

  function select(id: RoleId, reduced: boolean): void {
    const subject = getRobot(id);
    if (!subject) return;
    role = id;
    follows = !reduced;
    getAnchor(id, subject, anchor);
    const inward = subject.x < 0 ? 1 : -1;
    // Open the storefront like a dollhouse for desk views reached from the front.
    office.setFrontWall(subject.phase !== "working" || id === "ceo");
    if (subject.phase === "working") {
      if (id === "ceo") {
        heading.set(1, 0.73, 0.42);
      } else {
        heading.set(inward * 0.69, 0.84, -0.87);
      }
      heading.setLength(office.roofVisible() ? 2.55 : 3.55);
    } else if (subject.phase === "seated_fire" && id === "literature") {
      heading.set(1, 0.62, -0.14).setLength(2.85);
    } else if (subject.phase === "sipping") {
      heading.set(subject.x < 2.5 ? 1 : -1, 0.72, -0.05).setLength(2.85);
    } else if (subject.phase === "seated_fire") {
      heading.set(inward * 0.99, 0.91, -0.48).setLength(office.roofVisible() ? 2.75 : 4.3);
    } else {
      heading.set(inward * 0.84, 0.96, subject.z < -1.1 ? 0.42 : -0.56).setLength(office.roofVisible() ? 2.75 : 4.3);
    }
    begin({ p: anchor.clone().add(heading), t: anchor.clone(), z: closeZoom(subject) }, reduced);
  }

  function interrupt(): void {
    transition = null;
    follows = false;
  }

  return {
    get state() { return { role, transitioning: transition !== null }; },
    select,
    interrupt,
    clear() {
      interrupt();
      role = null;
      office.setFrontWall(true);
    },
    overview(reduced: boolean) {
      role = null;
      follows = false;
      office.setFrontWall(true);
      begin(office.overviewShot, reduced);
    },
    update(dt: number, reduced: boolean) {
      if (reduced) follows = false;
      if (!transition && !follows) return;
      const subject = role ? getRobot(role) : undefined;
      if (role && subject) getAnchor(role, subject, anchor);
      if (transition) {
        const { shot, from, start, end, turn } = transition;
        if (role && subject) {
          shot.t.copy(anchor);
          shot.z = closeZoom(subject);
          shot.p.setFromSpherical(end).add(anchor);
        }
        transition.age += dt;
        const time = reduced ? 1 : Math.min(1, transition.age / 0.78);
        if (time === 1) {
          show(shot);
          transition = null;
          return;
        }
        const eased = time * time * (3 - 2 * time);
        controls.target.lerpVectors(from.t, shot.t, eased);
        orbit.set(start.radius + (end.radius - start.radius) * eased, start.phi + (end.phi - start.phi) * eased, start.theta + turn * eased);
        camera.position.setFromSpherical(orbit).add(controls.target);
        camera.zoom = from.z * (shot.z / from.z) ** eased;
        camera.updateProjectionMatrix();
      } else if (follows && role && subject) {
        const blend = 1 - Math.exp(-6 * dt);
        offset.copy(anchor).sub(controls.target).multiplyScalar(blend);
        camera.position.add(offset);
        controls.target.add(offset);
        const difference = closeZoom(subject) - camera.zoom;
        if (Math.abs(difference) > 1e-6) {
          camera.zoom += difference * blend;
          camera.updateProjectionMatrix();
        }
      }
    },
  };
}
