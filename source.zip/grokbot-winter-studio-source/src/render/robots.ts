import {
  CanvasTexture,
  CircleGeometry,
  Color,
  CylinderGeometry,
  ExtrudeGeometry,
  Group,
  InstancedMesh,
  Matrix4,
  Mesh,
  MeshBasicMaterial,
  MeshPhysicalMaterial,
  MeshStandardMaterial,
  Quaternion,
  Shape,
  SRGBColorSpace,
  TorusGeometry,
  Vector3,
  type BufferGeometry,
  type Object3D,
} from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { ROLES, type RoleId } from "../sim/roles";
import type { RobotSnapshot } from "../sim/types";
import { makeKnitBump, makeRadial, matte } from "./factory";
import { buildDeskTool, buildHeldBook, deskActions, smoothStep, type DeskActionRig, type RobotAction } from "./motion";

export interface RobotRig {
  id: RoleId;
  group: Group;
  hips: Group;
  head: Group;
  armL: Group;
  armR: Group;
  forearmL: Group;
  forearmR: Group;
  handL: Group;
  handR: Group;
  legL: Group;
  legR: Group;
  shinL: Group;
  shinR: Group;
  setEyesOpen: (openness: number) => void;
  mug: Object3D;
  slots: { mesh: Mesh; index: number; batch: InstancedMesh }[];
  sit: number;
  bob: number;
  blink: number;
  nextBlink: number;
  blinkLeft: number;
}

const surface = new Group();
surface.name = "robot-surface";
const blobMat = new MeshBasicMaterial({ map: makeRadial(), transparent: true, depthWrite: false });
const geoCache = new Map<string, RoundedBoxGeometry>();
const ARM_LENGTH = 0.20;
const BLINK_DURATION = 0.18;
const mugHandleGrip = new Vector3(-0.077, 0.049, -0.027);
const palmGrip = new Vector3(0.042, 0.014, -0.027);
const paperGrip = new Vector3(-0.038, -0.030, -0.030);

const finishes: Record<RoleId, { shell: string; trim: string; metal: string; proportions: [number, number, number] }> = {
  ceo: { shell: "#f1dac0", trim: "#8e394a", metal: "#e6b774", proportions: [1.12, 1.02, 1.04] },
  quant: { shell: "#356966", trim: "#53bcc0", metal: "#9ae2dc", proportions: [1.13, 0.91, 1.03] },
  backtest: { shell: "#606982", trim: "#a24d38", metal: "#f3a951", proportions: [0.94, 1.13, 0.99] },
  literature: { shell: "#ead5ae", trim: "#a77341", metal: "#c69350", proportions: [1.08, 1.02, 1.03] },
  hr: { shell: "#f7e2db", trim: "#ae5979", metal: "#edb6ca", proportions: [1.02, 1.06, 0.96] },
  secretary: { shell: "#e5e1d8", trim: "#364a6b", metal: "#94b8e0", proportions: [0.94, 1.12, 0.95] },
  ta: { shell: "#efd7b9", trim: "#b35238", metal: "#eda752", proportions: [1.04, 0.97, 1.02] },
};

function rbox(w: number, h: number, d: number, r = 0.04, s = 3): RoundedBoxGeometry {
  const maxR = Math.min(w, h, d) * 0.5 - 1e-4;
  const rr = Math.min(r, Math.max(0.001, maxR));
  const key = `${w}|${h}|${d}|${rr}|${s}`;
  let geo = geoCache.get(key);
  if (!geo) {
    geo = new RoundedBoxGeometry(w, h, d, s, rr);
    geoCache.set(key, geo);
  }
  return geo;
}

function makeBatch(geo: RoundedBoxGeometry, capacity: number, color = "#ffffff"): InstancedMesh {
  const material = new MeshStandardMaterial({ color, roughness: 0.62, metalness: 0 });
  const batch = new InstancedMesh(geo, material, capacity);
  batch.count = 0;
  batch.receiveShadow = true;
  batch.frustumCulled = false;
  surface.add(batch);
  return batch;
}

const torsoBatch = makeBatch(rbox(0.4, 0.34, 0.28, 0.08, 2), 7);
const hipBatch = makeBatch(rbox(0.34, 0.12, 0.24, 0.05, 2), 7);
const armBatch = makeBatch(rbox(0.09, ARM_LENGTH, 0.09, 0.036, 2), 28);
const thighBatch = makeBatch(rbox(0.1, 0.22, 0.1, 0.04, 2), 14);
const shinBatch = makeBatch(rbox(0.084, 0.2, 0.084, 0.0336, 2), 14, "#f4e2d0");
const slotWorld = new Matrix4();

export function robotSurface(): Group {
  return surface;
}

function mesh(geo: BufferGeometry, material: MeshStandardMaterial, x = 0, y = 0, z = 0): Mesh {
  const item = new Mesh(geo, material);
  item.position.set(x, y, z);
  item.receiveShadow = true;
  return item;
}

function drawEye(
  g: CanvasRenderingContext2D,
  x: number,
  y: number,
  rx: number,
  ry: number,
  iris: string,
  square: boolean,
  openness: number,
) {
  g.save();
  g.translate(x, y);
  if (openness <= 0.05) {
    g.strokeStyle = "#473731";
    g.lineWidth = 2.8;
    g.lineCap = "round";
    g.beginPath();
    g.moveTo(-rx * 0.73, 1);
    g.quadraticCurveTo(0, 5, rx * 0.73, 1);
    g.stroke();
    g.restore();
    return;
  }
  const eyeHeight = ry + 7;
  g.beginPath();
  g.rect(-rx - 7, -eyeHeight * openness, (rx + 7) * 2, eyeHeight * 2 * openness);
  g.clip();
  g.fillStyle = "#2a221c";
  g.beginPath();
  if (square) g.roundRect(-rx - 4, -ry - 4, (rx + 4) * 2, (ry + 4) * 2, 10);
  else g.ellipse(0, 0, rx + 6, ry + 6, 0, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = "#fffdf8";
  g.beginPath();
  if (square) g.roundRect(-rx, -ry, rx * 2, ry * 2, 8);
  else g.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = iris;
  g.beginPath();
  g.ellipse(0, 1, rx * 0.48, ry * 0.55, 0, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = "#1a120e";
  g.beginPath();
  g.ellipse(0, 2, rx * 0.22, ry * 0.28, 0, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = "#ffffff";
  g.beginPath();
  g.arc(rx * 0.18, -ry * 0.2, Math.max(3, rx * 0.12), 0, Math.PI * 2);
  g.fill();
  g.restore();
}

function addFace(head: Group, id: RoleId, iris: string): RobotRig["setEyesOpen"] {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 256;
  const g = canvas.getContext("2d");
  if (!g) throw new Error("Could not draw the robot face");
  const digital = id === "quant" || id === "backtest";
  const shapes = {
    ceo: { rx: 38, ry: 25, y: 118, gap: 56 },
    literature: { rx: 28, ry: 28, y: 120, gap: 49 },
    hr: { rx: 34, ry: 36, y: 112, gap: 54 },
    secretary: { rx: 31, ry: 23, y: 121, gap: 51 },
    ta: { rx: 35, ry: 34, y: 112, gap: 52 },
  };
  const baseColor = digital ? "#182930" : finishes[id].shell;
  const texture = new CanvasTexture(canvas);
  texture.colorSpace = SRGBColorSpace;
  let lastOpenness = -1;

  const setEyesOpen = (openness: number): void => {
    if (openness === lastOpenness) return;
    lastOpenness = openness;
    g.fillStyle = baseColor;
    g.fillRect(0, 65, 256, 100);
    if (digital) {
      const width = id === "quant" ? 61 : 47;
      const height = (id === "quant" ? 21 : 43) * (0.1 + 0.9 * openness);
      for (const x of [73, 183]) {
        g.fillStyle = id === "quant" ? "#9af7e9" : "#bec9fc";
        g.beginPath();
        g.roundRect(x - width / 2, 117 - height / 2, width, height, Math.min(6, height / 2));
        g.fill();
        g.fillStyle = "#e8fff9";
        g.fillRect(x + width * 0.22, 117 - height * 0.30, 6, Math.min(5, height * 0.55));
      }
    } else {
      const shape = shapes[id];
      for (const side of [-1, 1]) drawEye(g, 128 + side * shape.gap, shape.y, shape.rx, shape.ry, iris, id === "secretary", openness);
    }
    // The upper edge of the blush overlaps the region cleared for the eyes.
    if (id === "hr" || id === "ta") {
      g.fillStyle = id === "hr" ? "#d693a1" : "#d49074";
      for (const x of [62, 194]) {
        g.beginPath();
        g.ellipse(x, 158, 13, 6, 0, 0, Math.PI * 2);
        g.fill();
      }
    }
    texture.needsUpdate = true;
  };

  g.fillStyle = baseColor;
  g.fillRect(0, 0, 256, 256);
  g.strokeStyle = digital ? "#88bdc6" : "#a6615d";
  g.lineWidth = 4;
  g.lineCap = "round";
  g.beginPath();
  g.moveTo(116, 168);
  g.quadraticCurveTo(128, 176, 140, 168);
  g.stroke();
  setEyesOpen(1);
  const face = {
    map: texture,
    roughness: 0.72,
    metalness: 0,
    emissive: "#ffffff",
    emissiveMap: texture,
    emissiveIntensity: digital ? 0.42 : 0.09,
  };
  const material = id === "quant"
    ? new MeshPhysicalMaterial({ ...face, clearcoat: 0.83, clearcoatRoughness: 0.23, specularIntensity: 0.55 })
    : new MeshStandardMaterial(face);
  if (id === "quant") {
    // A soft window reflection moves over the glass as the face turns relative to the camera.
    material.onBeforeCompile = (shader) => {
      shader.fragmentShader = shader.fragmentShader.replace("#include <opaque_fragment>", `
        vec2 pane = vMapUv - vec2(0.52 + 0.31 * normal.x, 0.73 + 0.20 * normal.y);
        float band = 1.0 - smoothstep(0.005, 0.082, abs(pane.y + 0.24 * pane.x));
        float ends = 1.0 - smoothstep(0.18, 0.38, abs(pane.x));
        float displayLight = max(max(totalEmissiveRadiance.r, totalEmissiveRadiance.g), totalEmissiveRadiance.b);
        outgoingLight += vec3(0.022, 0.038, 0.049) * band * ends * (1.0 - smoothstep(0.08, 0.32, displayLight));
        #include <opaque_fragment>
      `);
    };
  }
  const plateGeometry = rbox(0.36, 0.32, 0.02, 0.05, 2);
  if (digital) head.add(mesh(plateGeometry, matte("#182930", 0.61), 0, 0.01, -0.173));
  const plate = mesh(plateGeometry, material, 0, 0.01, -0.178);
  plate.name = "faceplate";
  head.add(plate);
  return setEyesOpen;
}

function limb(length: number, radius: number, material: MeshStandardMaterial, parent: Object3D): Mesh {
  const item = mesh(rbox(radius * 2, length, radius * 2, radius * 0.8, 2), material, 0, -length / 2, 0);
  parent.add(item);
  return item;
}

function track(batch: InstancedMesh, item: Mesh, tint: Color | null, slots: RobotRig["slots"]): void {
  const index = batch.count;
  if (tint) batch.setColorAt(index, tint);
  batch.count += 1;
  item.visible = false;
  item.castShadow = false;
  slots.push({ mesh: item, index, batch });
}

function addArm(parent: Group, side: number, cloth: MeshStandardMaterial, cuff: MeshStandardMaterial, slots: RobotRig["slots"]) {
  const arm = new Group();
  const forearm = new Group();
  const hand = new Group();
  arm.position.set(side * 0.24, 0.3, 0);
  forearm.position.y = -ARM_LENGTH;
  hand.position.y = -ARM_LENGTH;
  parent.add(arm);
  arm.add(forearm);
  forearm.add(hand);
  track(armBatch, limb(ARM_LENGTH, 0.045, cloth, arm), cloth.color, slots);
  track(armBatch, limb(ARM_LENGTH, 0.045, cloth, forearm), cloth.color, slots);
  forearm.add(mesh(rbox(0.101, 0.032, 0.101, 0.014, 1), cuff, 0, -ARM_LENGTH + 0.032, 0));
  const handShell = matte("#eadccc", 0.53);
  const thumb = mesh(rbox(0.044, 0.032, 0.035, 0.014, 2), handShell, -side * 0.040, 0.023, -0.034);
  thumb.rotation.z = side * -0.37;
  hand.add(mesh(rbox(0.101, 0.072, 0.075, 0.029, 2), handShell), thumb);
  return { arm, forearm, hand };
}

export function buildRobots(): RobotRig[] {
  const rigs = ROLES.map((role) => buildRobot(role.id));
  for (const batch of [torsoBatch, hipBatch, armBatch, thighBatch]) {
    if (batch.instanceColor) batch.instanceColor.needsUpdate = true;
  }
  return rigs;
}

function addRoleDetails(id: RoleId, head: Group, hips: Group, trim: MeshStandardMaterial, accent: MeshStandardMaterial): void {
  const porcelain = matte("#ead9bd", 0.52);
  const enamel = matte("#283940", 0.46, 0.12);
  switch (id) {
    case "ceo": {
      head.add(mesh(rbox(0.392, 0.092, 0.360, 0.044, 2), trim, 0, 0.157, 0.014));
      head.add(mesh(rbox(0.308, 0.025, 0.022, 0.009, 1), accent, 0, 0.135, -0.171));
      const crest = mesh(rbox(0.095, 0.025, 0.095, 0.014, 2), accent, 0, 0.209, 0.015);
      crest.rotation.y = Math.PI / 4;
      head.add(crest);
      hips.add(mesh(rbox(0.462, 0.092, 0.316, 0.039, 2), trim, 0, 0.317, 0.006));
      hips.add(mesh(rbox(0.308, 0.023, 0.024, 0.009, 1), accent, 0, 0.322, 0.17));
      for (const side of [-1, 1]) {
        const lapel = mesh(rbox(0.041, 0.139, 0.022, 0.009, 1), accent, side * 0.087, 0.247, -0.139);
        lapel.rotation.z = side * 0.35;
        hips.add(lapel);
      }
      break;
    }
    case "quant": {
      const signal = matte("#8cdfcb", 0.42);
      signal.emissive.set("#62cdc4");
      signal.emissiveIntensity = 0.28;
      head.add(mesh(rbox(0.373, 0.039, 0.054, 0.016, 2), signal, 0, 0.112, -0.155));
      for (const side of [-1, 1]) {
        head.add(mesh(rbox(0.044, 0.055, 0.268, 0.020, 2), trim, side * 0.175, 0.110, -0.026));
        const fin = mesh(rbox(0.047, 0.105, 0.083, 0.020, 2), trim, side * 0.116, 0.169, 0.064);
        fin.rotation.z = -side * 0.27;
        head.add(fin, mesh(rbox(0.043, 0.031, 0.064, 0.010, 1), signal, side * 0.126, 0.224, 0.067));
      }
      hips.add(
        mesh(rbox(0.225, 0.112, 0.022, 0.016, 2), enamel, 0, 0.236, -0.140),
        mesh(rbox(0.144, 0.025, 0.026, 0.009, 1), signal, 0, 0.240, -0.151),
      );
      break;
    }
    case "backtest": {
      head.add(mesh(rbox(0.304, 0.054, 0.288, 0.024, 2), enamel, 0, 0.160, 0.020));
      head.add(mesh(rbox(0.136, 0.032, 0.274, 0.013, 2), trim, -0.029, 0.195, 0.025));
      head.add(mesh(new CylinderGeometry(0.022, 0.032, 0.084, 9), enamel, -0.091, 0.228, 0.060));
      head.add(mesh(rbox(0.076, 0.067, 0.071, 0.024, 2), accent, -0.091, 0.284, 0.060));
      for (const side of [-1, 1]) {
        head.add(mesh(rbox(0.061, 0.120, 0.148, 0.020, 2), trim, side * 0.185, 0.042, 0.060));
        for (const y of [0.012, 0.044, 0.076]) {
          head.add(mesh(rbox(0.011, 0.014, 0.100, 0.004, 1), accent, side * 0.218, y, 0.061));
        }
      }
      hips.add(mesh(rbox(0.256, 0.120, 0.027, 0.021, 2), enamel, 0, 0.226, -0.141));
      for (const x of [-0.066, 0, 0.066]) hips.add(mesh(rbox(0.032, 0.077, 0.022, 0.009, 1), accent, x, 0.224, -0.155));
      break;
    }
    case "literature": {
      head.add(mesh(rbox(0.326, 0.070, 0.302, 0.032, 2), trim, 0, 0.164, 0.035));
      head.add(mesh(rbox(0.251, 0.026, 0.225, 0.012, 2), accent, 0, 0.205, 0.042));
      const frame = new TorusGeometry(0.065, 0.0075, 6, 20);
      for (const side of [-1, 1]) {
        head.add(mesh(frame, accent, side * 0.073, 0.020, -0.194));
        head.add(mesh(rbox(0.014, 0.018, 0.097, 0.006, 1), trim, side * 0.158, 0.037, -0.131));
      }
      head.add(mesh(rbox(0.024, 0.015, 0.021, 0.006, 1), accent, 0, 0.024, -0.197));
      const leather = matte("#795032", 0.68);
      const strap = mesh(rbox(0.041, 0.316, 0.023, 0.009, 1), leather, 0.033, 0.199, 0.136);
      strap.rotation.z = 0.56;
      hips.add(strap);
      hips.add(mesh(rbox(0.218, 0.180, 0.069, 0.023, 2), leather, -0.101, 0.105, 0.144));
      hips.add(mesh(rbox(0.189, 0.062, 0.019, 0.009, 2), trim, -0.101, 0.151, 0.187));
      hips.add(mesh(rbox(0.032, 0.037, 0.014, 0.006, 1), accent, -0.101, 0.125, 0.196));
      break;
    }
    case "hr": {
      head.add(mesh(new TorusGeometry(0.179, 0.023, 7, 22, Math.PI), trim, 0, 0.042, 0.050));
      head.add(mesh(rbox(0.179, 0.051, 0.090, 0.022, 2), accent, 0, 0.198, 0.050));
      for (const side of [-1, 1]) {
        const ear = mesh(new CylinderGeometry(0.079, 0.087, 0.028, 14), trim, side * 0.213, 0.014, 0.019);
        ear.rotation.z = Math.PI / 2;
        head.add(ear);
      }
      hips.add(mesh(rbox(0.284, 0.123, 0.022, 0.019, 2), trim, 0, 0.235, -0.138));
      const heart = new Shape();
      heart.moveTo(0, -0.041);
      heart.bezierCurveTo(-0.076, 0.002, -0.037, 0.061, 0, 0.029);
      heart.bezierCurveTo(0.037, 0.061, 0.076, 0.002, 0, -0.041);
      hips.add(mesh(new ExtrudeGeometry(heart, { depth: 0.010, steps: 1, curveSegments: 10, bevelEnabled: false }), porcelain, 0, 0.231, -0.155));
      break;
    }
    case "secretary": {
      const mast = mesh(rbox(0.024, 0.174, 0.030, 0.010, 1), accent, 0.147, 0.170, 0.064);
      mast.rotation.z = -0.32;
      head.add(mast, mesh(rbox(0.063, 0.062, 0.045, 0.013, 2), trim, 0.173, 0.256, 0.064));
      head.add(mesh(rbox(0.026, 0.026, 0.013, 0.004, 1), accent, 0.178, 0.260, 0.043));
      const mic = mesh(rbox(0.115, 0.020, 0.023, 0.007, 1), enamel, 0.176, -0.035, -0.118);
      mic.rotation.y = -Math.PI / 3;
      head.add(mic, mesh(rbox(0.037, 0.035, 0.035, 0.012, 2), accent, 0.150, -0.035, -0.174));
      for (const side of [-1, 1]) {
        const collar = mesh(rbox(0.116, 0.058, 0.024, 0.012, 2), porcelain, side * 0.077, 0.326, -0.136);
        collar.rotation.z = side * -0.34;
        hips.add(collar);
      }
      hips.add(mesh(rbox(0.069, 0.129, 0.021, 0.013, 2), accent, 0, 0.245, -0.148));
      break;
    }
    case "ta": {
      head.add(mesh(rbox(0.266, 0.057, 0.263, 0.024, 2), trim, 0, 0.166, 0.022));
      const cap = mesh(rbox(0.300, 0.034, 0.300, 0.015, 2), enamel, 0, 0.205, 0.024);
      cap.rotation.y = Math.PI / 4;
      head.add(cap, mesh(new CylinderGeometry(0.029, 0.031, 0.017, 9), accent, 0, 0.229, 0.021));
      head.add(mesh(rbox(0.201, 0.014, 0.014, 0.005, 1), accent, 0.100, 0.225, 0.034));
      head.add(mesh(new CylinderGeometry(0.009, 0.009, 0.084, 8), accent, 0.194, 0.182, 0.034));
      head.add(mesh(new CylinderGeometry(0.014, 0.024, 0.054, 8), accent, 0.194, 0.124, 0.034));
      hips.add(mesh(rbox(0.236, 0.111, 0.027, 0.015, 2), trim, 0, 0.242, -0.143));
      for (const side of [-1, 1]) {
        const insignia = mesh(rbox(0.060, 0.048, 0.011, 0.005, 1), porcelain, side * 0.030, 0.240, -0.159);
        insignia.rotation.z = side * 0.16;
        hips.add(insignia);
      }
      break;
    }
  }
}

function buildRobot(id: RoleId): RobotRig {
  const role = ROLES.find((item) => item.id === id)!;
  const finish = finishes[id];
  const group = new Group();
  group.userData.role = id;
  group.name = id;
  const cloth = matte(role.cloth, role.id === "hr" ? 0.86 : 0.62);
  const skin = matte(finish.shell, 0.54);
  const trim = matte(finish.trim, 0.58, 0.09);
  const accent = matte(finish.metal, 0.34, 0.36);

  const hips = new Group();
  group.add(hips);
  const slots: RobotRig["slots"] = [];
  const torso = mesh(rbox(0.4, 0.34, 0.28, 0.08, 2), cloth, 0, 0.2, 0);
  hips.add(torso);
  track(torsoBatch, torso, cloth.color, slots);
  const hipPad = mesh(rbox(0.34, 0.12, 0.24, 0.05, 2), cloth, 0, 0.02, 0);
  hips.add(hipPad);
  track(hipBatch, hipPad, cloth.color, slots);

  const head = new Group();
  head.position.set(0, 0.48, 0);
  head.scale.set(...finish.proportions);
  hips.add(head);
  head.add(mesh(rbox(0.38, 0.34, 0.34, 0.1, 3), skin));
  const earpiece = new CylinderGeometry(0.082, 0.091, 0.035, 12);
  const earCap = new CylinderGeometry(0.051, 0.055, 0.018, 12);
  for (const side of [-1, 1]) {
    const shell = mesh(earpiece, trim, side * 0.187, 0.014, 0.016);
    const cap = mesh(earCap, accent, side * 0.206, 0.014, 0.016);
    shell.rotation.z = side * -Math.PI / 2;
    cap.rotation.z = shell.rotation.z;
    head.add(shell, cap);
  }
  head.add(mesh(rbox(0.154, 0.060, 0.021, 0.009, 1), trim, 0, -0.018, 0.170));
  for (const x of [-0.037, 0, 0.037]) {
    head.add(mesh(rbox(0.018, 0.013, 0.006, 0.003, 1), accent, x, -0.018, 0.183));
  }
  const setEyesOpen = addFace(head, id, role.iris);

  const cuff = id === "quant"
    ? new MeshStandardMaterial({ color: "#579488", roughness: 0.95, bumpMap: makeKnitBump(), bumpScale: 0.004 })
    : accent;
  const { arm: armL, forearm: forearmL, hand: handL } = addArm(hips, -1, cloth, cuff, slots);
  const { arm: armR, forearm: forearmR, hand: handR } = addArm(hips, 1, cloth, cuff, slots);

  const legL = new Group();
  legL.position.set(-0.09, 0, 0);
  hips.add(legL);
  track(thighBatch, limb(0.22, 0.05, cloth, legL), cloth.color, slots);
  const shinL = new Group();
  shinL.position.y = -0.22;
  legL.add(shinL);
  track(shinBatch, limb(0.2, 0.042, skin, shinL), null, slots);
  const legR = new Group();
  legR.position.set(0.09, 0, 0);
  hips.add(legR);
  track(thighBatch, limb(0.22, 0.05, cloth, legR), cloth.color, slots);
  const shinR = new Group();
  shinR.position.y = -0.22;
  legR.add(shinR);
  track(shinBatch, limb(0.2, 0.042, skin, shinR), null, slots);

  const mug = new Group();
  const glaze = matte("#f3e9dc", 0.34);
  const coffee = matte("#714431", 0.32);
  const rim = mesh(new TorusGeometry(0.047, 0.005, 6, 16), glaze, 0, 0.082, -0.027);
  rim.rotation.x = Math.PI / 2;
  mug.add(
    mesh(new CylinderGeometry(0.049, 0.039, 0.074, 16), glaze, 0, 0.045, -0.027),
    mesh(new CylinderGeometry(0.041, 0.041, 0.005, 16), coffee, 0, 0.082, -0.027),
    mesh(new TorusGeometry(0.021, 0.007, 6, 12), glaze, -0.056, 0.049, -0.027),
    rim,
  );
  mug.visible = false;
  hips.add(mug);

  addRoleDetails(id, head, hips, trim, accent);
  group.scale.setScalar(id === "ta" ? 1.05 : 1.16);

  const blob = new Mesh(new CircleGeometry(0.26, 18), blobMat);
  blob.rotation.x = -Math.PI / 2;
  blob.position.y = 0.02;
  blob.castShadow = false;
  group.add(blob);

  hips.position.y = 0.5;
  return {
    id,
    group,
    hips,
    head,
    armL,
    armR,
    forearmL,
    forearmR,
    handL,
    handR,
    legL,
    legR,
    shinL,
    shinR,
    setEyesOpen,
    mug,
    slots,
    sit: 1,
    bob: Math.random() * 6,
    blink: 1,
    nextBlink: 1.5 + Math.random() * 2.5 + (id === "hr" ? 1.2 : 0),
    blinkLeft: 0,
  };
}

interface Performance {
  time: number;
  action: RobotAction;
  deskApproach: number;
  hasCoffee: boolean;
  book?: ReturnType<typeof buildHeldBook>;
  tool?: ReturnType<typeof buildDeskTool>;
  pageAngle: number | null;
  left: Vector3;
  right: Vector3;
}

const performances = new WeakMap<RobotRig, Performance>();
const down = new Vector3(0, -1, 0);
const reach = new Vector3();
const bend = new Vector3();
const upper = new Vector3();
const lower = new Vector3();
const hand = new Vector3();
const tiltedGrip = new Vector3();
const inverseHips = new Matrix4();
const wristRotation = new Quaternion();

function headYawFor(bodyYaw: number): number {
  const desired = -0.55;
  let delta = desired - bodyYaw;
  while (delta > Math.PI) delta -= Math.PI * 2;
  while (delta < -Math.PI) delta += Math.PI * 2;
  return Math.max(-1.45, Math.min(1.45, delta));
}

function damp(current: number, target: number, dt: number, speed = 8): number {
  return current + (target - current) * (1 - Math.exp(-speed * dt));
}

function dampAngle(current: number, target: number, dt: number): number {
  let delta = target - current;
  while (delta > Math.PI) delta -= Math.PI * 2;
  while (delta < -Math.PI) delta += Math.PI * 2;
  return current + delta * (1 - Math.exp(-7 * dt));
}

export function poseRobot(rig: RobotRig, robot: RobotSnapshot, dt: number, reduced: boolean, desk?: DeskActionRig): void {
  let performance = performances.get(rig);
  const firstPose = performance === undefined;
  if (!performance) {
    const book = rig.id === "literature" ? buildHeldBook() : undefined;
    if (book) rig.hips.add(book.root);
    const tool = buildDeskTool(rig.id);
    if (tool) rig.handR.add(tool);
    performance = {
      time: ROLES.findIndex((role) => role.id === rig.id) * 0.62,
      action: "rest",
      deskApproach: 0,
      hasCoffee: false,
      book,
      tool,
      pageAngle: null,
      left: new Vector3(),
      right: new Vector3(),
    };
    performances.set(rig, performance);
  }
  const instant = reduced || firstPose;
  if (!reduced) performance.time += dt;
  const time = performance.time;
  const walking = robot.phase === "walking";
  const perched = robot.phase === "sipping";
  const working = robot.phase === "working";
  const byFire = robot.phase === "seated_fire";
  const readingInLounge = byFire && rig.id === "literature";
  const sitting = working || perched || byFire;
  if (sitting) performance.hasCoffee = perched || (byFire && !readingInLounge);
  const action = working ? deskActions[rig.id]
    : readingInLounge ? "reading"
    : sitting && performance.hasCoffee ? "sipping"
    : performance.hasCoffee && (walking || robot.phase === "getting_up") ? "carrying"
    : walking ? "walking" : "rest";
  performance.action = action;
  const wantSit = sitting ? 1 : 0;
  rig.sit = instant ? wantSit : damp(rig.sit, wantSit, dt, 7);
  const approach = working ? 0.115 : 0;
  performance.deskApproach = instant ? approach : damp(performance.deskApproach, approach, dt, 10);
  rig.group.position.set(robot.x - Math.sin(robot.yaw) * performance.deskApproach, 0, robot.z - Math.cos(robot.yaw) * performance.deskApproach);
  rig.group.rotation.y = instant ? robot.yaw : dampAngle(rig.group.rotation.y, robot.yaw, dt);
  if (walking && !reduced) rig.bob += dt * 9;
  const swing = walking && !reduced ? Math.sin(rig.bob) : 0;
  const bob = walking && !reduced ? Math.abs(Math.sin(rig.bob)) * 0.035 : 0;
  rig.hips.position.y = 0.5 + (perched ? 0.16 : -0.06) * rig.sit + bob;
  const lean = working ? -0.16 : readingInLounge ? -0.06 : walking ? -0.047 : 0;
  rig.hips.rotation.x = instant ? lean : damp(rig.hips.rotation.x, lean, dt, 8);
  const thigh = rig.sit * (perched ? 0.75 : 1.25);
  rig.legL.rotation.x = thigh + swing * 0.55;
  rig.legR.rotation.x = thigh - swing * 0.55;
  rig.shinL.rotation.x = -rig.sit * (perched ? 0.85 : 1.35);
  rig.shinR.rotation.x = -rig.sit * (perched ? 0.85 : 1.35);

  const { left, right } = performance;
  left.set(-0.267, -0.05, -swing * 0.17);
  right.set(0.267, -0.05, swing * 0.17);

  const book = performance.book;
  if (book) book.root.visible = readingInLounge;
  if (performance.tool) performance.tool.visible = working;
  const page = readingInLounge ? book?.page : working ? desk?.page : undefined;
  const turnTime = time % 5.1;
  const turn = page && !reduced ? Math.min(1, Math.max(0, (turnTime - 1.28) / 0.8)) : 0;
  page?.update(turn);
  if (desk?.page && desk.page !== page) desk.page.update(0);
  performance.pageAngle = page ? Math.abs(page.pivot.rotation.z) : null;
  let sip = 0;
  if (working && desk) {
    rig.hips.updateWorldMatrix(true, false);
    inverseHips.copy(rig.hips.matrixWorld).invert();
    desk.root.updateWorldMatrix(true, false);
    left.copy(desk.left);
    right.copy(desk.right);
    if (performance.tool) right.y += action === "stamping" ? 0.065 : 0.058;
    if (action === "typing" && !reduced) {
      const burst = 0.58 + 0.42 * Math.sin(time * 1.55) ** 2;
      left.y += burst * (0.032 + 0.029 * Math.sin(time * 16.8));
      right.y += burst * (0.032 + 0.029 * Math.sin(time * 19.2 + 1.9));
      left.x += 0.019 * Math.sin(time * 3.15);
      right.x += 0.021 * Math.cos(time * 3.7);
    } else if (action === "stamping" && !reduced) {
      const beat = time % 3.2;
      right.y += 0.16 * (smoothStep(0.32, 0.87, beat) - smoothStep(0.87, 1.06, beat));
    } else if (!reduced && action !== "reading") {
      const line = time % 1.7;
      right.x += (smoothStep(0.07, 1.29, line) - smoothStep(1.42, 1.68, line) - 0.5) * 0.128;
      right.y += 0.025 * Math.sin(time * 12.5) + 0.065 * Math.sin(Math.PI * smoothStep(1.36, 1.69, line));
      right.z += 0.029 * Math.sin(time * 7.1);
      if (action === "planning") left.y += 0.042 * Math.sin(time * 2.4) ** 2;
      if (action === "teaching") right.y += 0.075 * Math.max(0, Math.sin(time * 1.7)) ** 5;
    }
    left.applyMatrix4(desk.root.matrixWorld).applyMatrix4(inverseHips);
    right.applyMatrix4(desk.root.matrixWorld).applyMatrix4(inverseHips);
    left.lerp(hand.set(-0.248, 0.04, -0.19), 1 - rig.sit);
    right.lerp(hand.set(0.248, 0.04, -0.19), 1 - rig.sit);
  } else if (readingInLounge) {
    left.set(-0.138, 0.153, -0.22);
    right.set(0.145, 0.17, -0.236);
  } else if (action === "sipping" || action === "carrying") {
    const beat = time % 6.3;
    if (action === "sipping" && !reduced) sip = smoothStep(1.4, 2.25, beat) - smoothStep(2.83, 3.51, beat);
    left.set(-0.226 + 0.099 * sip, 0.076 + 0.300 * sip, -0.24 + 0.019 * sip);
    if (action === "sipping") right.set(0.205, 0.047, -0.17);
  }

  const pageGrip = page && !reduced ? smoothStep(1.10, 1.28, turnTime) * (1 - smoothStep(0.40, 0.58, turn)) : 0;
  if (page && pageGrip > 0) {
    // The hand starts the turn, then lets the leaf fall to the other side.
    const corner = rig.hips.worldToLocal(page.getGrip(hand));
    right.lerp(corner.sub(paperGrip), pageGrip);
  }

  aimArm(rig.armL, rig.forearmL, rig.handL, left, -1, dt, instant);
  aimArm(rig.armR, rig.forearmR, rig.handR, right, 1, dt, instant || pageGrip > 0);
  rig.mug.visible = action === "sipping" || action === "carrying";
  if (rig.mug.visible) {
    rig.handL.getWorldPosition(hand);
    rig.mug.rotation.x = -rig.hips.rotation.x - 0.23 * sip;
    tiltedGrip.copy(mugHandleGrip).applyEuler(rig.mug.rotation);
    rig.mug.position.copy(rig.hips.worldToLocal(hand)).add(palmGrip).sub(tiltedGrip);
  }

  const attention = action === "reading" ? 0.35 : working ? 0.73 : 1;
  const glance = reduced ? 0 : 0.11 * Math.sin(time * 0.81);
  const look = action === "reading" ? -0.27 : working ? -0.09 : action === "sipping" ? -0.13 * sip : 0.095;
  const faceYaw = headYawFor(robot.yaw) * attention * (1 - sip) + glance;
  rig.head.rotation.x = instant ? look : damp(rig.head.rotation.x, look, dt, 5);
  rig.head.rotation.y = instant ? faceYaw : damp(rig.head.rotation.y, faceYaw, dt, 5);

  if (!reduced) {
    rig.nextBlink -= dt;
    if (rig.nextBlink <= 0) {
      rig.blinkLeft = BLINK_DURATION;
      rig.nextBlink = (rig.id === "hr" ? 4.5 : 2.4) + Math.random() * 2.8;
    }
    if (rig.blinkLeft > 0) {
      rig.blinkLeft = Math.max(0, rig.blinkLeft - dt);
      const elapsed = 1 - rig.blinkLeft / BLINK_DURATION;
      rig.blink = 1 - smoothStep(0, 0.39, elapsed) + smoothStep(0.43, 1, elapsed);
    } else rig.blink = 1;
  } else {
    rig.blink = 1;
    rig.blinkLeft = 0;
  }
  rig.setEyesOpen(rig.blink);
  for (const slot of rig.slots) {
    slot.mesh.updateWorldMatrix(true, false);
    slotWorld.copy(slot.mesh.matrixWorld);
    slot.batch.setMatrixAt(slot.index, slotWorld);
    slot.batch.instanceMatrix.needsUpdate = true;
  }
}

function aimArm(shoulder: Group, forearm: Group, wrist: Group, target: Vector3, side: number, dt: number, instant: boolean): void {
  reach.copy(target).sub(shoulder.position);
  const length = Math.min(ARM_LENGTH * 1.995, Math.max(0.035, reach.length()));
  reach.normalize();
  bend.set(side * 0.42, -0.91, 0.12);
  bend.addScaledVector(reach, -bend.dot(reach)).normalize();
  const flex = Math.sqrt(ARM_LENGTH ** 2 - (length / 2) ** 2);
  upper.copy(reach).multiplyScalar(length / 2).addScaledVector(bend, flex);
  lower.copy(reach).multiplyScalar(length).sub(upper).normalize();
  const interpolation = instant ? 1 : 1 - Math.exp(-dt * 38);
  wristRotation.setFromUnitVectors(down, upper.normalize());
  shoulder.quaternion.slerp(wristRotation, interpolation);
  lower.applyQuaternion(wristRotation.copy(shoulder.quaternion).invert());
  wristRotation.setFromUnitVectors(down, lower);
  forearm.quaternion.slerp(wristRotation, interpolation);
  wrist.quaternion.multiplyQuaternions(shoulder.quaternion, forearm.quaternion).invert();
}

export function inspectRobotMotion(rig: RobotRig) {
  const performance = performances.get(rig);
  return {
    id: rig.id,
    action: performance?.action ?? "rest",
    leftHand: rig.handL.getWorldPosition(hand).toArray(),
    rightHand: rig.handR.getWorldPosition(hand).toArray(),
    coffeeVisible: rig.mug.visible,
    pageAngle: performance?.pageAngle ?? null,
  };
}
