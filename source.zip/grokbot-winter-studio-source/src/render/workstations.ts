import { CanvasTexture, SRGBColorSpace } from "three";
import type { RoleId } from "../sim/roles";

export const DESK_FINISH = {
  ceo: { lacquer: "#60433c", accent: "#883e53", trim: "#d7ad72" },
  quant: { lacquer: "#344f55", accent: "#37786d", trim: "#83c9b0" },
  backtest: { lacquer: "#465168", accent: "#64618d", trim: "#e0a76c" },
  literature: { lacquer: "#87694e", accent: "#718163", trim: "#ddb980" },
  hr: { lacquer: "#bd918f", accent: "#994e64", trim: "#f0ceb8" },
  secretary: { lacquer: "#3f5471", accent: "#557b9c", trim: "#a9c7e3" },
  ta: { lacquer: "#886451", accent: "#b16650", trim: "#e6b675" },
} satisfies Record<RoleId, { lacquer: string; accent: string; trim: string }>;

type Paper = "briefing" | "archive" | "intake" | "calendar" | "lesson";

export function makeDeskPaper(kind: Paper): CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 192;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not draw the stationery");
  const letter = {
    briefing: ["STUDIO BRIEF", "#824353", "#f6ead5"],
    archive: ["WINTER INDEX", "#52644c", "#f7e7c4"],
    intake: ["INTAKE", "#935160", "#fff1db"],
    calendar: ["WEEK 52", "#4e7294", "#ecf2e9"],
    lesson: ["LESSON 03", "#e1c698", "#2a5148"],
  }[kind];
  const [title, ink, paper] = letter;
  ctx.fillStyle = paper;
  ctx.fillRect(0, 0, 256, 192);
  ctx.strokeStyle = ink;
  ctx.globalAlpha = 0.45;
  ctx.lineWidth = 2;
  ctx.strokeRect(10, 10, 236, 172);
  ctx.globalAlpha = 1;
  ctx.fillStyle = ink;
  ctx.font = "bold 18px Georgia, serif";
  ctx.fillText(title, 20, 36);

  if (kind === "calendar") {
    const days = ["M", "T", "W", "T", "F", "S", "S"];
    ctx.font = "bold 11px system-ui, sans-serif";
    for (const [index, day] of days.entries()) {
      const x = 20 + index * 31;
      ctx.fillStyle = ink;
      ctx.fillText(day, x + 9, 60);
      ctx.strokeRect(x, 69, 29, 92);
    }
    ctx.fillStyle = "#d4a17a";
    ctx.fillRect(55, 86, 22, 14);
    ctx.fillRect(117, 104, 22, 24);
    ctx.fillStyle = "#789a8b";
    ctx.fillRect(86, 111, 23, 17);
    ctx.fillRect(149, 89, 22, 24);
  } else if (kind === "lesson") {
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(30, 152);
    ctx.lineTo(30, 65);
    ctx.moveTo(30, 152);
    ctx.lineTo(223, 152);
    ctx.moveTo(42, 138);
    ctx.quadraticCurveTo(120, 56, 212, 82);
    ctx.stroke();
    for (const [x, y] of [[68, 116], [121, 90], [197, 79]]) {
      ctx.beginPath();
      ctx.arc(x, y, 5, 0, Math.PI * 2);
      ctx.fill();
    }
  } else {
    ctx.globalAlpha = 0.33;
    for (let row = 0; row < 7; row += 1) {
      const y = 62 + row * 15;
      const x = kind === "intake" ? 46 : 22;
      if (kind === "intake") ctx.strokeRect(22, y - 7, 9, 9);
      ctx.fillRect(x, y, 167 - (row % 3) * 24, 2);
    }
  }
  const texture = new CanvasTexture(canvas);
  texture.colorSpace = SRGBColorSpace;
  texture.anisotropy = 4;
  return texture;
}
