import { ROLES, type RoleId } from "./sim/roles";

export type BotBindings = Partial<Record<RoleId, string>>;

const storageKey = "grokbot-winter-studio.bindings.v1";
const scheme = "grokbot://app/v1/agent?id=";
const shareLink = "https://x.ai/bot/agent/";
const conversationIdFormat = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;

export function parseConversationId(input: string): string | undefined {
  const value = input.trim();
  const prefix = [scheme, shareLink].find((candidate) => value.toLowerCase().startsWith(candidate));
  const id = prefix ? value.slice(prefix.length) : value;
  if (id.length === 36 && conversationIdFormat.test(id)) return id.toLowerCase();
}

export function decodeBindings(config: string | null): BotBindings {
  if (config === null) return {};
  let decoded: unknown;
  try {
    decoded = JSON.parse(config);
  } catch {
    return {};
  }
  if (!decoded || typeof decoded !== "object" || Array.isArray(decoded)) return {};

  const bindings: BotBindings = {};
  const record = decoded as Record<string, unknown>;
  for (const { id } of ROLES) {
    const value = record[id];
    if (typeof value !== "string") continue;
    const conversation = parseConversationId(value);
    if (conversation) bindings[id] = conversation;
  }
  return bindings;
}

export function readBindings(): BotBindings {
  try {
    return decodeBindings(window.localStorage.getItem(storageKey));
  } catch {
    return {};
  }
}

export function saveBindings(bindings: BotBindings): boolean {
  try {
    const storage = window.localStorage;
    if (Object.keys(bindings).length) storage.setItem(storageKey, JSON.stringify(bindings));
    else storage.removeItem(storageKey);
    return true;
  } catch {
    return false;
  }
}

export function conversationLink(id: string | undefined): string | undefined {
  if (id?.length === 36 && conversationIdFormat.test(id)) return `${scheme}${id.toLowerCase()}`;
}
