import "./style.css";
import {
  ACESFilmicToneMapping,
  Spherical,
  SRGBColorSpace,
  Vector2,
  Vector3,
  WebGLRenderer,
} from "three";
import { lightingForHour } from "./sim/lighting";
import { createSim, setIntent, snapshots, summonCoffee, tick } from "./sim/officeSim";
import { ROLES, type RoleId } from "./sim/roles";
import { effectiveSnow, initialSettings, reduceSettings, resolveClock, type SettingsAction } from "./sim/settings";
import { inspectRobotMotion, poseRobot } from "./render/robots";
import { configureRenderer, createOffice } from "./render/scene";
import { createCameraFocus } from "./render/focus";
import { createScenePicker } from "./render/selection";
import { createBindingsDialog } from "./bindingsDialog";

const canvas = document.querySelector<HTMLCanvasElement>("#view")!;
const fallback = document.querySelector<HTMLElement>("#fallback")!;
const linkForRobot = createBindingsDialog();

function showFallback(message: string): void {
  canvas.hidden = true;
  fallback.hidden = false;
  fallback.textContent = message;
}

try {
  start();
} catch (error) {
  console.error(error);
  showFallback("The studio could not open. Try reloading in a browser with WebGL 2 support.");
}

function start(): void {
  const renderer = new WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.outputColorSpace = SRGBColorSpace;
  renderer.toneMapping = ACESFilmicToneMapping;
  configureRenderer(renderer);
  const office = createOffice(canvas, renderer);
  const gl = renderer.getContext();
  const extension = gl.getExtension("WEBGL_debug_renderer_info");
  const rendererName = String(gl.getParameter(extension?.UNMASKED_RENDERER_WEBGL ?? gl.RENDERER));
  const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)");
  let settings = initialSettings(reducedMotion.matches);
  if (/llvmpipe|swiftshader|softpipe|software/i.test(rendererName)) settings = { ...settings, quality: "low" };

  const sim = createSim();
  const focus = createCameraFocus(office, (id) => sim.robots.find((robot) => robot.id === id));
  const pick = createScenePicker(office.scene, office.camera, office.robots);
  const pointer = new Vector2();
  const offset = new Vector3();
  const orbit = new Spherical();
  const activePointers = new Set<number>();
  let tap: { id: number; x: number; y: number } | null = null;
  let selected: RoleId | undefined;
  let dprScale = 1;
  let slowFrames = 0;
  let frames = 0;
  let fpsMark = performance.now();
  let last = fpsMark;
  let lastHour = -1;
  let recipe = lightingForHour(resolveClock(settings, new Date()).hour);
  let raf = 0;
  let lost = false;

  const debug = {
    get settings() { return settings; },
    get quality() { return settings.quality; },
    get cameraState() {
      return {
        position: office.camera.position.toArray(),
        target: office.controls.target.toArray(),
        zoom: office.camera.zoom,
      };
    },
    get robotStates() { return snapshots(sim); },
    get motionState() { return office.robots.map(inspectRobotMotion); },
    get focusState() { return focus.state; },
    get snowState() { return office.snowState; },
    fps: 0,
    renderer: rendererName,
    ready: false,
    lastHotspot: "",
    select: (id: RoleId) => { selected = id; },
    setZoom,
    setView(name: Parameters<typeof office.setView>[0]) {
      focus.clear();
      office.setView(name);
    },
    setRoof,
    toggleDoor: office.toggleDoor,
    toggleStringLights: office.toggleStringLights,
    pulseSteam: office.pulseSteam,
    draws: 0,
    tris: 0,
    action(type: string, value?: string | number) {
      switch (type) {
        case "preview":
          if (value != null && Number.isFinite(Number(value))) dispatch({ type: "set-preview", hour: Number(value) });
          return;
        case "quality":
          if (value === "low" || value === "standard" || value === "high") dispatch({ type: "set-quality", quality: value });
          return;
        case "zone": return dispatch({ type: "set-zone", timeZone: String(value) });
        case "snow": return dispatch({ type: "toggle-snow" });
        case "pause": return dispatch({ type: "toggle-pause" });
        case "demo": return dispatch({ type: "toggle-demo" });
        case "reduced": return dispatch({ type: "toggle-reduced" });
        case "now": return dispatch({ type: "clear-preview" });
        case "busy":
        case "idle":
          if (selected) setIntent(sim, selected, type);
      }
    },
  };
  Object.assign(window, { __OFFICE__: debug });

  applySettings();
  office.setQuality(settings.quality, renderer, dprScale);
  resize();
  window.addEventListener("resize", resize);
  reducedMotion.addEventListener("change", (event) => {
    settings = { ...settings, reducedMotion: event.matches };
    applySettings();
  });
  canvas.addEventListener("pointerdown", (event) => {
    activePointers.add(event.pointerId);
    tap = activePointers.size === 1 && event.button === 0 && !event.ctrlKey && !event.metaKey && !event.shiftKey
      ? { id: event.pointerId, x: event.clientX, y: event.clientY }
      : null;
    if (!tap) focus.interrupt();
  });
  canvas.addEventListener("pointermove", cancelMovedTap);
  canvas.addEventListener("pointerup", (event) => {
    cancelMovedTap(event);
    activePointers.delete(event.pointerId);
    if (tap?.id !== event.pointerId) return;
    tap = null;
    activate(event);
  });
  canvas.addEventListener("lostpointercapture", cancelPointer);
  canvas.addEventListener("pointercancel", cancelPointer);
  canvas.addEventListener("wheel", () => focus.interrupt(), { passive: true });
  window.addEventListener("keydown", keyControl);
  document.addEventListener("visibilitychange", () => {
    last = performance.now();
    if (!document.hidden && !lost && raf === 0) raf = requestAnimationFrame(frame);
  });
  canvas.addEventListener("webglcontextlost", (event) => {
    event.preventDefault();
    lost = true;
    debug.ready = false;
    cancelAnimationFrame(raf);
    showFallback("The graphics connection was lost. Reload the page to reopen the studio.");
  });
  raf = requestAnimationFrame(frame);

  function resize(): void {
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (!width || !height) return;
    renderer.setSize(width, height, false);
    office.resize(width, height);
  }

  function dispatch(action: SettingsAction): void {
    const previousQuality = settings.quality;
    settings = reduceSettings(settings, action);
    applySettings();
    if (previousQuality !== settings.quality) {
      office.setQuality(settings.quality, renderer, dprScale);
      resize();
    }
  }

  function applySettings(): void {
    sim.demo = settings.demo && !settings.reducedMotion;
    sim.paused = settings.paused;
    sim.reducedMotion = settings.reducedMotion;
    office.setReducedMotion(settings.reducedMotion);
  }

  function cancelMovedTap(event: PointerEvent): void {
    if (tap?.id === event.pointerId && Math.hypot(event.clientX - tap.x, event.clientY - tap.y) > 6) {
      tap = null;
      focus.interrupt();
    }
  }

  function cancelPointer(event: PointerEvent): void {
    activePointers.delete(event.pointerId);
    if (tap?.id === event.pointerId) tap = null;
  }

  function activate(event: PointerEvent): void {
    const rect = canvas.getBoundingClientRect();
    pointer.set((event.clientX - rect.left) / rect.width * 2 - 1, 1 - (event.clientY - rect.top) / rect.height * 2);
    const hit = pick(pointer);
    if (hit.type === "robot" || hit.type === "workstation") {
      selected = hit.id;
      const link = hit.type === "robot" ? linkForRobot(hit.id) : undefined;
      if (link && event.isTrusted) {
        window.location.assign(link);
        return;
      }
      focus.select(hit.id, settings.reducedMotion);
    } else if (hit.type === "background" || hit.type === "ground") {
      if (focus.state.role) focus.overview(settings.reducedMotion);
    } else if (hit.type === "hotspot") {
      if (hit.name === "hotspot-door") office.toggleDoor();
      if (hit.name === "hotspot-lights") office.toggleStringLights();
      if (hit.name === "hotspot-coffee" && !settings.paused) {
        summonCoffee(sim);
        office.pulseSteam();
      }
      debug.lastHotspot = hit.name;
    }
  }

  function setRoof(on: boolean): void {
    const { role } = focus.state;
    office.setRoof(on);
    if (role) focus.select(role, settings.reducedMotion);
  }

  function setZoom(zoom: number): void {
    focus.interrupt();
    office.camera.zoom = Math.min(office.controls.maxZoom, Math.max(office.controls.minZoom, zoom));
    office.camera.updateProjectionMatrix();
  }

  function keyControl(event: KeyboardEvent): void {
    if (event.altKey || event.metaKey || event.ctrlKey || event.defaultPrevented) return;
    if (event.target !== canvas && event.target !== document.body && event.target !== document.documentElement) return;
    const key = event.key.toLowerCase();
    const { camera, controls } = office;
    const directionX = Number(key === "arrowright") - Number(key === "arrowleft");
    const directionY = Number(key === "arrowup") - Number(key === "arrowdown");
    if (directionX || directionY) {
      focus.interrupt();
      if (event.shiftKey) {
        offset.set(directionX, directionY, 0).multiplyScalar(0.32 / camera.zoom).applyQuaternion(camera.quaternion);
        camera.position.add(offset);
        controls.target.add(offset);
      } else {
        orbit.setFromVector3(offset.copy(camera.position).sub(controls.target));
        orbit.theta -= directionX * 0.10;
        orbit.phi -= directionY * 0.085;
        orbit.phi = Math.min(controls.maxPolarAngle, Math.max(controls.minPolarAngle, orbit.phi));
        camera.position.copy(controls.target).add(offset.setFromSpherical(orbit));
      }
      controls.update();
    } else if (key === "+" || key === "=") setZoom(camera.zoom * 1.13);
    else if (key === "-" || key === "_") setZoom(camera.zoom / 1.13);
    else if (key === "0") {
      focus.clear();
      office.resetCamera();
    }
    else if (key >= "1" && key <= "7") selected = ROLES[Number(key) - 1].id;
    else if (event.repeat) return;
    else if (key === "enter" && selected) {
      const link = event.shiftKey ? linkForRobot(selected) : undefined;
      if (link && event.isTrusted) window.location.assign(link);
      else focus.select(selected, settings.reducedMotion);
    }
    else if (key === "escape") focus.overview(settings.reducedMotion);
    else if (key === " ") dispatch({ type: "toggle-pause" });
    else if (key === "r") dispatch({ type: "toggle-reduced" });
    else if (key === "t") setRoof(!office.roofVisible());
    else if (key === "d") office.toggleDoor();
    else if (key === "l") office.toggleStringLights();
    else if (key === "c" && !settings.paused) {
      summonCoffee(sim);
      office.pulseSteam();
    } else if (key === "b" && selected) setIntent(sim, selected, "busy");
    else if (key === "i" && selected) setIntent(sim, selected, "idle");
    else return;
    event.preventDefault();
  }

  function frame(now: number): void {
    if (document.hidden || lost) {
      raf = 0;
      return;
    }
    raf = requestAnimationFrame(frame);
    const cap = settings.quality === "low" ? 30 : 60;
    if (now - last < 1000 / cap - 0.8) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    const started = performance.now();
    if (!settings.paused) tick(sim, dt);
    const still = settings.paused || settings.reducedMotion;
    if (!settings.paused || !debug.ready) {
      const view = snapshots(sim);
      for (const rig of office.robots) {
        const robot = view.find((item) => item.id === rig.id);
        if (robot) poseRobot(rig, robot, dt, settings.reducedMotion, office.workstations.get(rig.id));
      }
    }
    const hour = settings.previewHour ?? resolveClock(settings, new Date()).hour;
    if (lastHour !== hour) {
      lastHour = hour;
      recipe = lightingForHour(hour);
      office.updateLighting(recipe, renderer);
      office.setClock(hour);
    }
    office.tickFire(settings.paused ? 0 : dt, still, recipe.fire);
    office.updateSnow(dt, effectiveSnow(settings));
    focus.update(dt, settings.reducedMotion);
    office.controls.update();
    office.render();

    debug.ready = true;
    debug.draws = renderer.info.render.calls;
    debug.tris = renderer.info.render.triangles;
    frames += 1;
    if (now - fpsMark > 600) {
      debug.fps = frames * 1000 / (now - fpsMark);
      frames = 0;
      fpsMark = now;
    }
    const cost = performance.now() - started;
    slowFrames = cost > 42 ? slowFrames + 1 : Math.max(0, slowFrames - 1);
    if (slowFrames > 24 && dprScale > 0.75) {
      dprScale = Math.max(0.75, dprScale - 0.15);
      office.setQuality(settings.quality, renderer, dprScale);
      resize();
      slowFrames = 0;
    }
  }
}
