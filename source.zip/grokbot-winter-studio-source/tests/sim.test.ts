import { describe, expect, it } from "vitest";
import { describeRobot } from "../src/sim/labels";
import { ROBOT_R, clearance, deskSeat } from "../src/sim/layout";
import { createSim, robotById, setIntent, snapshots, tick } from "../src/sim/officeSim";
import { ROLES } from "../src/sim/roles";

function settle(sim: ReturnType<typeof createSim>, seconds = 25): void {
  const steps = Math.ceil(seconds / 0.1);
  for (let i = 0; i < steps; i += 1) tick(sim, 0.1);
}

function assertClear(sim: ReturnType<typeof createSim>): void {
  for (const robot of sim.robots) {
    expect(clearance(robot.x, robot.z), robot.id).toBeGreaterThanOrEqual(ROBOT_R - 1e-3);
  }
}

describe("busy and idle life", () => {
  it("walks an idle robot to the kitchen or the hearth, then back to that robot's own desk", () => {
    const sim = createSim();
    sim.demo = false;
    const ceo = robotById(sim, "ceo");
    expect(describeRobot(snapshots(sim).find((item) => item.id === "ceo")!).line).toContain("Working at their desk");

    const seen: string[] = [];
    const track = () => {
      const line = describeRobot(snapshots(sim).find((item) => item.id === "ceo")!).line;
      if (seen[seen.length - 1] !== line) seen.push(line);
    };

    setIntent(sim, "ceo", "idle");
    for (let i = 0; i < 300 && ceo.phase !== "sipping" && ceo.phase !== "seated_fire"; i += 1) {
      tick(sim, 0.1);
      track();
      assertClear(sim);
    }
    expect(["sipping", "seated_fire"]).toContain(ceo.phase);
    expect(seen.some((line) => line.includes("Heading to the kitchen") || line.includes("Heading to the fireplace"))).toBe(true);
    expect(seen.at(-1)).toMatch(/kitchen|fireplace/);
    const idleSeat = ceo.seatId;
    expect(idleSeat?.startsWith("fire:") || idleSeat?.startsWith("kitchen:")).toBe(true);

    const returning: string[] = [];
    const trackBack = () => {
      const line = describeRobot(snapshots(sim).find((item) => item.id === "ceo")!).line;
      if (returning[returning.length - 1] !== line) returning.push(line);
    };
    setIntent(sim, "ceo", "busy");
    for (let i = 0; i < 400 && ceo.phase !== "working"; i += 1) {
      tick(sim, 0.1);
      trackBack();
      assertClear(sim);
    }
    expect(ceo.phase).toBe("working");
    expect(ceo.seatId).toBe(deskSeat("ceo").id);
    expect(Math.hypot(ceo.x - deskSeat("ceo").x, ceo.z - deskSeat("ceo").z)).toBeLessThan(0.08);
    expect(returning.some((line) => line.includes("Returning to their desk"))).toBe(true);
    expect(returning.at(-1)).toContain("Working at their desk");
  });

  it("interrupts an idle walk and returns to the desk", () => {
    const sim = createSim();
    sim.demo = false;
    const quant = robotById(sim, "quant");
    const home = deskSeat("quant");
    setIntent(sim, "quant", "idle");
    let moved = 0;
    for (let i = 0; i < 80 && moved < 0.6; i += 1) {
      tick(sim, 0.1);
      moved = Math.hypot(quant.x - home.x, quant.z - home.z);
      assertClear(sim);
    }
    expect(quant.phase).toBe("walking");
    setIntent(sim, "quant", "busy");
    for (let i = 0; i < 400 && quant.phase !== "working"; i += 1) {
      tick(sim, 0.1);
      assertClear(sim);
    }
    expect(quant.phase).toBe("working");
    expect(quant.seatId).toBe(home.id);
    const label = describeRobot(snapshots(sim).find((item) => item.id === "quant")!);
    expect(label.line).toContain("Demo · Working");
    expect(label.line).toContain("Working at their desk");
  });

  it("sends the secretary from the kitchen back to her own desk", () => {
    const sim = createSim();
    sim.demo = false;
    const secretary = robotById(sim, "secretary");
    expect(secretary.phase).toBe("sipping");
    expect(describeRobot(snapshots(sim).find((item) => item.id === "secretary")!).line).toContain("kitchen");
    setIntent(sim, "secretary", "busy");
    for (let i = 0; i < 400 && secretary.phase !== "working"; i += 1) {
      tick(sim, 0.1);
      assertClear(sim);
    }
    expect(secretary.phase).toBe("working");
    expect(secretary.seatId).toBe("desk:secretary");
    expect(describeRobot(snapshots(sim).find((item) => item.id === "secretary")!).line).toContain("Working at their desk");
  });

  it("gives every robot a distinct idle seat", () => {
    const sim = createSim();
    sim.demo = false;
    for (const role of ROLES) setIntent(sim, role.id, "idle");
    settle(sim, 30);
    const seats = sim.robots.map((robot) => robot.seatId);
    expect(new Set(seats).size).toBe(7);
    for (const robot of sim.robots) {
      expect(["sipping", "seated_fire"]).toContain(robot.phase);
      expect(robot.seatId?.startsWith("desk:")).toBe(false);
      assertClear(sim);
    }
  });

  it("staggers the automatic demo instead of flipping everyone together", () => {
    const sim = createSim();
    sim.demo = true;
    const previous = new Map(sim.robots.map((robot) => [robot.id, robot.intent]));
    const times: number[] = [];
    const counts = new Map<string, number>();
    for (let i = 0; i < 2200; i += 1) {
      tick(sim, 0.25);
      for (const robot of sim.robots) {
        if (robot.intent !== previous.get(robot.id)) {
          times.push(sim.elapsed);
          counts.set(robot.id, (counts.get(robot.id) ?? 0) + 1);
          previous.set(robot.id, robot.intent);
        }
      }
    }
    for (const role of ROLES) expect(counts.get(role.id) ?? 0).toBeGreaterThan(0);
    const sorted = [...times].sort((a, b) => a - b);
    for (let i = 1; i < sorted.length; i += 1) {
      expect(sorted[i] - sorted[i - 1]).toBeGreaterThan(4);
    }
  });
});
