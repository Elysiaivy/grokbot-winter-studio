import { describe, expect, it } from "vitest";
import { BLOCKS, GRID_R, ROBOT_R, SEATS, SHELL, clearance, pathClear, segmentClear } from "../src/sim/layout";
import { findPath } from "../src/sim/nav";
import { UPPER_FLOOR, UPPER_STAIR } from "../src/sim/upperFloor";

describe("office routes", () => {
  it("gives the reading room a quarter of the main hall after the tree-side cutout", () => {
    const polygon = UPPER_FLOOR.outline;
    const twiceArea = polygon.reduce((sum, [x, z], i) => {
      const [nextX, nextZ] = polygon[(i + 1) % polygon.length];
      return sum + x * nextZ - nextX * z;
    }, 0);
    const hallArea = (SHELL.maxX - SHELL.minX) * (SHELL.maxZ - SHELL.minZ);
    expect(Math.abs(twiceArea) / (2 * hallArea)).toBeCloseTo(0.25, 4);
    const stairCenter = (UPPER_STAIR.minX + UPPER_STAIR.maxX) / 2;
    expect(segmentClear({ x: stairCenter, z: UPPER_STAIR.footZ - 0.3 }, { x: stairCenter, z: UPPER_STAIR.landingZ })).toBe(false);
  });
  it("keeps every seat outside furniture and walls", () => {
    for (const seat of SEATS) {
      const gap = clearance(seat.x, seat.z);
      expect(gap, `${seat.id} clearance ${gap.toFixed(3)}`).toBeGreaterThan(GRID_R);
    }
  });

  it("rejects a shortcut through a desk", () => {
    const desk = BLOCKS.find((block) => block.id === "desk-quant");
    expect(desk).toBeTruthy();
    const through = segmentClear(
      { x: desk!.minX - 0.1, z: (desk!.minZ + desk!.maxZ) / 2 },
      { x: desk!.maxX + 0.1, z: (desk!.minZ + desk!.maxZ) / 2 },
    );
    expect(through).toBe(false);
  });

  it("joins every seat to every other seat without crossing furniture", () => {
    for (const origin of SEATS) {
      for (const goal of SEATS) {
        if (origin.id === goal.id) continue;
        const path = findPath(origin, goal);
        expect(path, `${origin.id} -> ${goal.id}`).toBeTruthy();
        expect(pathClear(path!, ROBOT_R), `${origin.id} -> ${goal.id}`).toBe(true);
        const end = path![path!.length - 1];
        expect(Math.hypot(end.x - goal.x, end.z - goal.z)).toBeLessThan(0.06);
      }
    }
  });
});
