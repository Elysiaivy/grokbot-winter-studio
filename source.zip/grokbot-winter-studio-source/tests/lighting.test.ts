import { describe, expect, it } from "vitest";
import { colorDistance, lightingForHour, periodForHour } from "../src/sim/lighting";
import { formatHour, hourInZone, initialSettings, reduceSettings, resolveClock } from "../src/sim/settings";

describe("artistic clock light", () => {
  it("labels morning, day, dusk, and night from the hour", () => {
    expect(periodForHour(3)).toBe("night");
    expect(periodForHour(6)).toBe("morning");
    expect(periodForHour(8.9)).toBe("morning");
    expect(periodForHour(9)).toBe("day");
    expect(periodForHour(16.4)).toBe("day");
    expect(periodForHour(16.5)).toBe("dusk");
    expect(periodForHour(18.9)).toBe("dusk");
    expect(periodForHour(19)).toBe("night");
    expect(periodForHour(23.5)).toBe("night");
  });

  it("keeps noon, dusk, and night visibly different and continuous", () => {
    const noon = lightingForHour(12.5);
    const dusk = lightingForHour(17.3);
    const night = lightingForHour(22);
    expect(noon.period).toBe("day");
    expect(dusk.period).toBe("dusk");
    expect(night.period).toBe("night");
    expect(noon.sunIntensity).toBeGreaterThan(night.sunIntensity + 0.8);
    expect(night.lamp).toBeGreaterThan(noon.lamp + 0.4);
    expect(night.street).toBeGreaterThan(noon.street + 0.5);
    expect(dusk.sunIntensity).toBeLessThan(noon.sunIntensity - 0.4);
    expect(colorDistance(noon.sunColor, dusk.sunColor)).toBeGreaterThan(70);
    expect(colorDistance(noon.skyTop, night.skyTop)).toBeGreaterThan(90);

    let previous = lightingForHour(0);
    for (let hour = 0.25; hour <= 24; hour += 0.25) {
      const current = lightingForHour(hour);
      expect(Math.abs(current.sunIntensity - previous.sunIntensity)).toBeLessThan(0.45);
      expect(Math.abs(current.lamp - previous.lamp)).toBeLessThan(0.45);
      previous = current;
    }
  });

  it("previews an hour and then returns to the Shanghai wall clock", () => {
    let settings = initialSettings(false);
    expect(settings.timeZone).toBe("Asia/Shanghai");
    settings = reduceSettings(settings, { type: "set-preview", hour: 21.5 });
    let clock = resolveClock(settings, new Date("2026-01-15T04:00:00Z"));
    expect(clock.preview).toBe(true);
    expect(clock.hour).toBe(21.5);
    expect(periodForHour(clock.hour)).toBe("night");
    expect(formatHour(clock.hour)).toBe("21:30");

    settings = reduceSettings(settings, { type: "clear-preview" });
    clock = resolveClock(settings, new Date("2026-01-15T04:00:00Z"));
    expect(clock.preview).toBe(false);
    expect(clock.hour).toBeCloseTo(12, 1);
    expect(periodForHour(clock.hour)).toBe("day");
    expect(hourInZone(new Date("2026-01-15T16:30:00Z"), "Asia/Hong_Kong")).toBeCloseTo(0.5, 1);
  });
});
