import { describe, expect, it } from "vitest";
import { conversationLink, decodeBindings, parseConversationId } from "../src/grokBot";

const exampleId = "00000000-0000-4000-8000-00000000000a";

describe("Grok Bot conversation bindings", () => {
  it("accepts IDs and the two supported links and generates one canonical native URL", () => {
    for (const input of [
      `  ${exampleId.toUpperCase()}  `,
      `grokbot://app/v1/agent?id=${exampleId}`,
      `https://x.ai/bot/agent/${exampleId}`,
    ]) {
      const id = parseConversationId(input);
      expect(id).toBe(exampleId);
      expect(conversationLink(id)).toBe(`grokbot://app/v1/agent?id=${exampleId}`);
    }
  });

  it("rejects unrelated origins, malformed IDs, and extra URL components", () => {
    for (const input of [
      "",
      "not-an-id",
      `https://x.ai.evil.example/bot/agent/${exampleId}`,
      `https://x.ai@evil.example/bot/agent/${exampleId}`,
      `https://x.ai/bot/agent/${exampleId}?extra=1`,
      `grokbot://app/v1/agent?id=${exampleId}&redirect=...`,
      `grokbot://app/v1/agent#${exampleId}`,
      `grokbot://app/v1/agent?id=${exampleId}/`,
    ]) expect(parseConversationId(input)).toBeUndefined();
    expect(conversationLink(`${exampleId}\n`)).toBeUndefined();
  });

  it("ignores corrupted local data and retains only valid known roles", () => {
    for (const invalid of [null, "{invalid", "null", "[]", "42"]) {
      expect(decodeBindings(invalid)).toEqual({});
    }
    expect(decodeBindings(JSON.stringify({ ceo: exampleId, quant: 3, unknown: exampleId }))).toEqual({ ceo: exampleId });
  });
});
