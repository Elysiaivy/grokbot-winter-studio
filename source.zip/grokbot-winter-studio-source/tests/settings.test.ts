import { describe, expect, it } from "vitest";
import { effectiveSnow, initialSettings, reduceSettings } from "../src/sim/settings";

describe("controls", () => {
  it("toggles pause, snow, quality, and reduced motion", () => {
    let settings = initialSettings(false);
    expect(settings.paused).toBe(false);
    expect(settings.demo).toBe(true);
    expect(settings.quality).toBe("standard");
    expect(settings.previewHour).toBe(21.3);
    expect(effectiveSnow(settings)).toBe(true);

    settings = reduceSettings(settings, { type: "toggle-pause" });
    expect(settings.paused).toBe(true);
    settings = reduceSettings(settings, { type: "toggle-pause" });
    expect(settings.paused).toBe(false);

    settings = reduceSettings(settings, { type: "toggle-snow" });
    expect(settings.snow).toBe(false);
    expect(effectiveSnow(settings)).toBe(false);
    settings = reduceSettings(settings, { type: "toggle-snow" });
    expect(settings.snow).toBe(true);
    expect(effectiveSnow(settings)).toBe(true);

    settings = reduceSettings(settings, { type: "set-quality", quality: "low" });
    expect(settings.quality).toBe("low");
    settings = reduceSettings(settings, { type: "set-quality", quality: "high" });
    expect(settings.quality).toBe("high");

    settings = reduceSettings(settings, { type: "toggle-reduced" });
    expect(settings.reducedMotion).toBe(true);
    expect(settings.snow).toBe(true);
    expect(effectiveSnow(settings)).toBe(false);

    settings = reduceSettings(settings, { type: "toggle-reduced" });
    expect(effectiveSnow(settings)).toBe(true);

    settings = reduceSettings(settings, { type: "toggle-demo" });
    expect(settings.demo).toBe(false);
    settings = reduceSettings(settings, { type: "set-zone", timeZone: "Asia/Shanghai" });
    expect(settings.timeZone).toBe("Asia/Shanghai");
  });
});
