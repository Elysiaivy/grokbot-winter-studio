import { describe, expect, it } from "vitest";
import { clearance, ROBOT_R } from "../src/sim/layout";
import { createSim, robotById, setIntent, summonCoffee, tick } from "../src/sim/officeSim";
import { ROLES } from "../src/sim/roles";

describe("coffee machine summon", () => {
  it("walks an idle robot to the kitchen without crossing furniture", () => {
    const sim = createSim();
    sim.demo = false;
    const result = summonCoffee(sim);
    expect(result.ok).toBe(true);
    expect(result.reason).toBe("walking");
    const robot = robotById(sim, result.id!);
    expect(robot.intent).toBe("idle");
    for (let i = 0; i < 400 && robot.phase !== "sipping"; i += 1) {
      tick(sim, 0.1);
      expect(clearance(robot.x, robot.z), robot.id).toBeGreaterThanOrEqual(ROBOT_R - 1e-3);
    }
    expect(robot.phase).toBe("sipping");
    expect(robot.seatId?.startsWith("kitchen:")).toBe(true);
  });

  it("does not pull a busy robot, and a new task still returns the summoned robot to their own desk", () => {
    const sim = createSim();
    sim.demo = false;
    for (const role of ROLES) {
      if (robotById(sim, role.id).intent === "idle") setIntent(sim, role.id, "busy");
    }
    for (let i = 0; i < 400; i += 1) tick(sim, 0.1);
    expect(summonCoffee(sim).reason).toBe("busy");

    setIntent(sim, "literature", "idle");
    for (let i = 0; i < 400 && robotById(sim, "literature").phase === "getting_up"; i += 1) tick(sim, 0.1);
    const called = summonCoffee(sim);
    expect(called.ok).toBe(true);
    const robot = robotById(sim, "literature");
    setIntent(sim, "literature", "busy");
    for (let i = 0; i < 400 && robot.phase !== "working"; i += 1) {
      tick(sim, 0.1);
      expect(clearance(robot.x, robot.z)).toBeGreaterThanOrEqual(ROBOT_R - 1e-3);
    }
    expect(robot.phase).toBe("working");
    expect(robot.seatId).toBe("desk:literature");
  });

  it("refuses to summon while the demonstration is paused", () => {
    const sim = createSim();
    sim.paused = true;
    expect(summonCoffee(sim)).toEqual({ ok: false, reason: "paused" });
  });
});
