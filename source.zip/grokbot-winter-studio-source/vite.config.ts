import { defineConfig } from "vite";

export default defineConfig({
  base: "./",
  server: {
    host: "127.0.0.1",
    port: 41773,
    strictPort: true,
  },
  preview: {
    host: "127.0.0.1",
    port: 41773,
    strictPort: true,
  },
  build: {
    cssCodeSplit: false,
    modulePreload: false,
    assetsInlineLimit: 100000000,
    rollupOptions: {
      output: {
        inlineDynamicImports: true,
        entryFileNames: "assets/office.js",
        assetFileNames: "assets/office[extname]",
      },
    },
  },
});
