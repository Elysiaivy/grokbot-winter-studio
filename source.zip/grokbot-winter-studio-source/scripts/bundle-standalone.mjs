import { readFileSync, writeFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { build } from "esbuild";

const dist = join(process.cwd(), "dist");
const htmlPath = join(dist, "index.html");
const html = readFileSync(htmlPath, "utf8");
const notices = readFileSync(new URL("../THIRD-PARTY-NOTICES.txt", import.meta.url), "utf8");
const assets = readdirSync(join(dist, "assets"));
const jsName = assets.find((file) => file.endsWith(".js") && !file.includes("iife"));
const cssName = assets.find((file) => file.endsWith(".css"));
if (!jsName) throw new Error("Could not find the built script");

const iifePath = join(dist, "assets", "office-iife.js");
await build({
  entryPoints: [join(dist, "assets", jsName)],
  bundle: true,
  format: "iife",
  platform: "browser",
  target: "es2022",
  minify: true,
  outfile: iifePath,
  legalComments: "none",
});

const css = cssName ? readFileSync(join(dist, "assets", cssName), "utf8") : "";
const js = readFileSync(iifePath, "utf8").replace(/<\/script/gi, "<\\/script");
const safeCss = css.replace(/<\/style/gi, "<\\/style");
const page = html
  .replace("<!DOCTYPE html>", () => "<!DOCTYPE html>\n<!--\n" + notices + "-->")
  .replace(/<script type="module"[^>]*src="[^"]+"[^>]*><\/script>\s*/g, "")
  .replace(/<link rel="stylesheet"[^>]*>\s*/g, "")
  .replace("</head>", () => "<style>" + safeCss + "</style></head>")
  .replace("</body>", () => "<script>" + js + "</script></body>");

if (page.includes('type="module"') || page.includes("src=\"./assets")) {
  throw new Error("The standalone page still references external modules");
}
writeFileSync(join(dist, "standalone.html"), page);
console.log(`standalone.html ${(page.length / 1024).toFixed(0)} KB`);
